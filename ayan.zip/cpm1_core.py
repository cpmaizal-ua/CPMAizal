
import asyncio
import os, time, json, hashlib, zlib, sqlite3, secrets, html, threading, struct, base64, struct, base64
import logging
from copy import deepcopy
from typing import Any, Dict, List, Optional, Tuple
from datetime import datetime, timedelta
from urllib.parse import urlparse, urlunparse
import requests, urllib3, httpx
from config import (
    HOST_SERVER_IP,
    REQUEST_PACE_SECONDS,
    REQUEST_TIMEOUT_SECONDS,
)
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
LOGGER = logging.getLogger("coby.requests")
try:
    import brotli
    HAS_BROTLI = True
except ImportError:
    brotli = None
    HAS_BROTLI = False
try:
    from Crypto.Cipher import AES
    from Crypto.Util.Padding import pad, unpad
    HAS_CRYPTO = True
except ImportError:
    HAS_CRYPTO = False

FK = "AIzaSyBW1ZbMiUeDZHYUO2bY8Bfnf5rRgrQGPTM"
LOAD_URL = "https://europe-west1-cp-multiplayer.cloudfunctions.net/GetPlayerRecords3"
SAVE_URL = "https://europe-west1-cp-multiplayer.cloudfunctions.net/SavePlayerRecordsPartially8"
RANK_URL = "https://us-central1-cp-multiplayer.cloudfunctions.net/SetUserRating5"
MAX_MONEY = 50_000_000
MAX_COIN = 500_000
GAME_HEADERS = {
    "Accept": "*/*",
    "Accept-Encoding": "gzip",
    "Content-Type": "application/json",
    "User-Agent": "UnityPlayer/2022.3.62f2 (UnityWebRequest/1.0, libcurl/8.10.1-DEV)",
    "X-Unity-Version": "2022.3.62f2",
}
http_session = requests.Session()
adapter = requests.adapters.HTTPAdapter(
    pool_connections=15,
    pool_maxsize=15,
    max_retries=0,
    pool_block=True,
)
http_session.mount("https://", adapter)
http_session.mount("http://", adapter)
HTTP_MAX_CONNECTIONS = 3
HTTP_ASYNC_LIMITS = httpx.Limits(
    max_connections=HTTP_MAX_CONNECTIONS,
    max_keepalive_connections=HTTP_MAX_CONNECTIONS,
)


def new_car_upload_semaphore() -> asyncio.Semaphore:
    return asyncio.Semaphore(3)


REQUEST_GATE_LOCK = threading.Lock()
_LAST_REQUEST_TS = 0.0
_ACCOUNT_DEADLINE = threading.local()
ACCOUNT_TIMEOUT_SECONDS = 120.0


class AccountTimeoutError(TimeoutError):
    pass


def set_account_timeout(seconds: float) -> None:
    _ACCOUNT_DEADLINE.ends_at = time.monotonic() + seconds


def clear_account_timeout() -> None:
    if hasattr(_ACCOUNT_DEADLINE, "ends_at"):
        del _ACCOUNT_DEADLINE.ends_at


def get_account_deadline() -> Optional[float]:
    return getattr(_ACCOUNT_DEADLINE, "ends_at", None)


def check_account_timeout() -> Optional[float]:
    ends_at = getattr(_ACCOUNT_DEADLINE, "ends_at", None)
    if ends_at is None:
        return None
    remaining = ends_at - time.monotonic()
    if remaining <= 0:
        raise AccountTimeoutError(
            f"Account execution exceeded {ACCOUNT_TIMEOUT_SECONDS:g} seconds"
        )
    return remaining


def account_sleep(seconds: float) -> None:
    remaining = check_account_timeout()
    if remaining is not None:
        time.sleep(min(seconds, remaining))
        check_account_timeout()
    else:
        time.sleep(seconds)


def resolve_request_url(url: str) -> str:
    if not url:
        return url
    if not HOST_SERVER_IP or HOST_SERVER_IP in ("0.0.0.0", "::", "localhost"):
        return url
    parsed = urlparse(url)
    if not parsed.scheme or not parsed.netloc:
        return url
    if parsed.hostname == HOST_SERVER_IP:
        return url
    host = parsed.hostname or ""
    if host == "127.0.0.1" or host.endswith("cloudfunctions.net") or host.endswith("googleapis.com"):
        return url
    rebuilt = parsed._replace(netloc=f"{HOST_SERVER_IP}:{parsed.port or (443 if parsed.scheme == 'https' else 80)}")
    return urlunparse(rebuilt)


def _pace_request() -> None:
    global _LAST_REQUEST_TS
    with REQUEST_GATE_LOCK:
        wait_for = _LAST_REQUEST_TS + REQUEST_PACE_SECONDS - time.monotonic()
        while wait_for > 0:
            remaining = check_account_timeout()
            if wait_for >= 1:
                LOGGER.info(
                    "Rate-limiting pause before next request: %d second(s) remaining",
                    int(wait_for + 0.999),
                )
                account_sleep(min(1.0, wait_for, remaining) if remaining is not None else min(1.0, wait_for))
            else:
                LOGGER.debug("Rate-limiting pause before next request: %.2fs", wait_for)
                account_sleep(min(wait_for, remaining) if remaining is not None else wait_for)
            wait_for = _LAST_REQUEST_TS + REQUEST_PACE_SECONDS - time.monotonic()
        _LAST_REQUEST_TS = time.monotonic()


def direct_request(
    method: str,
    url: str,
    *,
    retries: int = None,
    timeout: Optional[float] = None,
    pace: bool = True,
    **kwargs,
):
    timeout = timeout if timeout is not None else REQUEST_TIMEOUT_SECONDS
    check_account_timeout()
    if pace:
        _pace_request()
    target_url = resolve_request_url(url)
    remaining = check_account_timeout()
    request_timeout = min(timeout, remaining) if remaining is not None else timeout
    response = getattr(http_session, method.lower())(
        target_url,
        timeout=request_timeout,
        **kwargs,
    )
    check_account_timeout()
    return response


USE_MONGO = False
db_path = "cpm_web.db"
tokens_col = users_col = premium_col = admins_col = user_data_col = None

with sqlite3.connect(db_path) as c:
    c.execute("CREATE TABLE IF NOT EXISTS tokens (user_id INTEGER PRIMARY KEY, auth_token TEXT, email TEXT, password TEXT, refresh_token TEXT, firebase_uid TEXT, token_expires_at REAL)")
    c.execute("CREATE TABLE IF NOT EXISTS user_data (cache_key TEXT PRIMARY KEY, email TEXT, data_json TEXT, saved_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP)")
    c.execute("""CREATE TABLE IF NOT EXISTS license_keys (
        key_code TEXT PRIMARY KEY, max_devices INTEGER DEFAULT 1, devices TEXT DEFAULT '[]',
        expires_at REAL DEFAULT 0, created_at REAL, created_by TEXT, active INTEGER DEFAULT 1)""")
    c.execute("CREATE TABLE IF NOT EXISTS user_keys (session_id TEXT PRIMARY KEY, key_code TEXT, activated_at REAL)")
    c.execute("CREATE TABLE IF NOT EXISTS admins (username TEXT PRIMARY KEY, password TEXT)")
    c.commit()

def make_xor_key(uid: str) -> bytes:
    chars = list(str(uid or ""))
    if len(chars) >= 9: chars[1], chars[8] = chars[8], chars[1]
    if len(chars) >= 3: chars.pop(2)
    if len(chars) >= 5: chars.append(chars[4])
    return "".join(chars).encode("utf-8") or b"0"

def xor_bytes(data: bytes, key: bytes) -> bytes: return bytes(data[i] ^ key[i % len(key)] for i in range(len(data)))

def decompress(data: bytes):
    if HAS_BROTLI:
        try: return brotli.decompress(data)
        except: pass
    for args in ((zlib.MAX_WBITS | 16,), tuple()):
        try: return zlib.decompress(data, *args)
        except: pass
    return None

def decrypt_aes(data: bytes, key: bytes):
    if not HAS_CRYPTO: return None
    try: return unpad(AES.new(key[:16], AES.MODE_CBC, b"\x00" * 16).decrypt(data), 16)
    except: return None

def _md5(text: str) -> bytes: return hashlib.md5(str(text).encode()).digest()
def _sha1(text: str) -> bytes: return hashlib.sha1(str(text).encode()).digest()[:16]
def build_aes_keys(uid: str, password: str = None, email: str = None) -> list:
    keys = [_md5("olzhas_carparking")]
    if password: keys.extend([_md5(password), _sha1(password)])
    if uid: keys.extend([_md5(uid), _sha1(uid)])
    if email: keys.append(_md5(email))
    return keys

class Reader:
    def __init__(self, data: bytes): self.buf, self.pos = data, 0
    def has_bytes(self, n: int) -> bool: return self.pos + n <= len(self.buf)
    def read_byte(self) -> int:
        if not self.has_bytes(1): return 0
        v = self.buf[self.pos]; self.pos += 1; return v
    def read_int(self) -> int:
        if not self.has_bytes(4): self.pos = len(self.buf); return 0
        v = struct.unpack_from("<i", self.buf, self.pos)[0]; self.pos += 4; return v
    def read_float(self) -> float:
        if not self.has_bytes(4): self.pos = len(self.buf); return 0.0
        v = struct.unpack_from("<f", self.buf, self.pos)[0]; self.pos += 4; return v
    def read_string(self) -> str:
        marker = self.read_int()
        if marker in (0, -1): return ""
        length = (-marker) - 1 if marker < -1 else marker
        if marker < -1: self.read_int()
        length = max(0, min(length, 1000000))
        if not self.has_bytes(length): return ""
        text = self.buf[self.pos:self.pos + length].decode("utf-8", errors="replace")
        self.pos += length
        return text.replace("\x00", "").strip()
    def read_list(self, item_fn):
        count = self.read_int()
        if count <= 0 or count > 1000000: return []
        res = []
        for _ in range(count):
            if self.pos >= len(self.buf): break
            val = item_fn()
            if val is not None: res.append(val)
        return res
    def read_dict(self) -> dict:
        count = self.read_int()
        if count <= 0 or count > 1000000: return {}
        return {self.read_int(): self.read_int() for _ in range(count) if self.pos < len(self.buf)}
    def read_equipment(self):
        if self.read_byte() == 0: return None
        return {k: self.read_list(self.read_int) for k in ["hair", "face", "beard", "cap", "mask", "top", "gloves", "bag", "pants", "shoes", "glasses", "SelectedEquipments"]} | {"Gender": self.read_int()}

def parse_player(buf: bytes) -> dict:
    r = Reader(buf)
    if r.read_byte() == 0: return None
    player = {"Name": r.read_string(), "money": r.read_int(), "coin": r.read_int(), "localID": r.read_string(), "boughtFsos": r.read_list(r.read_int)}
    player["FriendsID"] = r.read_list(lambda: (r.read_byte(), {"id": r.read_string(), "Name": r.read_string(), "accountID": r.read_string()})[1])
    player.update({"LevelsDoneTime": r.read_list(r.read_float), "floats": r.read_list(r.read_float), "integers": r.read_list(r.read_int), "fcar": r.read_list(r.read_int), "favouriteWheels": r.read_list(r.read_int), "favouriteVinyls": r.read_list(r.read_int), "favouriteEmojis": r.read_list(r.read_int), "personEquipmentsMale": r.read_equipment(), "personEquipmentsFemale": r.read_equipment()})
    if r.read_byte() == 0: player["platesData"] = None
    else:
        def read_vinyl(): r.read_byte(); return {"vectors": r.read_list(lambda: {"x": r.read_float(), "y": r.read_float(), "z": r.read_float()}), "v": r.read_list(r.read_string), "floats": r.read_list(r.read_float), "text": r.read_string()}
        def read_plate(): r.read_byte(); return {"plateId": r.read_int(), "frontCarId": r.read_int(), "rearCarId": r.read_int(), "vinyls": r.read_list(read_vinyl)}
        player["platesData"] = {"allPlates": r.read_list(read_plate)}

    if r.read_byte() == 0: player["carIDnStatus"] = None
    else: player["carIDnStatus"] = {"carGeneratedIDs": r.read_list(r.read_string), "carStatus": r.read_list(r.read_int)}
    
    player["allData"] = r.read_string()
    player["flags"] = r.read_dict()
    player["animations"] = r.read_list(r.read_int)
    player["emojiPacks"] = r.read_list(r.read_int)
    player["wheels"] = r.read_list(r.read_int)
    player["boughtPoliceLights"] = r.read_list(r.read_int)
    player["boughtPoliceSirens"] = r.read_list(r.read_int)
    return player

def try_parse(buf: bytes) -> dict:
    candidates = [buf, decompress(buf)]
    if candidates[1]: candidates.append(decompress(candidates[1]))
    for candidate in filter(None, candidates):
        if candidate[0] in (17, 23, 24):
            try:
                p = parse_player(candidate)
                if p and p.get("Name") is not None: return p
            except: pass
        try:
            clean = candidate[3:] if len(candidate) >= 3 and candidate[:2] == b"\xef\xbb" else candidate
            if clean and clean[0] == 123: return json.loads(clean.decode("utf-8"))
        except: pass
    return None

def decrypt_player_record(base64_text: str, uid: str, password: str = None, email: str = None) -> dict:
    try: buf = base64.b64decode(base64_text)
    except: return {"success": False, "message": "Bad base64"}
    if len(buf) < 10: return {"success": False, "message": "Too small"}
    direct = try_parse(buf)
    if direct: return {"success": True, "record": direct}
    if uid:
        try:
            decoded = decompress(xor_bytes(buf, make_xor_key(uid)))
            if decoded:
                parsed = try_parse(decoded)
                if parsed: return {"success": True, "record": parsed}
        except: pass
    for key in build_aes_keys(uid or "", password, email):
        plain = decrypt_aes(buf, key)
        if not plain: continue
        parsed = try_parse(plain)
        if parsed: return {"success": True, "record": parsed}
    return {"success": False, "message": "Could not decrypt"}

class Writer:
    def __init__(self): self._p: List[bytes] = []
    def write_byte(self, v): self._p.append(bytes([int(v or 0) & 0xFF]))
    def write_int(self, v): self._p.append(struct.pack("<i", int(v or 0)))
    def write_float(self, v): self._p.append(struct.pack("<f", float(v or 0.0)))
    def write_string(self, s):
        if s is None: self._p.append(struct.pack("<i", -1)); return
        s = str(s)
        if s == "": self._p.append(struct.pack("<i", 0)); return
        enc = s.encode("utf-8")
        self._p.append(struct.pack("<ii", -(len(enc)) - 1, len(s)) + enc)
    def write_list(self, lst, fn):
        if lst is None: self._p.append(struct.pack("<i", -1)); return
        self._p.append(struct.pack("<i", len(lst)))
        for item in lst: fn(item)
    def write_equipment(self, data):
        if not data: self.write_byte(0); return
        self.write_byte(13)
        for key in ["hair", "face", "beard", "cap", "mask", "top", "gloves", "bag", "pants", "shoes", "glasses", "SelectedEquipments"]:
            self.write_list(data.get(key, []), self.write_int)
        self.write_int(data.get("Gender", 0))
    def write_plates(self, data):
        if not data: self.write_byte(0); return
        self.write_byte(1)
        plates = data.get("allPlates", [])
        self._p.append(struct.pack("<i", len(plates)))
        for plate in plates:
            self.write_byte(4); self.write_int(plate.get("plateId", 0)); self.write_int(plate.get("frontCarId", 0)); self.write_int(plate.get("rearCarId", 0))
            vinyls = plate.get("vinyls", [])
            self._p.append(struct.pack("<i", len(vinyls)))
            for vinyl in vinyls:
                self.write_byte(4)
                vecs = vinyl.get("vectors", [])
                self._p.append(struct.pack("<i", len(vecs)))
                for vec in vecs: self._p.append(struct.pack("<fff", vec.get("x", 0), vec.get("y", 0), vec.get("z", 0)))
                self.write_list(vinyl.get("v", []), self.write_string)
                self.write_list(vinyl.get("floats", []), self.write_float)
                self.write_string(vinyl.get("text", ""))
    def write_car_id_status(self, data):
        if not data: self.write_byte(0); return
        self.write_byte(2)
        self.write_list(data.get("carGeneratedIDs", []), self.write_string)
        self.write_list(data.get("carStatus", []), self.write_int)
    def to_bytes(self): return b"".join(self._p)

FIELD_MAPPING = [(1, "localID"), (2, "money"), (3, "Name"), (4, "coin"), (5, "allData"), (6, "boughtFsos"), (7, "boughtPoliceLights"), (8, "boughtPoliceSirens"), (9, "FriendsID"), (10, "LevelsDoneTime"), (11, "floats"), (12, "integers"), (13, "fcar"), (14, "favouriteWheels"), (15, "favouriteVinyls"), (16, "favouriteEmojis"), (18, "emojiPacks"), (41, "personEquipmentsMale"), (42, "personEquipmentsFemale"), (43, "platesData"), (44, "carIDnStatus"), (45, "flags"), (46, "animations"), (48, "wheels")]
INT_LIST_FIELDS = {6, 7, 8, 12, 13, 14, 15, 16, 18, 46, 48}
FLOAT_LIST_FIELDS = {10, 11}

def _field_modified(new_value, old_value) -> bool:
    if new_value is None and old_value is None: return False
    if new_value is None or old_value is None: return True
    if type(new_value) != type(old_value): return True
    if isinstance(new_value, (dict, list)): return json.dumps(new_value, sort_keys=True) != json.dumps(old_value, sort_keys=True)
    return new_value != old_value

def serialize_field(fid: int, value: Any) -> Optional[bytes]:
    w = Writer()
    if fid in (1, 3, 5): w.write_string(value); return w.to_bytes()
    if fid in (2, 4): w.write_int(value or 0); return w.to_bytes()
    if fid == 9:
        friends = value or []
        w._p.append(struct.pack("<i", len(friends)))
        for friend in friends: w.write_byte(3); w.write_string(friend.get("id", "")); w.write_string(friend.get("Name", "")); w.write_string(friend.get("accountID", ""))
        return w.to_bytes()
    if fid in INT_LIST_FIELDS: w.write_list(value or [], w.write_int); return w.to_bytes()
    if fid in FLOAT_LIST_FIELDS: w.write_list(value or [], w.write_float); return w.to_bytes()
    if fid in (41, 42): w.write_equipment(value); return w.to_bytes()
    if fid == 43: w.write_plates(value); return w.to_bytes()
    if fid == 44: w.write_car_id_status(value); return w.to_bytes()
    if fid == 45:
        w._p.append(struct.pack("<i", len(value or {})))
        for key, val in (value or {}).items(): w.write_int(int(key)); w.write_int(int(val))
        return w.to_bytes()
    return None

def build_payload(record: Dict[str, Any], uid: str, original: Optional[Dict[str, Any]] = None, force_fields: Optional[set] = None) -> str:
    force_fields = set(force_fields or [])
    fields = []
    for fid, key in FIELD_MAPPING:
        value = record.get(key)
        if value is None: continue
        if key == "allData": should_send = isinstance(value, str) and len(value) > 0
        elif key in force_fields: should_send = True
        elif original is not None: should_send = _field_modified(value, original.get(key))
        else: should_send = True
        if not should_send: continue
        raw = serialize_field(fid, value)
        if raw is not None: fields.append((fid, raw))
    parts = [struct.pack("<i", len(fields))]
    for fid, raw in fields: parts.extend([struct.pack("<hi", fid, len(raw)), raw])
    combined = b"".join(parts)
    compressed = brotli.compress(combined) if HAS_BROTLI else zlib.compress(combined)
    encrypted = xor_bytes(compressed, make_xor_key(uid))
    return base64.b64encode(encrypted).decode("ascii")

class SyncCPMNuker:
    def __init__(self):
        self.cache = {}

    def _ck(self, uid: int, email: Optional[str] = None) -> str:
        td = self.get_token_data(uid)
        return f"{uid}_{email or (td.get('email') if td else '')}"

    def save_token(self, uid: int, auth: str, email: str, pw: Optional[str] = None, rt: Optional[str] = None, fuid: Optional[str] = None):
        if USE_MONGO:
            try:
                tokens_col.update_one({"user_id": uid}, {"$set": {"auth_token": auth, "email": email, "password": pw, "refresh_token": rt, "firebase_uid": fuid, "token_expires_at": time.time() + 3600}}, upsert=True)
            except: pass
        else:
            with sqlite3.connect(db_path) as c:
                c.execute("INSERT OR REPLACE INTO tokens (user_id, auth_token, email, password, refresh_token, firebase_uid, token_expires_at) VALUES (?, ?, ?, ?, ?, ?, ?)", (uid, auth, email, pw, rt, fuid, time.time() + 3600))
                c.commit()

    def get_token_data(self, uid: int) -> Optional[Dict[str, Any]]:
        if USE_MONGO:
            try:
                row = tokens_col.find_one({"user_id": uid})
                if not row: return None
                return row
            except: return None
        else:
            with sqlite3.connect(db_path) as c:
                row = c.execute("SELECT auth_token, email, password, refresh_token, firebase_uid, token_expires_at FROM tokens WHERE user_id=?", (uid,)).fetchone()
            if not row: return None
            return {"auth_token": row[0], "email": row[1], "password": row[2], "refresh_token": row[3], "firebase_uid": row[4], "token_expires_at": row[5]}

    def update_token(self, uid: int, auth: str, rt: Optional[str] = None):
        if USE_MONGO:
            try:
                update_data = {"auth_token": auth, "token_expires_at": time.time() + 3600}
                if rt: update_data["refresh_token"] = rt
                tokens_col.update_one({"user_id": uid}, {"$set": update_data})
            except: pass
        else:
            with sqlite3.connect(db_path) as c:
                if rt: c.execute("UPDATE tokens SET auth_token=?, refresh_token=?, token_expires_at=? WHERE user_id=?", (auth, rt, time.time() + 3600, uid))
                else: c.execute("UPDATE tokens SET auth_token=?, token_expires_at=? WHERE user_id=?", (auth, time.time() + 3600, uid))
                c.commit()

    def delete_token(self, uid: int):
        if USE_MONGO:
            try: tokens_col.delete_one({"user_id": uid})
            except: pass
        else:
            with sqlite3.connect(db_path) as c:
                c.execute("DELETE FROM tokens WHERE user_id=?", (uid,))
                c.commit()
        for key in list(self.cache.keys()):
            if key.startswith(str(uid)): del self.cache[key]

    def is_expired(self, uid: int) -> bool:
        td = self.get_token_data(uid)
        return not td or not td.get("token_expires_at") or td.get("token_expires_at") < time.time()

    def get_record(self, uid: int, email: Optional[str] = None) -> Dict[str, Any]:
        ck = self._ck(uid, email)
        if ck not in self.cache:
            if USE_MONGO:
                try:
                    doc = user_data_col.find_one({"cache_key": ck})
                    if doc and "data_json" in doc: self.cache[ck] = json.loads(doc["data_json"])
                except: pass
            else:
                with sqlite3.connect(db_path) as c:
                    row = c.execute("SELECT data_json FROM user_data WHERE cache_key=?", (ck,)).fetchone()
                if row:
                    try: self.cache[ck] = json.loads(row[0])
                    except: pass
        return self.cache.get(ck, {})

    def set_record(self, uid: int, data: Dict[str, Any], email: Optional[str] = None):
        ck = self._ck(uid, email)
        self.cache[ck] = data
        if USE_MONGO:
            try:
                user_data_col.update_one({"cache_key": ck}, {"$set": {"email": email, "data_json": json.dumps(data), "saved_at": datetime.now()}}, upsert=True)
            except: pass
        else:
            with sqlite3.connect(db_path) as c:
                c.execute("INSERT OR REPLACE INTO user_data (cache_key, email, data_json) VALUES (?, ?, ?)", (ck, email, json.dumps(data)))
                c.commit()

    def _post(self, url: str, payload: Dict[str, Any], headers: Dict[str, str], *, retries: Optional[int] = None) -> Dict[str, Any]:
        secondary_endpoint = url in {LOAD_URL, SAVE_URL, RANK_URL}
        try:
            clean_headers = {k: v for k, v in headers.items() if k.lower() != "host"}
            if secondary_endpoint:
                retries = 0
            request_options = {"timeout": REQUEST_TIMEOUT_SECONDS}
            if retries is not None:
                request_options["retries"] = retries
            resp = direct_request(
                "post",
                url,
                json=payload,
                headers=clean_headers,
                **request_options,
            )
            if secondary_endpoint and resp.status_code != 200:
                LOGGER.warning(
                    "Secondary API request failed: %s returned HTTP %d",
                    url,
                    resp.status_code,
                )
            try:
                result = resp.json()
                if not isinstance(result, dict):
                    result = {"result": result}
            except ValueError:
                result = {"raw": resp.text}
            result["_http_status"] = resp.status_code
            return result
        except requests.RequestException as e:
            if secondary_endpoint:
                LOGGER.warning(
                    "Secondary API request failed: %s (%s)",
                    url,
                    type(e).__name__,
                )
            return {"ok": False, "message": f"CONNECTION FAILED: {str(e)[:120]}"}
        except Exception as e:
            if not secondary_endpoint:
                raise
            LOGGER.warning(
                "Secondary API request failed: %s (%s)",
                url,
                type(e).__name__,
            )
            return {"ok": False, "message": f"REQUEST FAILED: {type(e).__name__}"}

    def login(self, email: str, password: str, *, retries: Optional[int] = None) -> Dict[str, Any]:
        url = f"https://identitytoolkit.googleapis.com/v1/accounts:signInWithPassword?key={FK}"
        payload = {"email": email, "password": password, "returnSecureToken": True, "clientType": "CLIENT_TYPE_ANDROID"}
        result = self._post(url, payload, GAME_HEADERS, retries=retries)
        if result.get("ok") is False: return result
        if "idToken" in result: return {"ok": True, "message": "OK", "auth": result["idToken"], "refresh_token": result.get("refreshToken", ""), "firebase_uid": result.get("localId", "")}
        err = "INVALID_CREDENTIALS"
        try:
            if isinstance(result.get("error"), dict): err = str(result["error"].get("message", "INVALID_CREDENTIALS"))
            elif isinstance(result.get("error"), str): err = result["error"]
        except: pass
        return {"ok": False, "message": err.upper()[:80]}

    def register(self, email: str, password: str) -> Dict[str, Any]:
        email = (email or "").strip()
        password = password or ""
        if not email or "@" not in email or "." not in email.split("@")[-1]:
            return {"ok": False, "message": "INVALID_EMAIL"}
        if len(password) < 6:
            return {"ok": False, "message": "WEAK_PASSWORD (min 6 chars)"}
        url = f"https://identitytoolkit.googleapis.com/v1/accounts:signUp?key={FK}"
        payload = {
            "email": email,
            "password": password,
            "returnSecureToken": True,
            "clientType": "CLIENT_TYPE_ANDROID",
        }
        result = self._post(url, payload, GAME_HEADERS)
        if result.get("ok") is False:
            return {"ok": False, "message": result.get("message", "CONNECTION FAILED")}
        if "idToken" in result:
            return {
                "ok": True,
                "message": "OK",
                "auth": result["idToken"],
                "refresh_token": result.get("refreshToken", ""),
                "firebase_uid": result.get("localId", ""),
            }
        err = "REGISTRATION_FAILED"
        try:
            if isinstance(result.get("error"), dict):
                err = str(result["error"].get("message", "FAILED"))
            elif isinstance(result.get("error"), str):
                err = result["error"]
        except Exception:
            pass
        el = err.upper()
        if "EMAIL_EXISTS" in el:
            err = "EMAIL_EXISTS — use Login"
        elif "INVALID_EMAIL" in el:
            err = "INVALID_EMAIL"
        elif "WEAK_PASSWORD" in el:
            err = "WEAK_PASSWORD — min 6 characters"
        elif "OPERATION_NOT_ALLOWED" in el:
            err = "SIGNUP_DISABLED on Firebase"
        elif "TOO_MANY_ATTEMPTS" in el:
            err = "TOO_MANY_ATTEMPTS — try later"
        return {"ok": False, "message": err[:100]}


    def seed_blank_profile(self, auth: str, fuid: str, email: str = "") -> Dict[str, Any]:
        """Create a minimal game profile for a newly registered Firebase account.

        This method is intentionally only used when the account has no loadable
        game record. It saves the same minimal fields expected by the existing
        profile serializer and returns a structured result for the bot handlers.
        """
        if not auth or not fuid:
            return {"ok": False, "message": "MISSING_AUTH_OR_FIREBASE_UID"}
        local_id = str(random.randint(1_000_000, 99_999_999)).zfill(8)
        record = {
            "Name": "Player",
            "money": 25000,
            "coin": 0,
            "localID": local_id,
            "allData": '{"cars":[]}',
            "boughtFsos": [],
            "boughtPoliceLights": [],
            "boughtPoliceSirens": [],
            "FriendsID": [],
            "LevelsDoneTime": [],
            "floats": [0.0] * 50,
            "integers": [0] * 120,
            "favouriteWheels": [],
            "favouriteVinyls": [],
            "favouriteEmojis": [],
            "emojiPacks": [],
            "flags": {},
        }
        ok, message = self._send(auth, record, fuid, original=None)
        if ok:
            return {"ok": True, "message": "OK", "localID": local_id}
        return {"ok": False, "message": message or "PROFILE_SEED_FAILED", "localID": local_id}

    def _refresh(self, uid: int, *, retries: Optional[int] = None) -> Tuple[bool, str]:
        td = self.get_token_data(uid)
        if not td: return False, "NO_TOKEN"
        rt, em, pw = td.get("refresh_token"), td.get("email"), td.get("password")
        if rt:
            res = self._post(f"https://securetoken.googleapis.com/v1/token?key={FK}", {"grant_type": "refresh_token", "refresh_token": rt}, {"Content-Type": "application/json"}, retries=retries)
            if res.get("id_token"):
                self.update_token(uid, res["id_token"], res.get("refresh_token", rt))
                return True, "OK"
        if em and pw:
            res = self.login(em, pw, retries=retries)
            if res.get("ok"):
                self.save_token(uid, res["auth"], em, pw, res.get("refresh_token", ""), res.get("firebase_uid", ""))
                return True, "OK"
        return False, "REFRESH_FAILED"

    def get_auth(self, uid: int, *, retries: Optional[int] = None) -> Tuple[bool, str, str]:
        if self.is_expired(uid):
            ok, msg = self._refresh(uid, retries=retries)
            if not ok: return False, msg, ""
        td = self.get_token_data(uid)
        if td and td.get("auth_token"): return True, "OK", td.get("auth_token")
        return False, "NO_TOKEN", ""

    def load(self, uid: int, force: bool = False, *, retries: Optional[int] = None) -> bool:
        td = self.get_token_data(uid)
        if not td: return False
        if not force and self._ck(uid) in self.cache: return True
        ok, msg, auth = self.get_auth(uid, retries=retries)
        if not ok: return False
        res = self._post(LOAD_URL, {"data": None}, {**GAME_HEADERS, "Authorization": f"Bearer {auth}"})
        if res.get("ok") is False or not res.get("result"): return False
        dec = decrypt_player_record(res["result"], td.get("firebase_uid", ""), td.get("password", ""), td.get("email", ""))
        if dec.get("success") and dec.get("record"):
            self.set_record(uid, dec["record"], td.get("email", ""))
            return True
        return False

    def _ok(self, value: Any) -> bool:
        if value in (1, True, "1"): return True
        if value in (0, False, None, "0"): return False
        if isinstance(value, str):
            try: return self._ok(json.loads(value.strip()))
            except: return False
        if isinstance(value, dict):
            for k in ("result", "ok", "success"):
                if k in value: return self._ok(value[k])
        return False

    def _send(self, auth: str, record: Dict[str, Any], fuid: str, original: Optional[Dict[str, Any]] = None, force_fields: Optional[set] = None) -> Tuple[bool, str]:
        if not fuid: return False, "NO_FIREBASE_UID"
        try:
            payload = build_payload(record, fuid, original, force_fields=force_fields)
            res = self._post(SAVE_URL, {"data": {"data": payload, "deviceId": fuid[:8]}}, {**GAME_HEADERS, "Authorization": f"Bearer {auth}", "Connection": "Keep-Alive", "User-Agent": "Dalvik/2.1.0 (Linux; U; Android 12; Pixel 6 Build/SD1A.210817.036)"})
            if res.get("ok") is False: return False, res.get("message", "API TIMEOUT")
            if res.get("_http_status") != 200:
                return False, f"HTTP {res.get('_http_status', 'UNKNOWN')}"
            if res and self._ok(res): return True, "OK"
            return False, f"SAVE-FAILED"
        except Exception as e: return False, str(e)

    def save_currency_fields(self, uid: int, money: int, coins: int, attempts: int = 1) -> Dict[str, Any]:
        if not self.load(uid, force=True, retries=0):
            return {"ok": False, "message": "ACCOUNT LOAD FAILED."}
        td = self.get_token_data(uid)
        if not td:
            return {"ok": False, "message": "NO_TOKEN"}
        original = self.get_record(uid, td.get("email")) or {}
        if not original or original.get("Name") is None:
            return {"ok": False, "message": "PROFILE DATA CORRUPTED."}
        data = deepcopy(original)
        data["money"] = min(int(money), MAX_MONEY)
        data["coin"] = min(int(coins), MAX_COIN)
        ok, msg, auth = self.get_auth(uid, retries=0)
        if not ok:
            return {"ok": False, "message": msg}
        fuid = td.get("firebase_uid", "")
        check_account_timeout()
        ok, msg = self._send(
            auth,
            data,
            fuid,
            original=original,
            force_fields={"money", "coin"},
        )
        if ok:
            self.set_record(uid, data, td.get("email"))
            return {"ok": True, "message": "OK", "attempt": 1}
        return {"ok": False, "message": msg, "attempts": 1}

    def _save(self, uid: int, data: Dict[str, Any], force_fields: Optional[set] = None, retries: Optional[int] = None) -> Dict[str, Any]:
        ok, msg, auth = self.get_auth(uid, retries=retries)
        if not ok: return {"ok": False, "message": msg}
        td = self.get_token_data(uid)
        fuid = td.get("firebase_uid", "") if td else ""
        email = td.get("email", "") if td else ""
        original = self.get_record(uid, email) or None
        ok2, msg2 = self._send(auth, data, fuid, original, force_fields=force_fields)
        if ok2:
            self.set_record(uid, data, email)
            return {"ok": True, "message": "OK"}
        return {"ok": False, "message": msg2}

    def _modify(self, uid: int, mods: Dict[str, Any], force_fields: Optional[set] = None, retries: Optional[int] = None) -> Dict[str, Any]:
        if not self.load(uid, retries=retries): return {"ok": False, "message": "ACCOUNT LOAD FAILED. CHECK CREDENTIALS."}
        td = self.get_token_data(uid)
        data = deepcopy(self.get_record(uid, td.get("email") if td else None))
        if not data or data.get("Name") is None: return {"ok": False, "message": "PROFILE DATA CORRUPTED."}
        for k, v in mods.items():
            if k == "money": v = min(int(v), MAX_MONEY)
            if k == "coin": v = min(int(v), MAX_COIN)
            data[k] = v
        return self._save(uid, data, force_fields=set(force_fields or mods.keys()), retries=retries)

    def _set_floats(self, uid: int, indices_values: List[Tuple[int, float]]) -> Dict[str, Any]:
        if not self.load(uid): return {"ok": False, "message": "ACCOUNT LOAD FAILED."}
        td = self.get_token_data(uid)
        data = deepcopy(self.get_record(uid, td.get("email") if td else None))
        if not data or data.get("Name") is None: return {"ok": False, "message": "PROFILE DATA CORRUPTED."}
        floats = data.get("floats", [])
        max_idx = max(idx for idx, _ in indices_values)
        while len(floats) <= max_idx: floats.append(0.0)
        for idx, val in indices_values: floats[idx] = float(val)
        data["floats"] = floats
        return self._save(uid, data, force_fields={"floats"})

    def _set_integers(self, uid: int, indices_values: List[Tuple[int, int]]) -> Dict[str, Any]:
        if not self.load(uid): return {"ok": False, "message": "ACCOUNT LOAD FAILED."}
        td = self.get_token_data(uid)
        data = deepcopy(self.get_record(uid, td.get("email") if td else None))
        if not data or data.get("Name") is None: return {"ok": False, "message": "PROFILE DATA CORRUPTED."}
        integers = data.get("integers", [])
        max_idx = max(idx for idx, _ in indices_values)
        while len(integers) <= max_idx: integers.append(0)
        for idx, val in indices_values: integers[idx] = int(val)
        data["integers"] = integers
        return self._save(uid, data, force_fields={"integers"})

    def set_money(self, uid: int, amount: int) -> Dict[str, Any]: return self._modify(uid, {"money": min(int(amount), MAX_MONEY)}, force_fields={"money"})
    def set_coin(self, uid: int, amount: int) -> Dict[str, Any]: return self._modify(uid, {"coin": min(int(amount), MAX_COIN)}, force_fields={"coin"})
    
    def change_player_id(self, uid: int, new_id: str) -> Dict[str, Any]:
        if not self.load(uid, force=True): return {"ok": False, "message": "ACCOUNT LOAD FAILED."}
        td = self.get_token_data(uid)
        data = deepcopy(self.get_record(uid, td.get("email") if td else None))
        if not data or data.get("Name") is None: return {"ok": False, "message": "PROFILE DATA CORRUPTED."}
        new_id_upper = str(new_id).strip().upper()
        data["localID"] = new_id_upper
        result = self._save(uid, data, force_fields={"localID"})
        if result.get("ok"): return {"ok": True, "message": f"TAG MASKED TO {new_id_upper}", "new_id": new_id_upper}
        return {"ok": False, "message": result.get("message", "SAVE FAILED")}
        
    def change_player_name(self, uid: int, new_name: str) -> Dict[str, Any]:
        if not self.load(uid, force=True): return {"ok": False, "message": "ACCOUNT LOAD FAILED."}
        td = self.get_token_data(uid)
        data = deepcopy(self.get_record(uid, td.get("email") if td else None))
        data["Name"] = new_name
        return self._save(uid, data, force_fields={"Name"})

    def change_email(self, uid: int, new_email: str) -> Dict[str, Any]:
        """Change the email for the currently authenticated account."""
        new_email = (new_email or "").strip()
        if not new_email or "@" not in new_email or "." not in new_email.rsplit("@", 1)[-1]:
            return {"ok": False, "message": "INVALID_EMAIL"}
        td = self.get_token_data(uid)
        if not td:
            return {"ok": False, "message": "Not logged in"}
        old_email, password = td.get("email"), td.get("password")
        if not old_email or not password:
            return {"ok": False, "message": "Saved email/password missing; log in again"}
        login_result = self.login(old_email, password)
        if not login_result.get("ok"):
            return {"ok": False, "message": "LOGIN_FAILED: verify the current credentials"}
        url = f"https://identitytoolkit.googleapis.com/v1/accounts:update?key={FK}"
        result = self._post(url, {
            "idToken": login_result["auth"],
            "email": new_email,
            "returnSecureToken": True,
        }, GAME_HEADERS)
        if result.get("idToken") and result.get("email"):
            self.save_token(
                uid, result["idToken"], result.get("email", new_email), password,
                result.get("refreshToken", login_result.get("refresh_token", "")),
                result.get("localId", td.get("firebase_uid", "")),
            )
            return {"ok": True, "message": "Email changed successfully", "email": result.get("email", new_email),
                    "_auth": result.get("idToken", ""), "_refresh_token": result.get("refreshToken", ""),
                    "_firebase_uid": result.get("localId", "")}
        err = result.get("error", {})
        message = err.get("message", "EMAIL_CHANGE_FAILED") if isinstance(err, dict) else str(err or "EMAIL_CHANGE_FAILED")
        return {"ok": False, "message": str(message)[:120]}

    def change_password(self, uid: int, new_password: str) -> Dict[str, Any]:
        """Change the password for the currently authenticated account."""
        new_password = new_password or ""
        if len(new_password) < 6:
            return {"ok": False, "message": "WEAK_PASSWORD (minimum 6 characters)"}
        td = self.get_token_data(uid)
        if not td:
            return {"ok": False, "message": "Not logged in"}
        email, old_password = td.get("email"), td.get("password")
        if not email or not old_password:
            return {"ok": False, "message": "Saved email/password missing; log in again"}
        login_result = self.login(email, old_password)
        if not login_result.get("ok"):
            return {"ok": False, "message": "LOGIN_FAILED: verify the current credentials"}
        url = f"https://identitytoolkit.googleapis.com/v1/accounts:update?key={FK}"
        result = self._post(url, {
            "idToken": login_result["auth"],
            "password": new_password,
            "returnSecureToken": True,
        }, GAME_HEADERS)
        if result.get("idToken"):
            self.save_token(
                uid, result["idToken"], email, new_password,
                result.get("refreshToken", login_result.get("refresh_token", "")),
                result.get("localId", td.get("firebase_uid", "")),
            )
            return {"ok": True, "message": "Password changed successfully",
                    "_auth": result.get("idToken", ""), "_refresh_token": result.get("refreshToken", ""),
                    "_firebase_uid": result.get("localId", "")}
        err = result.get("error", {})
        message = err.get("message", "PASSWORD_CHANGE_FAILED") if isinstance(err, dict) else str(err or "PASSWORD_CHANGE_FAILED")
        return {"ok": False, "message": str(message)[:120]}

    def unlock_w16(self, uid: int) -> Dict[str, Any]: return self._set_floats(uid, [(32, 1.0)])
    def unlock_horns(self, uid: int) -> Dict[str, Any]: return self._set_floats(uid, [(27, 1.0), (28, 1.0), (29, 1.0), (30, 1.0), (31, 1.0)])
    def disable_damage(self, uid: int) -> Dict[str, Any]: return self._set_floats(uid, [(34, 1.0)])
    def unlimited_fuel(self, uid: int) -> Dict[str, Any]: return self._set_floats(uid, [(3, 1.0)])
    def unlock_smoke(self, uid: int) -> Dict[str, Any]: return self._set_floats(uid, [(33, 1.0)])
    
    def unlock_animations(self, uid: int) -> Dict[str, Any]:
        if not self.load(uid): return {"ok": False, "message": "ACCOUNT LOAD FAILED."}
        td = self.get_token_data(uid)
        data = deepcopy(self.get_record(uid, td.get("email") if td else None))
        data["animations"] = sorted(set(data.get("animations", []) + list(range(301))))
        return self._save(uid, data, force_fields={"animations"})

    def unlock_wheels(self, uid: int) -> Dict[str, Any]:
        if not self.load(uid): return {"ok": False, "message": "ACCOUNT LOAD FAILED."}
        td = self.get_token_data(uid)
        data = deepcopy(self.get_record(uid, td.get("email") if td else None))
        data["wheels"] = sorted(set(data.get("wheels", []) + list(range(73, 221))))
        integers = data.get("integers", [])
        while len(integers) < 113: integers.append(0)
        for idx in [0, 1, 2, 3, 4, 5, 110, 111, 112]: integers[idx] = 1
        data["integers"] = integers
        return self._save(uid, data, force_fields={"wheels", "integers"})

    def unlock_houses(self, uid: int) -> Dict[str, Any]: return self._set_integers(uid, [(8, 1), (110, 1), (111, 1), (112, 1)])
    def complete_all_levels(self, uid: int) -> Dict[str, Any]: return self._modify(uid, {"LevelsDoneTime": [0] + [120 if i == 43 else 1 for i in range(1, 110)]}, force_fields={"LevelsDoneTime"})

    def set_rank(self, uid: int) -> Dict[str, Any]:
        self.load(uid, retries=0)
        ok, msg, auth = self.get_auth(uid, retries=0)
        if not ok: return {"ok": True, "message": "OK"}
        rating_data = {"RatingData": {"time": 1e22, "cars": 1e16, "car_fix": 1e13, "car_collided": 1e12, "car_exchange": 1e13, "car_trade": 1e13, "car_wash": 1e13, "slicer_cut": 1e13, "drift_max": 1e14, "drift": 1e14, "cargo": 1e5, "delivery": 1e5, "race_win": 3e20, "taxi": 1e10, "levels": 10000990000, "gifts": 1e9, "fuel": 1e10, "offroad": 1e10, "speed_banner": 1e9, "reactions": 1e17, "run": 1e9, "real_estate": 1e9, "t_distance": 1e10, "treasure": 1e10, "block_post": 1e10, "push_ups": 1e12, "burnt_tire": 1e10, "passanger_distance": 1e8}}
        try: self._post(RANK_URL, {"data": json.dumps(rating_data)}, {**GAME_HEADERS, "Authorization": f"Bearer {auth}"})
        except: pass
        return {"ok": True, "message": "OK"}

    def set_rank_checked(self, uid: int, rank_data: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        check_account_timeout()
        self.load(uid, retries=0)
        check_account_timeout()
        ok, msg, auth = self.get_auth(uid, retries=0)
        if not ok:
            return {"ok": False, "message": msg}
        if isinstance(rank_data, dict):
            payload_data = rank_data if "RatingData" in rank_data else {"RatingData": rank_data}
        else:
            payload_data = {"RatingData": {"time": 1e22, "cars": 1e16, "car_fix": 1e13, "car_collided": 1e12, "car_exchange": 1e13, "car_trade": 1e13, "car_wash": 1e13, "slicer_cut": 1e13, "drift_max": 1e14, "drift": 1e14, "cargo": 1e5, "delivery": 1e5, "race_win": 3e20, "taxi": 1e10, "levels": 10000990000, "gifts": 1e9, "fuel": 1e10, "offroad": 1e10, "speed_banner": 1e9, "reactions": 1e17, "run": 1e9, "real_estate": 1e9, "t_distance": 1e10, "treasure": 1e10, "block_post": 1e10, "push_ups": 1e12, "burnt_tire": 1e10, "passanger_distance": 1e8}}
        try:
            result = self._post(
                RANK_URL,
                {"data": json.dumps(payload_data)},
                {**GAME_HEADERS, "Authorization": f"******"},
                retries=0,
            )
            if result.get("_http_status") == 200 and result.get("ok") is not False:
                return {"ok": True, "message": "OK"}
            return {"ok": False, "message": f"HTTP {result.get('_http_status', 'UNKNOWN')}"}
        except AccountTimeoutError:
            raise
        except Exception as exc:
            return {"ok": False, "message": str(exc)[:120]}

    def _normalize_equipment(self, equipment: Dict[str, Any], gender: int) -> Dict[str, Any]:
        list_fields = ["hair", "face", "beard", "cap", "mask", "top", "gloves", "bag", "pants", "shoes", "glasses", "SelectedEquipments"]
        normalized = {key: [int(v) for v in (equipment.get(key, []) if isinstance(equipment, dict) else [])] for key in list_fields}
        normalized["Gender"] = int(gender)
        return normalized

    def unlock_all_clothes(self, uid: int) -> Dict[str, Any]:
        if not self.load(uid, force=True): return {"ok": False, "message": "ACCOUNT LOAD FAILED."}
        td = self.get_token_data(uid)
        data = deepcopy(self.get_record(uid, td.get("email") if td else None))
        
        eq_male = {"Gender": 0, "bag": list(range(101)), "beard": list(range(6, 21)) + [100], "cap": list(range(3, 64)), "face": [0, 1, 2, 100], "glasses": list(range(10)) + [100], "gloves": list(range(6)) + [100], "hair": list(range(3, 20)) + [100], "mask": list(range(3, 9)) + [100], "pants": list(range(26)), "shoes": list(range(31)), "top": list(range(2, 109)), "SelectedEquipments": [-1, 10, 19, 41, 100, 4, 20, 9, 22, 21, 74]}
        eq_female = {"Gender": 1, "bag": list(range(6)), "beard": [], "cap": list(range(3, 41)), "face": [0], "glasses": list(range(10)), "gloves": [1], "hair": [0, 7, 8, 9, 10], "mask": list(range(3, 8)), "pants": list(range(12)), "shoes": list(range(3, 15)), "top": list(range(5, 80)), "SelectedEquipments": [0, 0, -1, -1, -1, -1, -1, -1, 0, -1, -1]}
        
        data["personEquipmentsMale"] = self._normalize_equipment(eq_male, 0)
        data["personEquipmentsFemale"] = self._normalize_equipment(eq_female, 1)
        
        return self._save(uid, data, force_fields={"personEquipmentsMale", "personEquipmentsFemale"})

    def unlock_all_features(self, uid: int) -> Dict[str, Any]:
        feature_calls = [("W16 Engine", self.unlock_w16), ("Horns", self.unlock_horns), ("No Damage", self.disable_damage), ("Unlimited Fuel", self.unlimited_fuel), ("Smoke", self.unlock_smoke), ("Animations", self.unlock_animations), ("Wheels", self.unlock_wheels), ("Houses", self.unlock_houses), ("All Levels", self.complete_all_levels), ("Max Rank", self.set_rank)]
        if not self.load(uid, force=True): return {"ok": False, "message": "ACCOUNT LOAD FAILED."}
        results, failed = [], []
        for name, fn in feature_calls:
            res = fn(uid)
            if res.get("ok"): results.append(name)
            else: failed.append(f"{name}: {res.get('message', 'Failed')}")
        return {"ok": not failed, "message": f"Unlocked {len(results)}/{len(feature_calls)} features"}
        
    def fix_account(self, uid: int) -> Dict[str, Any]:
        if not self.load(uid, force=True): return {"ok": False, "message": "ACCOUNT LOAD FAILED."}
        td = self.get_token_data(uid)
        data = deepcopy(self.get_record(uid, td.get("email") if td else None))
        if data.get("money", 0) > MAX_MONEY: data["money"] = MAX_MONEY
        if data.get("coin", 0) > MAX_COIN: data["coin"] = MAX_COIN
        flags = data.get("flags", {})
        if isinstance(flags, dict):
            for bad_flag in [0, 1, 2, "0", "1", "2"]:
                flags.pop(bad_flag, None)
            data["flags"] = flags
        return self._save(uid, data, force_fields={"money", "coin", "flags"})

    def get_account_info(self, uid: int, force_refresh: bool = False) -> Dict[str, Any]:
        if not self.load(uid, force=force_refresh): return {"ok": False}
        td = self.get_token_data(uid)
        if not td: return {"ok": False}
        data = self.get_record(uid, td.get("email"))
        if not data or data.get("Name") is None: return {"ok": False}
        
        cars_count = 0
        try:
            c_status = data.get('carIDnStatus')
            if isinstance(c_status, dict):
                c_list = c_status.get('carStatus', [])
                if isinstance(c_list, list): cars_count = len(c_list)
        except: pass

        if cars_count == 0:
            try:
                ad = data.get('allData', '{}')
                if isinstance(ad, str):
                    ad_json = json.loads(ad)
                    if isinstance(ad_json, dict):
                        cars_count = len(ad_json.get('cars', []))
            except: pass
        
        return {"ok": True, "name": data.get("Name", "Unknown"), "money": data.get("money", 0), "coin": data.get("coin", 0), "localID": data.get("localID", "Unknown"), "email": td.get("email"), "cars": cars_count}

nuker = SyncCPMNuker()


# ---- Integrated clone and bulk-clone functionality (merged from cpm1_clone.py) ----
from concurrent.futures import ThreadPoolExecutor, as_completed
from threading import Lock
import uuid, re, struct, base64, zlib
# Clone helpers extracted from MARKCPM1TOOLS
import threading, time, json, html, random, string, uuid, re, struct, base64, zlib
try:
    import brotli
except ImportError:
    brotli = None
from typing import Any, Dict, List, Optional
import math
import time

# Parallel cloning
CLONE_WORKERS = 10          # maximum concurrent bulk account workers
CAR_CLONE_WORKERS = 1       # one car worker
BULK_CLONE_LIMIT_USER = 35
BULK_CLONE_LIMIT_ADMIN = 3500

# Configure these only through environment variables; never store live credentials in source code.
SOURCE_ACCOUNT = (os.getenv('CPM_SOURCE_EMAIL', '').strip(), os.getenv('CPM_SOURCE_PASSWORD', ''))
# Number plates deliberately use a separate source account from car injection.
PLATE_SOURCE_ACCOUNT = (os.getenv('CPM_PLATE_SOURCE_EMAIL', '').strip(), os.getenv('CPM_PLATE_SOURCE_PASSWORD', ''))
CPM_CARS_FETCH_URL = "https://europe-west1-cp-multiplayer.cloudfunctions.net/GetAllCars2"
CPM_CARS_SAVE_URL = "https://europe-west1-cp-multiplayer.cloudfunctions.net/SaveCarsPartially8"

CPM_FIELD_NAMES = {
    1: 'CarID', 2: 'dataVersion', 3: 'vectors', 4: 'floats', 5: 'gears',
    6: 'typeToInstall', 7: 'BoughtParts', 8: 'texts', 9: 'flagID',
    10: 'fsoData', 11: 'installedPoliceLights', 12: 'Vynils', 13: 'WindowVinyls',
}

def cpm1_ios_headers(token):
    return {
        'accept': '*/*',
        'authorization': f'Bearer {token}',
        'content-type': 'application/json; charset=utf-8',
        'user-agent': 'CarParking/265 CFNetwork/3860.600.12 Darwin/25.5.0',
        'x-client-platform': 'IOS',
        'x-client-version': '4.9.10',
        'x-client-deviceid': str(uuid.uuid4()).upper(),
        'x-request-nonce': str(uuid.uuid4()),
        'x-unity-version': '2022.3.62f2',
        'accept-encoding': 'gzip',
        'connection': 'Keep-Alive',
    }

def cpm1_write_memorypack_string(s):
    if s is None or s == "": return struct.pack("<i", 0)
    sb = str(s).encode("utf-8")
    return struct.pack("<ii", -len(sb) - 1, len(sb)) + sb

def cpm1_looks_like_base64(val):
    if not isinstance(val, str): return False
    if len(val) < 4 or len(val) % 4 != 0: return False
    return bool(re.match(r'^[A-Za-z0-9+/]+={0,2}$', val))

def cpm1_deserialize_string_list(b64):
    if not b64 or not isinstance(b64, str): return []
    try: compressed = base64.b64decode(b64)
    except: return []
    try: decompressed = brotli.decompress(compressed)
    except:
        try: decompressed = zlib.decompress(compressed, zlib.MAX_WBITS | 16)
        except: decompressed = compressed
    if not decompressed or len(decompressed) < 4: return []
    out = []
    pos = 0
    count = struct.unpack_from("<i", decompressed, 0)[0]
    pos = 4
    if count <= 0 or count > 100000: return []
    for _ in range(count):
        if pos + 4 > len(decompressed): break
        marker = struct.unpack_from("<i", decompressed, pos)[0]
        pos += 4
        if marker == 0:
            out.append("")
            continue
        if marker == -1: break
        if marker < -1:
            byte_len = -marker - 1
            if pos + 4 > len(decompressed): break
            pos += 4
        else:
            byte_len = marker
        if pos + byte_len > len(decompressed): break
        s = decompressed[pos:pos+byte_len].decode("utf-8", errors="replace")
        pos += byte_len
        out.append(s.replace("\x00", "").strip())
    return out

def cpm1_decode_car_array(value, kind):
    """Decode CPM's base64+Brotli packed numeric arrays returned by GetAllCars2."""
    if isinstance(value, list):
        return value[:]
    if value is None:
        return []
    if not isinstance(value, str) or not cpm1_looks_like_base64(value):
        raise ValueError("unsupported encoded car field")
    packed = base64.b64decode(value, validate=True)
    try:
        raw = brotli.decompress(packed) if brotli else zlib.decompress(packed)
    except Exception:
        raw = zlib.decompress(packed)
    if len(raw) < 4:
        raise ValueError("packed car field is truncated")
    count = struct.unpack_from("<i", raw, 0)[0]
    if count < 0 or count > 10000:
        raise ValueError("packed car field has invalid item count")
    if kind == "vectors":
        stride = 12
        if len(raw) != 4 + count * stride:
            raise ValueError("packed vector field length does not match count")
        return [dict(zip(("x", "y", "z"), struct.unpack_from("<fff", raw, 4 + i * stride))) for i in range(count)]
    if kind == "floats":
        stride = 4
        if len(raw) != 4 + count * stride:
            raise ValueError("packed float field length does not match count")
        return [struct.unpack_from("<f", raw, 4 + i * stride)[0] for i in range(count)]
    if kind == "ints":
        stride = 4
        if len(raw) != 4 + count * stride:
            raise ValueError("packed int field length does not match count")
        return [struct.unpack_from("<i", raw, 4 + i * stride)[0] for i in range(count)]
    raise ValueError("unsupported car array kind")


def cpm1_decode_car_field(car, field):
    """Decode one packed CPM numeric field in-place on a copied car object."""
    kinds = {
        "vectors": "vectors", "floats": "floats", "gears": "floats",
        "typeToInstall": "ints", "BoughtParts": "ints", "fsoData": "ints",
        "installedPoliceLights": "ints",
    }
    if field not in kinds:
        raise ValueError("unsupported car field: %s" % field)
    car[field] = cpm1_decode_car_array(car.get(field), kinds[field])
    return car[field]


def cpm1_is_readonly_cpm_id(v):
    if not isinstance(v, str): return False
    x = re.sub(r"\[[0-9A-Fa-f]{6}\]", "", v.strip()).upper()
    return len(x) == 8 and bool(re.match(r'^[A-Z]{2}\d{6}$', x))

def cpm1_generate_random_cpm_id():
    L = string.ascii_uppercase
    D = string.digits
    return ''.join(random.choice(L) for _ in range(2)) + ''.join(random.choice(D) for _ in range(6))

def cpm1_resolve_cpm_id(record):
    val = (record or {}).get("localID")
    if not val or not cpm1_is_readonly_cpm_id(val): val = cpm1_generate_random_cpm_id()
    return re.sub(r"\[[0-9A-Fa-f]{6}\]", "", str(val).strip()).upper()

def cpm1_generated_id_from_car(car):
    for k in ("generatedID", "generatedId", "carGeneratedID", "carGeneratedId"):
        v = car.get(k)
        if v and isinstance(v, str): return v
    texts = car.get("texts")
    if isinstance(texts, str):
        try: texts = cpm1_deserialize_string_list(texts)
        except: texts = []
    if isinstance(texts, list):
        for v in texts:
            if v and isinstance(v, str) and '_' in v and re.search(r'\d', v): return v
    return None

def cpm1_merge_cars_by_id(*car_lists):
    merged = {}
    for lst in car_lists:
        if not isinstance(lst, list): continue
        for car in lst:
            if not isinstance(car, dict): continue
            try: cid = int(car.get("CarID"))
            except: continue
            if cid < 0: continue
            merged[cid] = car
    return [merged[k] for k in sorted(merged.keys())]

def cpm1_replace_uid_in_value(value, src_uid, tgt_uid):
    if not src_uid or src_uid == tgt_uid: return value
    if isinstance(value, str):
        if cpm1_looks_like_base64(value): return value
        return value.replace(str(src_uid), str(tgt_uid))
    if isinstance(value, list): return [cpm1_replace_uid_in_value(v, src_uid, tgt_uid) for v in value]
    if isinstance(value, dict): return {k: cpm1_replace_uid_in_value(v, src_uid, tgt_uid) for k, v in value.items()}
    return value


def cpm1_normalize_car_physics(car):
    """Stop flying / fling / chrome-tint after clone or unlock.
    - NaN/Inf -> 0
    - Clamp absurd floats (suspension / height)
    - Soft-clamp vectors (keep normal paint 0..1)
    - Force near-ground if Y offset absurd
    - Preserve vinyl colors as uint32
    - Do NOT force floats[0] (siren) here — separate path
    """
    if not isinstance(car, dict):
        return car

    floats = car.get("floats")
    if isinstance(floats, list):
        out = []
        for i, v in enumerate(floats):
            try:
                f = float(v)
            except Exception:
                f = 0.0
            if math.isnan(f) or math.isinf(f):
                f = 0.0
            if abs(f) > 1e4:
                f = max(-1e4, min(1e4, f))
            out.append(f)
        # ride height / suspension-ish indices — keep modest
        for idx in (5, 6, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 35, 36, 37, 38, 39, 43):
            if idx < len(out):
                if abs(out[idx]) > 80:
                    out[idx] = max(-20.0, min(20.0, out[idx]))
        # mileage-ish index 19 sometimes huge → clamp
        if len(out) > 19 and abs(out[19]) > 1e6:
            out[19] = 0.0
        car["floats"] = out

    gears = car.get("gears")
    if isinstance(gears, list):
        gout = []
        for v in gears:
            try:
                f = float(v)
            except Exception:
                f = -10.0
            if math.isnan(f) or math.isinf(f):
                f = -10.0
            if abs(f) > 50:
                f = max(-50.0, min(50.0, f))
            gout.append(f)
        car["gears"] = gout

    vectors = car.get("vectors")
    if isinstance(vectors, list):
        vout = []
        for idx, vec in enumerate(vectors):
            if not isinstance(vec, dict):
                vout.append({"x": 0.0, "y": 0.0, "z": 0.0})
                continue
            try:
                x = float(vec.get("x") if vec.get("x") is not None else 0)
            except Exception:
                x = 0.0
            try:
                y = float(vec.get("y") if vec.get("y") is not None else 0)
            except Exception:
                y = 0.0
            try:
                z = float(vec.get("z") if vec.get("z") is not None else 0)
            except Exception:
                z = 0.0
            if math.isnan(x) or math.isinf(x):
                x = 0.0
            if math.isnan(y) or math.isinf(y):
                y = 0.0
            if math.isnan(z) or math.isinf(z):
                z = 0.0

            def soft(v, paint_ok=True):
                # normal paint / small scale
                if abs(v) <= 5.0:
                    return v
                if abs(v) > 200:
                    return max(-30.0, min(30.0, v))
                if abs(v) > 50:
                    return max(-15.0, min(15.0, v))
                return v

            # first few vectors often position/scale — harder clamp on Y (flying)
            if idx <= 2 and abs(y) > 10:
                y = max(-2.0, min(2.0, y))
            x, y, z = soft(x), soft(y), soft(z)
            vout.append({"x": x, "y": y, "z": z})
        car["vectors"] = vout

    # --- vynils: keep colors / packedData exact ---
    vyn = car.get("Vynils")
    if isinstance(vyn, dict) and isinstance(vyn.get("allVynils"), list):
        fixed = []
        for vinyl in vyn["allVynils"]:
            if not isinstance(vinyl, dict):
                continue
            nv = dict(vinyl)
            for fn in ("position", "scaleRotation", "iconPosition"):
                vec = nv.get(fn)
                if not isinstance(vec, dict):
                    continue
                try:
                    x = float(vec.get("x") if vec.get("x") is not None else 0)
                    y = float(vec.get("y") if vec.get("y") is not None else 0)
                    z = float(vec.get("z") if vec.get("z") is not None else 0)
                except Exception:
                    x = y = z = 0.0
                for a in (x, y, z):
                    pass
                if any(math.isnan(a) or math.isinf(a) for a in (x, y, z)):
                    x = y = z = 0.0
                # absurd scale → chrome/stretch artifacts
                if abs(x) > 500:
                    x = max(-100.0, min(100.0, x))
                if abs(y) > 500:
                    y = max(-100.0, min(100.0, y))
                if abs(z) > 1e6:
                    z = max(-3600.0, min(3600.0, z))
                nv[fn] = {"x": x, "y": y, "z": z}
            # color as full uint32 (do NOT use `or 0` which is fine; avoid float loss)
            try:
                if "color" in nv and nv["color"] is not None:
                    nv["color"] = int(nv["color"]) & 0xFFFFFFFF
            except Exception:
                nv["color"] = 0
            try:
                if "packedData" in nv and nv["packedData"] is not None:
                    nv["packedData"] = int(nv["packedData"])
            except Exception:
                pass
            fixed.append(nv)
        vyn = dict(vyn)
        vyn["allVynils"] = fixed
        try:
            vyn["CarID"] = int(car.get("CarID") or vyn.get("CarID") or 0)
        except Exception:
            pass
        car["Vynils"] = vyn

    # drop non-save junk that can confuse encoder
    for junk in ("source_slot", "sourceSlot", "one_car"):
        car.pop(junk, None)
    return car


# Private legacy migration data; retained only to clean up exact old preset
# tints when importing a car. No Chrome operation or UI uses these constants.
LEGACY_TINT_PRESETS = {
    "silver": (0.85, 0.85, 0.88), "chrome": (0.92, 0.92, 0.95),
    "gold": (0.95, 0.75, 0.25), "black": (0.08, 0.08, 0.10),
    "red": (0.85, 0.12, 0.12), "blue": (0.15, 0.35, 0.95),
    "green": (0.12, 0.75, 0.35), "purple": (0.55, 0.20, 0.85),
    "pink": (0.95, 0.40, 0.70), "orange": (0.95, 0.45, 0.10),
    "white": (0.96, 0.96, 0.98), "copper": (0.80, 0.45, 0.25),
}
LEGACY_TINT_VECTOR_INDEXES = tuple(range(12))


def cpm1_restore_legacy_preset_tint(car):
    """Undo exact legacy preset tint vectors left by earlier tool versions."""
    if not isinstance(car, dict):
        return False
    value = car.get("vectors")
    if value is None:
        return False
    try:
        vectors = cpm1_decode_car_array(value, "vectors")
    except Exception:
        return False

    # Previous versions stored min(1, channel * 1.16 + 0.015) on every
    # vector in the selected part. Skip ambiguous clipped colors (e.g. white).
    legacy = {}
    ambiguous = set()
    for name, rgb in LEGACY_TINT_PRESETS.items():
        if name == "glow":
            continue
        boosted = tuple(min(1.0, channel * 1.16 + 0.015) for channel in rgb)
        if boosted in legacy and legacy[boosted] != rgb:
            ambiguous.add(boosted)
        else:
            legacy[boosted] = rgb
    groups = []
    for indexes in (LEGACY_TINT_VECTOR_INDEXES,):
        indexes = tuple(indexes)
        if indexes and indexes not in groups:
            groups.append(indexes)

    changed = False
    for indexes in groups:
        if max(indexes) >= len(vectors):
            continue
        for boosted, original in legacy.items():
            if boosted in ambiguous:
                continue
            matches = True
            for idx in indexes:
                vec = vectors[idx]
                try:
                    matches = isinstance(vec, dict) and all(
                        abs(float(vec.get(axis, 0.0)) - boosted[n]) <= 0.001
                        for n, axis in enumerate(("x", "y", "z"))
                    )
                except (TypeError, ValueError):
                    matches = False
                if not matches:
                    break
            if matches:
                for idx in indexes:
                    vectors[idx] = {"x": original[0], "y": original[1], "z": original[2]}
                changed = True
                break
    if changed:
        car["vectors"] = vectors
    return changed


def cpm1_prepare_car(stock_car, cpm_id):
    car_copy = json.loads(json.dumps(stock_car))
    car_id = int(car_copy.get("CarID") or 0)
    # strip harvest junk
    for junk in ("source_slot", "sourceSlot", "one_car", "car_id"):
        car_copy.pop(junk, None)
    if isinstance(car_copy.get("Vynils"), dict):
        car_copy["Vynils"]["CarID"] = car_id
    texts = car_copy.get("texts")
    if isinstance(texts, str):
        try: texts = cpm1_deserialize_string_list(texts)
        except: texts = []
    if not isinstance(texts, list): texts = []
    while len(texts) < 4: texts.append('')
    orig = texts[2]
    if isinstance(orig, str) and '_' in orig:
        parts = orig.split('_')
        texts[2] = f"{cpm_id}_" + "_".join(parts[1:])
    else:
        texts[2] = f"{cpm_id}_{car_id}XX000"
    car_copy["texts"] = texts
    cpm1_restore_legacy_preset_tint(car_copy)
    # physics + vinyl safety (anti flying / anti chrome)
    car_copy = cpm1_normalize_car_physics(car_copy)
    return car_copy

def cpm1_build_car_entries(cars, cpm_id):
    entries = []
    for car in cars:
        try: cid = int(car.get("CarID"))
        except: continue
        if cid < 0: continue
        gen = cpm1_generated_id_from_car(car) or f"{cpm_id}_{cid}XX000"
        entries.append([cid, gen])
    return entries

def cpm1_entries_to_sparse(car_entries):
    if not car_entries:
        return {"carGeneratedIDs": [], "carStatus": []}
    ids = []
    for e in car_entries:
        try: ids.append(int(e[0]))
        except: pass
    ids = [i for i in ids if i >= 0]
    if not ids:
        return {"carGeneratedIDs": [], "carStatus": []}
    max_id = max(ids)
    gen_ids = [''] * (max_id + 1)
    statuses = [0] * (max_id + 1)
    for e in car_entries:
        try: cid = int(e[0])
        except: continue
        if 0 <= cid <= max_id:
            gen_ids[cid] = str(e[1]) if e[1] is not None else ''
            statuses[cid] = 1
    return {"carGeneratedIDs": gen_ids, "carStatus": statuses}

def cpm1_sanitize_car_for_encoding(car):
    clean = {}
    for key, value in car.items():
        if isinstance(value, str) and cpm1_looks_like_base64(value):
            clean[key] = value
            continue
        if key == 'floats':
            arr = value if isinstance(value, list) else []
            out = []
            for v in arr:
                try: f = float(v)
                except: f = 0.0
                out.append(f)
            while len(out) < 48: out.append(0.0)
            clean[key] = out
        elif key == 'gears':
            arr = value if isinstance(value, list) else []
            out = []
            for v in arr:
                try: f = float(v)
                except: f = -10.0
                out.append(f)
            clean[key] = out
        elif key == 'vectors':
            arr = value if isinstance(value, list) else []
            out = []
            for vec in arr:
                if isinstance(vec, dict):
                    try: x = float(vec.get('x') or 0)
                    except: x = 0.0
                    try: y = float(vec.get('y') or 0)
                    except: y = 0.0
                    try: z = float(vec.get('z') or 0)
                    except: z = 0.0
                    out.append({'x': x, 'y': y, 'z': z})
                else:
                    out.append({'x': 0.0, 'y': 0.0, 'z': 0.0})
            clean[key] = out
        elif key in ('typeToInstall', 'BoughtParts', 'fsoData', 'installedPoliceLights'):
            arr = value if isinstance(value, list) else []
            out = []
            for v in arr:
                try: iv = int(v)
                except: iv = 0
                out.append(iv)
            clean[key] = out
        elif key == 'texts':
            arr = value if isinstance(value, list) else []
            clean[key] = [str(v) if v is not None else '' for v in arr]
        elif key == 'Vynils':
            if isinstance(value, dict) and isinstance(value.get('allVynils'), list):
                fc = int(value.get('_fieldCount', 2) or 2)
                if fc < 2: fc = 2
                nv = {'_fieldCount': fc, 'allVynils': [], 'CarID': int(car.get('CarID', 0) or 0)}
                if isinstance(value.get('_remainingHex'), str): nv['_remainingHex'] = value['_remainingHex']
                for vinyl in value['allVynils']:
                    if not isinstance(vinyl, dict): continue
                    cv = {'_fieldCount': int(vinyl.get('_fieldCount', 6) or 6)}
                    for fn in ('position', 'scaleRotation', 'iconPosition'):
                        vec = vinyl.get(fn) or {}
                        if not isinstance(vec, dict): vec = {}
                        try: x = float(vec.get('x') or 0)
                        except: x = 0.0
                        try: y = float(vec.get('y') or 0)
                        except: y = 0.0
                        try: z = float(vec.get('z') or 0)
                        except: z = 0.0
                        cv[fn] = {'x': x, 'y': y, 'z': z}
                    cv['text'] = str(vinyl.get('text', '') or '')
                    cv['color'] = int(vinyl['color']) & 0xFFFFFFFF if vinyl.get('color') is not None else 0
                    cv['packedData'] = int(vinyl['packedData']) if vinyl.get('packedData') is not None else 0
                    nv['allVynils'].append(cv)
                clean[key] = nv
            else:
                clean[key] = value
        elif key == 'WindowVinyls':
            if isinstance(value, list):
                out = []
                for vinyl in value:
                    if not isinstance(vinyl, dict): continue
                    cv = {'_fieldCount': int(vinyl.get('_fieldCount', 6) or 6)}
                    for fn in ('position', 'scaleRotation', 'iconPosition'):
                        vec = vinyl.get(fn) or {}
                        if not isinstance(vec, dict): vec = {}
                        try: x = float(vec.get('x') or 0)
                        except: x = 0.0
                        try: y = float(vec.get('y') or 0)
                        except: y = 0.0
                        try: z = float(vec.get('z') or 0)
                        except: z = 0.0
                        cv[fn] = {'x': x, 'y': y, 'z': z}
                    cv['text'] = str(vinyl.get('text', '') or '')
                    cv['color'] = int(vinyl['color']) & 0xFFFFFFFF if vinyl.get('color') is not None else 0
                    cv['packedData'] = int(vinyl['packedData']) if vinyl.get('packedData') is not None else 0
                    out.append(cv)
                clean[key] = out
            else:
                clean[key] = value
        elif key in ('CarID', 'dataVersion', 'flagID'):
            try: clean[key] = int(value)
            except: clean[key] = 0
        else:
            clean[key] = value
    return clean

def cpm1_encode_field_value_binary(name, value):
    if name == 'vectors':
        if not isinstance(value, list): value = []
        buf = struct.pack("<i", len(value))
        for vec in value:
            x = float(vec.get('x') or 0) if isinstance(vec, dict) else 0.0
            y = float(vec.get('y') or 0) if isinstance(vec, dict) else 0.0
            z = float(vec.get('z') or 0) if isinstance(vec, dict) else 0.0
            buf += struct.pack("<fff", x, y, z)
        return buf
    if name in ('floats', 'gears'):
        if not isinstance(value, list): value = []
        buf = struct.pack("<i", len(value))
        for v in value:
            try: f = float(v)
            except: f = 0.0
            buf += struct.pack("<f", f)
        return buf
    if name in ('typeToInstall', 'BoughtParts', 'fsoData', 'installedPoliceLights'):
        if not isinstance(value, list): value = []
        buf = struct.pack("<i", len(value))
        for v in value:
            try: iv = int(v)
            except: iv = 0
            buf += struct.pack("<i", iv)
        return buf
    if name == 'texts':
        if not isinstance(value, list): value = []
        buf = struct.pack("<i", len(value))
        for v in value:
            buf += cpm1_write_memorypack_string(str(v) if v is not None else '')
        return buf
    if name == 'Vynils':
        if not isinstance(value, dict) or not isinstance(value.get('allVynils'), list): return b""
        fc = int(value.get('_fieldCount', 2) or 2)
        parts = [bytes([fc & 0xFF])]
        if fc == 0: return b"".join(parts)
        parts.append(struct.pack("<i", len(value['allVynils'])))
        for vinyl in value['allVynils']:
            if not isinstance(vinyl, dict):
                parts.append(bytes([0]))
                continue
            vfc = int(vinyl.get('_fieldCount', 6) or 6)
            parts.append(bytes([vfc & 0xFF]))
            if vfc == 0: continue
            for fn in ('position', 'scaleRotation', 'iconPosition'):
                vec = vinyl.get(fn) if isinstance(vinyl.get(fn), dict) else {}
                x = float(vec.get('x') or 0)
                y = float(vec.get('y') or 0)
                z = float(vec.get('z') or 0)
                parts.append(struct.pack("<fff", x, y, z))
            parts.append(cpm1_write_memorypack_string(str(vinyl.get('text', '') or '')))
            parts.append(struct.pack("<I", int(vinyl.get('color', 0) or 0) & 0xFFFFFFFF))
            try: pd = int(vinyl.get('packedData', 0) or 0)
            except: pd = 0
            parts.append(struct.pack("<q", pd))
        if fc >= 2:
            carid = value.get('CarID')
            if carid is None and isinstance(value.get('_remainingHex'), str) and value['_remainingHex']:
                try:
                    hx = bytes.fromhex(value['_remainingHex'])
                    carid = struct.unpack_from("<i", hx, 0)[0]
                except: carid = 0
            try: carid = int(carid) if carid is not None else 0
            except: carid = 0
            parts.append(struct.pack("<i", carid))
        return b"".join(parts)
    if name == 'WindowVinyls':
        if not isinstance(value, list): value = []
        parts = [struct.pack("<i", len(value))]
        for vinyl in value:
            if not isinstance(vinyl, dict):
                parts.append(bytes([0]))
                continue
            vfc = int(vinyl.get('_fieldCount', 6) or 6)
            parts.append(bytes([vfc & 0xFF]))
            if vfc == 0: continue
            for fn in ('position', 'scaleRotation', 'iconPosition'):
                vec = vinyl.get(fn) if isinstance(vinyl.get(fn), dict) else {}
                x = float(vec.get('x') or 0)
                y = float(vec.get('y') or 0)
                z = float(vec.get('z') or 0)
                parts.append(struct.pack("<fff", x, y, z))
            parts.append(cpm1_write_memorypack_string(str(vinyl.get('text', '') or '')))
            parts.append(struct.pack("<I", int(vinyl.get('color', 0) or 0) & 0xFFFFFFFF))
            try: pd = int(vinyl.get('packedData', 0) or 0)
            except: pd = 0
            parts.append(struct.pack("<q", pd))
        return b"".join(parts)
    return b""

def cpm1_encode_car_to_memorypack(car):
    fields = []
    for fid, name in CPM_FIELD_NAMES.items():
        if name in car and car[name] is not None:
            fields.append((fid, name, car[name]))
    fields.sort(key=lambda x: x[0])
    parts = [struct.pack("<i", len(fields))]
    for fid, name, value in fields:
        parts.append(struct.pack("<h", fid))
        if name in ('CarID', 'dataVersion', 'flagID'):
            try: iv = int(value)
            except: iv = 0
            parts.append(cpm1_write_memorypack_string(str(iv)))
        elif isinstance(value, str) and cpm1_looks_like_base64(value):
            parts.append(cpm1_write_memorypack_string(value))
        else:
            binv = cpm1_encode_field_value_binary(name, value)
            try: compressed = brotli.compress(binv, quality=4)
            except: compressed = brotli.compress(binv)
            parts.append(cpm1_write_memorypack_string(base64.b64encode(compressed).decode('ascii')))
    return b"".join(parts)

def cpm1_encrypt_car_for_save(car, uid, normalize=True):
    if normalize:
        car = cpm1_normalize_car_physics(car)
    else:
        car = json.loads(json.dumps(car))
    clean = cpm1_sanitize_car_for_encoding(car)
    key = make_xor_key(uid)
    mp = cpm1_encode_car_to_memorypack(clean)
    compressed = brotli.compress(mp, quality=4)
    encrypted = xor_bytes(compressed, key)
    return "__ver1__" + base64.b64encode(encrypted).decode('ascii')

def cpm1_fetch_cars_v2(token):
    """Fetch a garage without hiding API errors or mistaking malformed data for an empty garage."""
    if not token:
        return {"success": False, "error": "missing_auth_token", "cars": []}
    try:
        resp = http_session.post(
            CPM_CARS_FETCH_URL,
            json={"data": ""},
            headers=cpm1_ios_headers(token),
            timeout=20,
        )
        body = (resp.text or "").strip()
        if not 200 <= resp.status_code < 300:
            # Keep diagnostics short; never log request headers or credentials.
            safe_body = re.sub(r"\s+", " ", body)[:240]
            detail = f"HTTP {resp.status_code}" + (f" | body: {safe_body}" if safe_body else "")
            return {"success": False, "error": detail, "status": resp.status_code, "cars": []}
        try:
            parsed = resp.json() if body else None
        except Exception:
            return {"success": False, "error": "invalid_json_response", "status": resp.status_code, "cars": []}
        if isinstance(parsed, str):
            try:
                parsed = json.loads(parsed)
            except Exception:
                return {"success": False, "error": "unexpected_string_response", "status": resp.status_code, "cars": []}
        raw_result = None
        if isinstance(parsed, list):
            cars = parsed
            return {"success": True, "cars": cars}
        if isinstance(parsed, dict):
            if parsed.get("error"):
                err = parsed.get("error")
                return {"success": False, "error": f"api_error: {str(err)[:180]}", "status": resp.status_code, "cars": []}
            if parsed.get("result") is not None:
                raw_result = parsed["result"]
            elif isinstance(parsed.get("data"), dict) and parsed["data"].get("result") is not None:
                raw_result = parsed["data"]["result"]
            elif isinstance(parsed.get("data"), list):
                return {"success": True, "cars": parsed["data"]}
        if raw_result is None:
            return {"success": False, "error": "response_missing_expected_result_field", "status": resp.status_code, "cars": []}
        if isinstance(raw_result, list):
            cars = raw_result
        else:
            try:
                cars = json.loads(raw_result)
            except Exception:
                m = re.search(r'\[\s*\{[\s\S]*\}\s*\]', str(raw_result))
                if not m:
                    return {"success": False, "error": "result_not_a_car_list", "status": resp.status_code, "cars": []}
                try:
                    cars = json.loads(m.group(0))
                except Exception:
                    return {"success": False, "error": "result_json_parse_failed", "status": resp.status_code, "cars": []}
        if not isinstance(cars, list):
            return {"success": False, "error": "result_is_not_a_list", "status": resp.status_code, "cars": []}
        return {"success": True, "cars": cars, "status": resp.status_code}
    except requests.RequestException as e:
        return {"success": False, "error": f"network_error: {type(e).__name__}: {str(e)[:120]}", "cars": []}
    except Exception as e:
        return {"success": False, "error": f"fetch_error: {type(e).__name__}: {str(e)[:120]}", "cars": []}

def cpm1_save_car_encrypted_v2(token, car, uid, retries=2, normalize=True):
    try: payload = cpm1_encrypt_car_for_save(car, uid, normalize=normalize)
    except Exception as e: return {"success": False, "error": f"encode:{str(e)[:80]}"}
    headers = cpm1_ios_headers(token)
    last = {"success": False, "error": "max_retries"}
    for attempt in range(1, retries + 1):
        try:
            resp = http_session.post(CPM_CARS_SAVE_URL, json={"data": payload}, headers=headers, timeout=30)
            if resp.status_code < 300:
                body = (resp.text or "").strip()
                if not body:
                    return {"success": True, "status": resp.status_code, "data": body}
                try:
                    result_body = resp.json()
                except Exception:
                    result_body = body
                explicit_result = False
                accepted = True
                if isinstance(result_body, dict):
                    for key in ("result", "ok", "success"):
                        if key in result_body:
                            explicit_result = True
                            accepted = bool(nuker._ok(result_body))
                            break
                    if not explicit_result and result_body.get("error"):
                        explicit_result = True
                        accepted = False
                elif str(result_body).strip().lower() in ("0", "false", "failed", "error"):
                    explicit_result, accepted = True, False
                elif str(result_body).strip().lower() in ("1", "true", "ok", "success"):
                    explicit_result, accepted = True, True
                if accepted:
                    return {"success": True, "status": resp.status_code, "data": body}
                last = {"success": False, "status": resp.status_code,
                        "error": "API rejected save: %s" % body[:160], "data": body}
            elif resp.status_code in (401, 403):
                return {"success": False, "auth": True, "status": resp.status_code, "error": f"HTTP {resp.status_code}"}
            else:
                last = {"success": False, "status": resp.status_code, "error": f"HTTP {resp.status_code}"}
        except Exception as e:
            last = {"success": False, "error": str(e)[:120]}
        if attempt < retries:
            time.sleep(min(1 * attempt, 3))
    return last

def cpm1_save_car_status(auth, fuid, car_entries):
    sparse = cpm1_entries_to_sparse(car_entries)
    gen_ids = ['' if v is None else str(v) for v in sparse["carGeneratedIDs"]]
    statuses = [0 if v is None else int(v) for v in sparse["carStatus"]]
    record = {"carIDnStatus": {"carGeneratedIDs": gen_ids, "carStatus": statuses}}
    try:
        ok, msg = nuker._send(auth, record, fuid, original=None, force_fields={"carIDnStatus"})
        return {"success": bool(ok), "message": msg}
    except Exception as e:
        return {"success": False, "message": str(e)[:120]}

def cpm1_verify_car_updates(token, expected_cars, matcher, attempts=3):
    """Re-fetch the garage and verify requested in-place edits actually persisted."""
    last_error = None
    last_verified = []
    last_missing = []
    for attempt in range(max(1, int(attempts))):
        fetched = cpm1_fetch_cars_v2(token)
        if fetched.get("success"):
            by_id = _cars_by_id(fetched.get("cars") or [])
            verified, missing = [], []
            for expected in expected_cars:
                try:
                    cid = int(expected.get("CarID"))
                except Exception:
                    continue
                current = by_id.get(cid)
                if current is not None and matcher(current, expected):
                    verified.append(cid)
                else:
                    missing.append(cid)
            if len(verified) == len(expected_cars) or attempt + 1 >= max(1, int(attempts)):
                return {"success": len(verified) == len(expected_cars), "verified": verified, "missing": missing}
            last_verified, last_missing = verified, missing
        else:
            last_error = fetched.get("error") or "garage verification fetch failed"
        if attempt + 1 < max(1, int(attempts)):
            time.sleep(0.8)
    return {"success": False, "verified": last_verified, "missing": last_missing, "error": last_error}


def cpm1_verify_clone_v2(token, expected_car_ids, attempts=3):
    """Read back the garage, retrying briefly for eventual consistency."""
    expected = []
    for cid in expected_car_ids:
        try:
            expected.append(int(cid))
        except Exception:
            continue
    last_error = None
    last_present = []
    last_missing = list(expected)
    for attempt in range(max(1, int(attempts))):
        r = cpm1_fetch_cars_v2(token)
        if r.get("success"):
            present = set()
            for c in r.get("cars", []):
                try:
                    present.add(int(c.get("CarID")))
                except Exception:
                    pass
            missing = [cid for cid in expected if cid not in present]
            last_present, last_missing = sorted(present), missing
            if not missing or attempt + 1 >= max(1, int(attempts)):
                return {"success": not missing, "present": last_present, "missing": missing}
        else:
            last_error = r.get("error") or "garage fetch failed"
        if attempt + 1 < max(1, int(attempts)):
            time.sleep(min(0.8 * (attempt + 1), 2.0))
    out = {"success": False, "present": last_present, "missing": last_missing}
    if last_error:
        out["error"] = last_error
    return out

def cpm1_clone_cars_core(tgt_email, tgt_password, src_cars_to_clone, src_uid=None, tgt_token=None, tgt_uid=None, existing_tgt_cars=None, progress_cb=None, verify=True):
    result = {"success": False, "ok": 0, "fail": 0, "total": len(src_cars_to_clone), "stage": "INIT", "failed": [], "verified": None, "tgt_token": tgt_token, "tgt_uid": tgt_uid}

    if not tgt_token or not tgt_uid:
        lr = nuker.login(tgt_email, tgt_password)
        if not lr.get("ok"):
            result["stage"] = "LOGIN"
            result["error"] = lr.get("message", "login_fail")
            return result
        tgt_token, tgt_uid = lr["auth"], lr["firebase_uid"]

    if existing_tgt_cars is None:
        r = cpm1_fetch_cars_v2(tgt_token)
        if not r.get("success") and r.get("status") in (401, 403):
            lr = nuker.login(tgt_email, tgt_password)
            if lr.get("ok"):
                tgt_token, tgt_uid = lr["auth"], lr["firebase_uid"]
                r = cpm1_fetch_cars_v2(tgt_token)
        if not r.get("success"):
            result["stage"] = "FETCH_TGT"
            result["error"] = r.get("error", "fetch_fail")
            return result
        existing_tgt_cars = r["cars"]

    result["tgt_token"] = tgt_token
    result["tgt_uid"] = tgt_uid

    rec = nuker.get_record(tgt_uid, tgt_email) or {}
    cpm_id = cpm1_resolve_cpm_id(rec)
    result["cpm_id"] = cpm_id

    prepared = []
    for car in src_cars_to_clone:
        try:
            c2 = json.loads(json.dumps(car))
            if src_uid:
                c2 = cpm1_replace_uid_in_value(c2, src_uid, tgt_uid)
            prepared.append(cpm1_prepare_car(c2, cpm_id))
        except Exception as e:
            result["failed"].append({"CarID": car.get("CarID"), "stage": "PREPARE", "error": str(e)[:120]})

    if not prepared:
        result["stage"] = "PREPARE"
        result["error"] = "no_prepared"
        return result

    merged = cpm1_merge_cars_by_id(existing_tgt_cars, prepared)
    entries = cpm1_build_car_entries(merged, cpm_id)

    sr = {"success": False, "message": "status save not attempted"}
    for status_attempt in range(3):
        if status_attempt:
            time.sleep(0.75 * status_attempt)
            lr = nuker.login(tgt_email, tgt_password)
            if lr.get("ok"):
                tgt_token, tgt_uid = lr["auth"], lr["firebase_uid"]
                result["tgt_token"] = tgt_token
                result["tgt_uid"] = tgt_uid
        sr = cpm1_save_car_status(tgt_token, tgt_uid, entries)
        if sr.get("success"):
            break
    if not sr.get("success"):
        result["stage"] = "STATUS_SAVE_WARN"
        result["status_error"] = sr.get("message", "status_fail")
        # continue — car body saves can still succeed without perfect status write

    ok = 0
    total = len(prepared)
    token_lock = Lock()
    state = {"token": tgt_token, "uid": tgt_uid, "done": 0}

    def _save_one(car):
        sr = {"success": False, "error": "save not attempted"}
        for recovery in range(3):
            with token_lock:
                tok, uid_ = state["token"], state["uid"]
            sr = cpm1_save_car_encrypted_v2(tok, car, uid_, retries=3)
            if sr.get("success"):
                break
            if recovery >= 2:
                break
            if sr.get("auth"):
                lr = nuker.login(tgt_email, tgt_password)
                if lr.get("ok"):
                    with token_lock:
                        state["token"] = lr["auth"]
                        state["uid"] = lr["firebase_uid"]
                        result["tgt_token"] = state["token"]
                        result["tgt_uid"] = state["uid"]
            else:
                time.sleep(0.75 * (recovery + 1))
        with token_lock:
            state["done"] += 1
            done_n = state["done"]
        if progress_cb:
            try:
                progress_cb(done_n, total)
            except Exception:
                pass
        return car.get("CarID"), sr

    workers = max(1, min(int(CAR_CLONE_WORKERS), total, 1))
    if workers <= 1:
        # Avoid creating another thread pool inside each bulk-clone worker.
        for car in prepared:
            try:
                cid, sr = _save_one(car)
            except Exception as e:
                result["failed"].append({"CarID": car.get("CarID"), "stage": "CAR_SAVE", "error": str(e)[:120]})
                continue
            if sr.get("success"):
                ok += 1
            else:
                result["failed"].append({"CarID": cid, "stage": "CAR_SAVE", "error": sr.get("error", "unknown")})
    else:
        try:
            with ThreadPoolExecutor(max_workers=workers) as pool:
                futures = [pool.submit(_save_one, car) for car in prepared]
                for fut in as_completed(futures):
                    try:
                        cid, sr = fut.result()
                    except Exception as e:
                        result["failed"].append({"CarID": None, "stage": "CAR_SAVE", "error": str(e)[:120]})
                        continue
                    if sr.get("success"):
                        ok += 1
                    else:
                        result["failed"].append({"CarID": cid, "stage": "CAR_SAVE", "error": sr.get("error", "unknown")})
        except RuntimeError as e:
            # If the host cannot create threads, finish remaining work sequentially.
            result["failed"].append({"CarID": None, "stage": "THREAD_POOL", "error": str(e)[:120]})
            for car in prepared:
                try:
                    cid, sr = _save_one(car)
                except Exception as exc:
                    result["failed"].append({"CarID": car.get("CarID"), "stage": "CAR_SAVE", "error": str(exc)[:120]})
                    continue
                if sr.get("success"):
                    ok += 1
                else:
                    result["failed"].append({"CarID": cid, "stage": "CAR_SAVE", "error": sr.get("error", "unknown")})

    # Preserve original save errors before verification replaces the failure list
    # with a concise list of cars still missing from the garage.
    result["save_failed"] = list(result.get("failed") or [])
    tgt_token, tgt_uid = state["token"], state["uid"]
    result["tgt_token"] = tgt_token
    result["tgt_uid"] = tgt_uid
    result["stage"] = "DONE"
    result["workers"] = workers

    if verify:
        try:
            expected_ids = []
            by_id = {}
            for car in prepared:
                try:
                    cid = int(car.get("CarID"))
                    expected_ids.append(cid)
                    by_id[cid] = car
                except Exception:
                    continue
            v = cpm1_verify_clone_v2(tgt_token, expected_ids, attempts=3)
            for recovery in range(2):
                missing = set(v.get("missing") or [])
                if not missing:
                    break
                time.sleep(1.0 * (recovery + 1))
                lr = nuker.login(tgt_email, tgt_password)
                if lr.get("ok"):
                    tgt_token, tgt_uid = lr["auth"], lr["firebase_uid"]
                    result["tgt_token"], result["tgt_uid"] = tgt_token, tgt_uid
                for cid in sorted(missing):
                    car = by_id.get(cid)
                    if car is not None:
                        cpm1_save_car_encrypted_v2(tgt_token, car, tgt_uid, retries=4)
                v = cpm1_verify_clone_v2(tgt_token, expected_ids, attempts=3)
            result["verified"] = v
            prep_failed = [f for f in result["failed"] if f.get("stage") == "PREPARE"]
            remaining = set(v.get("missing") or [])
            result["failed"] = prep_failed + [
                {"CarID": cid, "stage": "VERIFY", "error": "car not present after recovery retries"}
                for cid in sorted(remaining)
            ]
            result["ok"] = len(expected_ids) - len(remaining)
        except Exception as e:
            result["verified"] = {"success": False, "error": str(e)[:80]}
            result["ok"] = ok
            result["failed"].append({"CarID": None, "stage": "VERIFY", "error": str(e)[:120]})
    else:
        result["ok"] = ok
    result["fail"] = len(result["failed"])
    result["success"] = (int(result.get("ok") or 0) >= int(result.get("total") or 0)) and not result.get("failed")

    return result

# ================================================================
#  BACKGROUND WORKERS (WITH TOKEN DEDUCTION)
# ================================================================
def _rand_gmail():
    """Generate an account email with the requested arrxcod prefix."""
    suffix = "".join(random.choice(string.ascii_lowercase + string.digits) for _ in range(random.randint(6, 10)))
    return "arrxcod" + suffix + "@gmail.com"


def _rand_password():
    """Random password letters+digits, length 10–14."""
    alphabet = string.ascii_letters + string.digits
    return "".join(random.choice(alphabet) for _ in range(random.randint(10, 14)))


def clone_task(src_record, src_cars, i, res_list, source_token, source_uid, progress_cb=None):
    reg_ok = False
    t_email = t_pass = ""
    for attempt in range(5):
        t_email = _rand_gmail()
        t_pass = _rand_password()
        try:
            r = http_session.post(f"https://identitytoolkit.googleapis.com/v1/accounts:signUp?key={FK}", json={"email": t_email, "password": t_pass, "returnSecureToken": True}, timeout=15)
            if "idToken" in r.text:
                reg_ok = True
                break
        except Exception:
            pass
        # A timed-out signup may have created the account despite losing its response.
        try:
            check = nuker.login(t_email, t_pass)
            if check.get("ok"):
                reg_ok = True
                break
        except Exception:
            pass
        time.sleep(min(0.75 * (attempt + 1), 3.0))

    if progress_cb: progress_cb(i, "registering")

    if not reg_ok:
        if res_list is not None:
            res_list.append({"success": False, "stage": "REGISTER", "error": "registration failed after retries"})
        if progress_cb: progress_cb(i, "done")
        return "", ""

    try:
        lr = nuker.login(t_email, t_pass)
        if lr.get("ok"):
            if hasattr(nuker, "seed_blank_profile"):
                nuker.seed_blank_profile(lr["auth"], lr.get("firebase_uid", ""), t_email)
            else:
                blank = {
                    "Name": "Player",
                    "money": 25000,
                    "coin": 0,
                    "localID": str(random.randint(1000000, 9999999)).zfill(8),
                    "allData": '{"cars":[]}',
                    "floats": list(src_record.get("floats") or []) if isinstance(src_record, dict) else [0.0] * 50,
                    "integers": list(src_record.get("integers") or []) if isinstance(src_record, dict) else [0] * 120,
                }
                nuker._send(lr["auth"], blank, lr["firebase_uid"])
            time.sleep(0.6)
    except Exception:
        pass

    cres = {"success": True, "ok": 0, "total": 0, "stage": "NO_CARS"}
    if src_cars:
        cres = cpm1_clone_cars_core(t_email, t_pass, src_cars, src_uid=source_uid, verify=False)
        try:
            if int(cres.get("ok") or 0) > 0:
                cres["success"] = True
        except Exception:
            pass
    if res_list is not None:
        res_list.append(cres)
    if progress_cb:
        progress_cb(i, "ok" if cres.get("success") or int(cres.get("ok") or 0) > 0 else "fail")
    return t_email, t_pass




# Full profile clone: everything except friends + player ID (localID)
IDENTITY_EXCLUDE = (
    "localID", "LocalID", "id", "ID", "playerId", "playerID",
    "email", "Email", "firebase_uid",
)
FRIEND_EXCLUDE = (
    "friends", "Friends", "friendList", "FriendList",
    "friendsData", "FriendsData", "saveFriends", "SaveFriends",
    "FriendsID", "friendsID",
)

PROFILE_CLONE_FIELDS = (
    "money", "coin",
    "floats", "integers",
    "boughtFsos", "boughtPoliceLights", "boughtPoliceSirens",
    "wheels", "animations", "emojiPacks",
    "favouriteWheels", "favouriteVinyls", "favouriteEmojis",
    "LevelsDoneTime",
    "personEquipmentsMale", "personEquipmentsFemale",
    "platesData",
    "carIDnStatus", "flags", "fcar",
    "allData",
    # Name optional — not an ID; still skip by default (include_name=True to copy)
)


def load_source_profile(src_email, src_pass):
    """Login source, load full player record + cars."""
    s = nuker.login(src_email, src_pass)
    if not s.get("ok"):
        return None, "Source login failed"
    # temporary uid for loading source into nuker cache
    src_uid_hash = abs(hash(src_email)) % (10**9)
    nuker.save_token(
        src_uid_hash, s["auth"], src_email, src_pass,
        s.get("refresh_token", ""), s.get("firebase_uid", ""),
    )
    nuker.load(src_uid_hash, force=True)
    rec = nuker.get_record(src_uid_hash, src_email) or {}
    fr = cpm1_fetch_cars_v2(s["auth"])
    cars = fr.get("cars", []) if fr.get("success") else []
    return {
        "login": s,
        "record": rec,
        "cars": cars,
        "uid_hash": src_uid_hash,
    }, "ok"


def apply_profile_to_target(tgt_email, tgt_pass, src_record, include_name=False):
    """Copy full data (money coin unlocks plates cars status rank…) except friends + localID."""
    t = nuker.login(tgt_email, tgt_pass)
    if not t.get("ok"):
        return {"ok": False, "message": "Target login failed"}
    tgt_hash = abs(hash(tgt_email + ":tgt")) % (10**9)
    nuker.save_token(
        tgt_hash, t["auth"], tgt_email, tgt_pass,
        t.get("refresh_token", ""), t.get("firebase_uid", ""),
    )
    nuker.load(tgt_hash, force=True)
    mods = {}
    force = set()
    skip = set(IDENTITY_EXCLUDE) | set(FRIEND_EXCLUDE)
    for field in PROFILE_CLONE_FIELDS:
        if field in skip:
            continue
        if field in src_record and src_record[field] is not None:
            mods[field] = src_record[field]
            force.add(field)
    # never write localID / FriendsID even if present in allData
    if "allData" in mods:
        ad = mods["allData"]
        if isinstance(ad, str):
            try:
                import json as _json
                ad_obj = _json.loads(ad)
            except Exception:
                ad_obj = None
            if isinstance(ad_obj, dict):
                for k in list(ad_obj.keys()):
                    kl = str(k).lower()
                    if "friend" in kl or kl in ("localid", "id", "playerid"):
                        ad_obj.pop(k, None)
                mods["allData"] = _json.dumps(ad_obj)
        elif isinstance(ad, dict):
            ad = dict(ad)
            for k in list(ad.keys()):
                kl = str(k).lower()
                if "friend" in kl or kl in ("localid", "id", "playerid"):
                    ad.pop(k, None)
            mods["allData"] = ad
    if include_name and src_record.get("Name"):
        mods["Name"] = src_record["Name"]
        force.add("Name")
    if "money" in mods:
        try:
            mods["money"] = min(int(mods["money"]), MAX_MONEY)
        except Exception:
            pass
    if "coin" in mods:
        try:
            mods["coin"] = min(int(mods["coin"]), MAX_COIN)
        except Exception:
            pass
    notes = []
    if mods:
        res = nuker._modify(tgt_hash, mods, force_fields=force)
        notes.append("profile:" + ("OK" if res.get("ok") else str(res.get("message", "fail"))))
    else:
        res = {"ok": False, "message": "No profile fields"}
        notes.append("profile:empty")
    # Explicit money/coin if present
    try:
        if "money" in mods:
            notes.append("money:%s" % mods.get("money"))
        if "coin" in mods:
            notes.append("coin:%s" % mods.get("coin"))
        if mods.get("personEquipmentsMale") or mods.get("personEquipmentsFemale"):
            notes.append("clothes:OK")
    except Exception:
        pass
    # King rank always
    try:
        rr = nuker.set_rank(tgt_hash)
        notes.append("rank:" + ("OK" if rr.get("ok") else "fail"))
    except Exception as e:
        notes.append("rank:" + str(e)[:40])
    # Full unlock pack (W16 fuel houses etc.)
    try:
        ur = nuker.unlock_all_features(tgt_hash)
        notes.append("unlocks:" + ("OK" if ur.get("ok") else "partial"))
    except Exception as e:
        notes.append("unlocks:" + str(e)[:40])
    rank_ok = any(n.startswith("rank:OK") for n in notes)
    unlock_ok = any(n.startswith("unlocks:OK") or n.startswith("unlocks:partial") for n in notes)
    ok = bool(res.get("ok")) or rank_ok or unlock_ok
    return {
        "ok": ok,
        "message": " · ".join(notes),
    }


def web_clone_account(src_email, src_pass, tgt_email, tgt_pass, progress_cb=None):
    """Full clone: all data except friends + localID (keeps target ID).
    progress_cb(pct:int 0-100, message:str)
    """
    def _p(pct, msg):
        if progress_cb:
            try:
                progress_cb(int(max(0, min(100, pct))), str(msg))
            except Exception:
                pass

    _p(2, "Loading source account…")
    src, msg = load_source_profile(src_email, src_pass)
    if not src:
        _p(100, "Failed: " + str(msg))
        return {"ok": False, "message": msg}
    cars = src["cars"] or []
    rec = src["record"]
    notes = []
    _p(12, "Copying profile data…")
    # 1) profile data
    pr = apply_profile_to_target(tgt_email, tgt_pass, rec, include_name=False)
    notes.append(pr.get("message", "profile"))
    # 2) cars
    if cars:
        total_cars = len(cars)
        _p(18, "Cloning cars 0/%d…" % total_cars)

        def car_progress(done, total):
            total = max(1, int(total or 1))
            done = int(done or 0)
            # cars occupy 20% → 92%
            pct = 20 + int(72 * done / total)
            _p(pct, "Cloning cars %d/%d…" % (done, total))

        res = cpm1_clone_cars_core(
            tgt_email, tgt_pass, cars,
            src_uid=src["login"].get("firebase_uid"),
            verify=True,
            progress_cb=car_progress,
        )
        notes.append(f"cars:{res.get('ok', 0)}/{res.get('total', 0)}")
        cars_ok = bool(res.get("success"))
    else:
        notes.append("cars:0")
        cars_ok = True
        res = {}
        _p(90, "No cars to clone")
    # plates count
    plates = 0
    pd = rec.get("platesData")
    if isinstance(pd, dict):
        plates = len(pd.get("allPlates") or [])
    elif isinstance(pd, list):
        plates = len(pd)
    ok = bool(pr.get("ok") and cars_ok)
    _p(100, "Clone finished" if ok else "Clone finished with errors")
    return {
        "ok": bool(ok),
        "message": f"Clone done · plates {plates} · " + " · ".join(notes),
        "detail": {"profile": pr, "cars": res},
    }


def web_bulk_clone(src_email, src_pass, count, progress_cb=None, workers=None, max_limit=None):
    """Create a batch and report per-attempt outcomes with actionable diagnostics.

    An account is marked COMPLETE only when its profile update succeeds and every
    expected car is saved/verified. Registration and worker failures are retained
    in account_details even when no credentials were returned.
    """
    try:
        lim = int(max_limit or BULK_CLONE_LIMIT_USER)
        lim = max(1, min(int(BULK_CLONE_LIMIT_ADMIN), lim))
        count = int(count)
    except (TypeError, ValueError):
        return {"ok": False, "message": "Account count must be a whole number.", "accounts": [], "account_details": []}
    if count < 1 or count > lim:
        return {"ok": False, "message": "Account count must be between 1 and %d." % lim, "accounts": [], "account_details": []}
    try:
        workers = int(workers or CLONE_WORKERS)
    except (TypeError, ValueError):
        workers = CLONE_WORKERS
    # Keep nested account/car concurrency bounded to reduce rate-limit and timeout failures.
    workers = max(1, min(workers, 10, count))  # hard cap: 10 concurrent account workers

    src, msg = load_source_profile(src_email, src_pass)
    if not src:
        return {"ok": False, "message": "Source login/profile load failed: %s" % str(msg)[:180], "accounts": [], "account_details": [], "complete_n": 0, "failed_n": count}
    cars = list(src.get("cars") or [])
    rec = src.get("record") or {}
    login = src.get("login") or {}
    src_token = login.get("auth")
    src_uid = login.get("firebase_uid")
    if not src_token or not isinstance(rec, dict) or not rec:
        return {"ok": False, "message": "Source account logged in, but its player profile could not be loaded. Check the source account and API response.", "accounts": [], "account_details": [], "complete_n": 0, "failed_n": count}

    attempts = [None] * count
    done = {"n": 0, "failed": 0}
    done_lock = Lock()
    t0 = time.time()

    def _fmt_eta(seconds):
        seconds = max(0, int(seconds))
        if seconds < 60:
            return "%ds" % seconds
        m, s = divmod(seconds, 60)
        if m < 60:
            return "%dm %ds" % (m, s)
        h, m = divmod(m, 60)
        return "%dh %dm" % (h, m)

    def _emit_progress(n, failed_n, message, pct):
        if not progress_cb:
            return
        try:
            progress_cb(n, count, message, pct)
        except TypeError:
            try:
                progress_cb(n, count, message)
            except Exception:
                pass
        except Exception:
            pass

    def _one(i):
        email = pw = ""
        clone_result = {"success": False, "stage": "REGISTER", "error": "Registration did not return a result", "ok": 0, "total": len(cars)}
        profile_result = {"ok": False, "message": "Target account was not created"}
        try:
            task_result = []
            email, pw = clone_task(rec, cars, i, task_result, src_token, src_uid)
            if task_result and isinstance(task_result[0], dict):
                clone_result = task_result[0]
            if not email or not pw:
                error = str(clone_result.get("error") or "Registration failed after retries")
                stage = str(clone_result.get("stage") or "REGISTER")
                status = {
                    "success": False, "stage": stage, "error": error[:200],
                    "cars_ok": int(clone_result.get("ok") or 0),
                    "cars_total": len(cars), "profile_ok": False,
                    "profile_msg": "Target credentials were not created",
                    "clone_stage": str(clone_result.get("stage") or "UNKNOWN"),
                    "clone_error": str(clone_result.get("error") or error)[:160],
                }
                with done_lock:
                    done["n"] += 1
                    done["failed"] += 1
                    n, failed_n = done["n"], done["failed"]
                pct = int(100 * n / max(1, count))
                elapsed = max(0.001, time.time() - t0)
                eta = (count - n) / (n / elapsed) if n else 0
                _emit_progress(n, failed_n,
                    "PROGRESS %d/%d (%d%%) · done: %d · failed: %d · ETA: %s · last: account %d failed at %s" %
                    (n, count, pct, n - failed_n, failed_n, _fmt_eta(eta), i + 1, stage), pct)
                return i, "", "", status
            else:
                for profile_attempt in range(3):
                    try:
                        profile_result = apply_profile_to_target(email, pw, rec, include_name=False)
                    except Exception as exc:
                        profile_result = {"ok": False, "message": "%s: %s" % (type(exc).__name__, str(exc)[:120])}
                    if profile_result.get("ok"):
                        break
                    if profile_attempt < 2:
                        time.sleep(0.5 * (profile_attempt + 1))
                if not profile_result.get("ok"):
                    try:
                        lr = nuker.login(email, pw)
                        if lr.get("ok") and hasattr(nuker, "seed_blank_profile"):
                            nuker.seed_blank_profile(lr["auth"], lr.get("firebase_uid", ""), email)
                            time.sleep(0.5)
                            profile_result = apply_profile_to_target(email, pw, rec, include_name=False)
                    except Exception as exc:
                        profile_result = {"ok": False, "message": "%s: %s" % (type(exc).__name__, str(exc)[:120])}
                expected = len(cars)
                cars_ok = int(clone_result.get("ok") or 0)
                cars_total = int(clone_result.get("total") if clone_result.get("total") is not None else expected)
                # A truly car-free source is valid; otherwise require every source car.
                cars_ok_enough = (expected == 0 and cars_total == 0) or (cars_total >= expected and cars_ok >= expected and bool(clone_result.get("success")))
                profile_ok = bool(profile_result.get("ok"))
                complete = bool(profile_ok and cars_ok_enough)
                if complete:
                    stage, error = "DONE", ""
                elif not profile_ok:
                    stage, error = "PROFILE", str(profile_result.get("message") or "Profile copy failed")
                elif not cars_ok_enough:
                    stage = str(clone_result.get("stage") or "CARS")
                    if stage in ("DONE", "NO_CARS", "INIT"):
                        stage = "CARS"
                    failed_cars = clone_result.get("failed") or []
                    first_error = failed_cars[0].get("error") if failed_cars and isinstance(failed_cars[0], dict) else ""
                    error = str(first_error or clone_result.get("error") or "Only %d/%d cars saved" % (cars_ok, expected))
                else:
                    stage, error = "PARTIAL", "Clone incomplete"
                status = {
                    "success": complete,
                    "stage": stage,
                    "error": str(error or "")[:200],
                    "cars_ok": cars_ok,
                    "cars_total": expected,
                    "profile_ok": profile_ok,
                    "profile_msg": str(profile_result.get("message") or "")[:160],
                    "clone_stage": str(clone_result.get("stage") or "UNKNOWN"),
                    "clone_error": str(clone_result.get("error") or clone_result.get("status_error") or "")[:160],
                }
                with done_lock:
                    done["n"] += 1
                    if not complete:
                        done["failed"] += 1
                    n, failed_n = done["n"], done["failed"]
                elapsed = max(0.001, time.time() - t0)
                eta = (count - n) / (n / elapsed) if n else 0
                pct = int(100 * n / max(1, count))
                _emit_progress(n, failed_n,
                    "CLONING PROGRESS %d/%d (%d%%)\nWorkers: %d\nCars: %d per account\nNeeds attention: %d\nETA: %s" % (n, count, pct, workers, expected, failed_n, _fmt_eta(eta)), pct)
                return i, email, pw, status
        except Exception as exc:
            error = "%s: %s" % (type(exc).__name__, str(exc)[:160])
            status = {"success": False, "stage": "WORKER", "error": error,
                      "cars_ok": int(clone_result.get("ok") or 0),
                      "cars_total": len(cars), "profile_ok": bool(profile_result.get("ok")),
                      "profile_msg": str(profile_result.get("message") or "")[:160],
                      "clone_stage": str(clone_result.get("stage") or "UNKNOWN"),
                      "clone_error": str(clone_result.get("error") or "")[:160]}
            with done_lock:
                done["n"] += 1
                done["failed"] += 1
                n, failed_n = done["n"], done["failed"]
            pct = int(100 * n / max(1, count))
            elapsed = max(0.001, time.time() - t0)
            eta = (count - n) / (n / elapsed) if n else 0
            _emit_progress(n, failed_n,
                "PROGRESS %d/%d (%d%%) · done: %d · failed: %d · ETA: %s · last: account %d failed at %s" %
                (n, count, pct, n - failed_n, failed_n, _fmt_eta(eta), i + 1, status["stage"]), pct)
            return i, email, pw, status

    def _record_attempt(idx, email, pw, status):
        credential = ("%s:%s" % (email, pw)) if email and pw else ""
        attempts[idx] = {"credentials": credential, **(status or {"success": False, "stage": "UNKNOWN", "error": "No result returned"})}

    async def _gather_attempts():
        # _one performs synchronous network I/O, so run it in a bounded thread
        # while asyncio.gather coordinates all account attempts.
        semaphore = asyncio.Semaphore(workers)
        async def _run_one(i):
            async with semaphore:
                try:
                    result = await asyncio.to_thread(_one, i)
                except Exception as exc:
                    result = (i, "", "", {"success": False, "stage": "WORKER",
                        "error": "%s: %s" % (type(exc).__name__, str(exc)[:160]),
                        "cars_ok": 0, "cars_total": len(cars), "profile_ok": False})
                return result
        return await asyncio.gather(*(_run_one(i) for i in range(count)))

    try:
        gathered = asyncio.run(_gather_attempts())
        for idx, email, pw, status in gathered:
            _record_attempt(idx, email, pw, status)
    except RuntimeError as exc:
        # Defensive fallback for environments where asyncio.run cannot start.
        _emit_progress(done["n"], done["failed"], "Async worker pool unavailable; using sequential mode: %s" % str(exc)[:100], int(100 * done["n"] / max(1, count)))
        for i in range(count):
            if attempts[i] is not None:
                continue
            try:
                idx, email, pw, status = _one(i)
            except Exception as worker_exc:
                idx, email, pw = i, "", ""
                status = {"success": False, "stage": "WORKER", "error": "%s: %s" % (type(worker_exc).__name__, str(worker_exc)[:160]), "cars_ok": 0, "cars_total": len(cars), "profile_ok": False}
            _record_attempt(idx, email, pw, status)

    account_details = []
    for index, item in enumerate(attempts):
        item = item or {"credentials": "", "success": False, "stage": "WORKER", "error": "Worker returned no result"}
        account_details.append({
            "attempt": index + 1,
            "credentials": item.get("credentials", ""),
            "complete": bool(item.get("success")),
            "stage": item.get("stage", "UNKNOWN"),
            "error": item.get("error", ""),
            "cars_ok": int(item.get("cars_ok") or 0),
            "cars_total": int(item.get("cars_total") or 0),
            "profile_ok": bool(item.get("profile_ok")),
            "profile_msg": item.get("profile_msg", ""),
            "clone_stage": item.get("clone_stage", ""),
            "clone_error": item.get("clone_error", ""),
        })
    accounts = [item["credentials"] for item in account_details if item.get("credentials")]
    complete_n = sum(1 for item in account_details if item.get("complete"))
    failed_n = count - complete_n
    total_time = _fmt_eta(time.time() - t0)
    message = "Created %d/%d accounts · full clone %d/%d complete · %d need attention (%d workers · %s)" % (len(accounts), count, complete_n, count, failed_n, workers, total_time)
    _emit_progress(count, failed_n, "DONE · " + message, 100)
    return {
        "ok": len(accounts) > 0,
        "message": message,
        "accounts": accounts,
        "account_details": account_details,
        "complete_n": complete_n,
        "failed_n": failed_n,
        "statuses": [dict(item) for item in account_details],
        "workers": workers,
        "elapsed": total_time,
    }


def set_cars_siren(cars):
    import copy
    out = []
    for car in cars:
        c = copy.deepcopy(car)
        floats = list(c.get("floats") or [])
        while len(floats) < 1:
            floats.append(0.0)
        floats[0] = 1.0
        c["floats"] = floats
        c = cpm1_normalize_car_physics(c)
        out.append(c)
    return out


# ================================================================
# UNLOCK CARS (from SOURCE_ACCOUNT → target logged-in account)
# ================================================================
def unlock_cars_to_account(tgt_email, tgt_pass, car_ids=None, progress_cb=None):
    """
    Inject cars from SOURCE_ACCOUNT into target.
    car_ids: None = all cars from source; or list/int of CarID(s).
    Applies physics normalize (no forced siren).
    """
    src_email, src_pass = SOURCE_ACCOUNT
    if not src_email or not src_pass:
        return {"ok": False, "message": "Set CPM_SOURCE_EMAIL and CPM_SOURCE_PASSWORD environment variables to use the configured source account.", "ok_n": 0, "total": 0}
    src, msg = load_source_profile(src_email, src_pass)
    if not src:
        return {"ok": False, "message": "Source login failed: %s" % msg, "ok_n": 0, "total": 0}
    cars = list(src.get("cars") or [])
    if not cars:
        return {"ok": False, "message": "Source has no cars", "ok_n": 0, "total": 0}

    if car_ids is not None:
        if isinstance(car_ids, (int, float, str)):
            want = {int(car_ids)}
        else:
            want = {int(x) for x in car_ids}
        filtered = []
        for c in cars:
            try:
                cid = int(c.get("CarID"))
            except Exception:
                continue
            if cid in want:
                filtered.append(c)
        cars = filtered
        if not cars:
            return {"ok": False, "message": "Car ID(s) not on source: %s" % sorted(want), "ok_n": 0, "total": 0}

    # For the UNLOCK feature, transfer only the car shell/configuration.
    # Do not carry custom vinyl designs or police/siren equipment from the source.
    # This is intentionally local to unlock; explicit clone/vinyl-transfer tools
    # keep their existing behavior.
    import copy
    stock_cars = []
    design_keys = {
        "vynils", "allvynils", "vinyls", "windowvinyls",
        "windowvynils", "allwindowvynils", "bodyvinyls", "windowvinyl",
    }
    for source_car in cars:
        if not isinstance(source_car, dict):
            continue
        car = copy.deepcopy(source_car)
        car_id = int(car.get("CarID") or 0)

        # Drop alternate spellings first so an alias cannot reintroduce a design.
        for key in list(car.keys()):
            if str(key).replace("_", "").lower() in design_keys:
                car.pop(key, None)

        # Keep the canonical fields in the format expected by the encoder, but empty.
        old_vinyls = source_car.get("Vynils") or source_car.get("vynils")
        field_count = 2
        if isinstance(old_vinyls, dict):
            try:
                field_count = max(2, int(old_vinyls.get("_fieldCount", 2) or 2))
            except Exception:
                field_count = 2
        car["Vynils"] = {"_fieldCount": field_count, "allVynils": [], "CarID": car_id}
        car["WindowVinyls"] = []

        # floats[0] is the CPM1 siren flag. Ensure it exists and is off.
        floats = list(car.get("floats") or [])
        if not floats:
            floats = [0.0]
        else:
            floats[0] = 0.0
        car["floats"] = floats

        # Some payloads expose police-light equipment separately from the siren flag.
        for key in list(car.keys()):
            if str(key).replace("_", "").lower() == "installedpolicelights":
                car[key] = []
        stock_cars.append(car)
    cars = stock_cars
    if not cars:
        return {"ok": False, "message": "No valid cars found to unlock", "ok_n": 0, "total": 0}

    def _p(done, total):
        if progress_cb:
            try:
                progress_cb(done, total)
            except Exception:
                pass

    res = cpm1_clone_cars_core(
        tgt_email, tgt_pass, cars,
        src_uid=src["login"].get("firebase_uid"),
        verify=True,
        progress_cb=_p,
    )
    unlocked_n = res.get("ok", 0)
    total_n = res.get("total", 0)
    message = "Cars unlocked %s/%s" % (unlocked_n, total_n)
    # Include the real failure reason in the bot response so 0/N is diagnosable.
    if not unlocked_n:
        failures = res.get("save_failed") or res.get("failed") or []
        first = failures[0] if failures else {}
        stage = first.get("stage") or res.get("stage") or "UNKNOWN"
        err = first.get("error") or res.get("error") or res.get("status_error")
        if err:
            message += " | %s: %s" % (stage, str(err)[:180])
        elif res.get("verified", {}).get("error"):
            message += " | VERIFY: %s" % str(res["verified"]["error"])[:180]
    return {
        "ok": bool(unlocked_n > 0),
        "message": message,
        "ok_n": unlocked_n,
        "total": total_n,
        "failed": res.get("save_failed") or res.get("failed") or [],
        "detail": res,
    }


def unlock_all_cars(tgt_email, tgt_pass, progress_cb=None):
    return unlock_cars_to_account(tgt_email, tgt_pass, car_ids=None, progress_cb=progress_cb)


def unlock_one_car(tgt_email, tgt_pass, car_id, progress_cb=None):
    return unlock_cars_to_account(tgt_email, tgt_pass, car_ids=car_id, progress_cb=progress_cb)


# ================================================================
# COPY VINYL / CLONE CARS / COPY PLATES
# ================================================================

def _cars_by_id(cars):
    out = {}
    for c in cars or []:
        if not isinstance(c, dict):
            continue
        try:
            raw_cid = c.get("CarID")
            if raw_cid is None:
                continue
            cid = int(raw_cid)
        except Exception:
            continue
        if cid >= 0:
            out[cid] = c
    return out


def _copy_vinyl_fields(src_car, tgt_car):
    """Copy body + window vinyl (+ related design fields) onto target car shell."""
    import copy
    out = copy.deepcopy(tgt_car) if isinstance(tgt_car, dict) else {}
    if not isinstance(src_car, dict):
        return out
    for key in (
        "Vynils", "WindowVinyls", "vynils", "windowVinyls",
        "vectors", "Vectors",
    ):
        if key in src_car and src_car[key] is not None:
            out[key] = copy.deepcopy(src_car[key])
    if "Vynils" not in out and "vynils" in out:
        out["Vynils"] = out.pop("vynils")
    if "WindowVinyls" not in out and "windowVinyls" in out:
        out["WindowVinyls"] = out.pop("windowVinyls")
    # keep target CarID / identity
    for k in ("CarID", "carGeneratedID", "UniqueID", "uniqueId"):
        if k in (tgt_car or {}):
            out[k] = tgt_car[k]
    return cpm1_normalize_car_physics(out)


def copy_car_vinyl_single(src_email, src_pass, tgt_email, tgt_pass, car_id, progress_cb=None):
    """Copy vinyl design of one CarID from source garage → target same CarID."""
    try:
        car_id = int(car_id)
    except Exception:
        return {"ok": False, "message": "Invalid car ID"}
    src, msg = load_source_profile(src_email, src_pass)
    if not src:
        return {"ok": False, "message": msg}
    tgt_lr = nuker.login(tgt_email, tgt_pass)
    if not tgt_lr.get("ok"):
        return {"ok": False, "message": "Target login failed"}
    fr = cpm1_fetch_cars_v2(tgt_lr["auth"])
    if not fr.get("success"):
        return {"ok": False, "message": "Target cars fetch failed"}
    src_map = _cars_by_id(src["cars"])
    tgt_map = _cars_by_id(fr.get("cars") or [])
    if car_id not in src_map:
        return {"ok": False, "message": "Source does not have car ID %s" % car_id}
    if car_id not in tgt_map:
        return {"ok": False, "message": "Target does not have car ID %s — unlock/clone car first" % car_id}
    merged = _copy_vinyl_fields(src_map[car_id], tgt_map[car_id])
    # rebind uid
    su = src["login"].get("firebase_uid")
    tu = tgt_lr.get("firebase_uid")
    if su and tu:
        merged = cpm1_replace_uid_in_value(merged, su, tu)
    rec = nuker.get_record(abs(hash(tgt_email)) % (10**9), tgt_email) or {}
    # load target into nuker for cpm id
    th = abs(hash(tgt_email + ":vinyl")) % (10**9)
    nuker.save_token(th, tgt_lr["auth"], tgt_email, tgt_pass, tgt_lr.get("refresh_token", ""), tu or "")
    nuker.load(th, force=True)
    rec = nuker.get_record(th, tgt_email) or {}
    cpm_id = cpm1_resolve_cpm_id(rec)
    car = cpm1_prepare_car(merged, cpm_id)
    if progress_cb:
        try:
            progress_cb(1, 1)
        except Exception:
            pass
    # ensure car status lists include this car
    try:
        fr2 = cpm1_fetch_cars_v2(tgt_lr["auth"])
        existing = fr2.get("cars") or [] if fr2.get("success") else list(tgt_map.values())
        merged_list = cpm1_merge_cars_by_id(existing, [car])
        entries = cpm1_build_car_entries(merged_list, cpm_id)
        cpm1_save_car_status(tgt_lr["auth"], tu, entries)
    except Exception:
        pass
    sr = cpm1_save_car_encrypted_v2(tgt_lr["auth"], car, tu, retries=3)
    if not sr.get("success"):
        tgt_lr = nuker.login(tgt_email, tgt_pass)
        if tgt_lr.get("ok"):
            sr = cpm1_save_car_encrypted_v2(tgt_lr["auth"], car, tgt_lr.get("firebase_uid"), retries=2)
    if sr.get("success"):
        return {"ok": True, "message": "Vinyl copied for car %s — reopen game" % car_id}
    return {"ok": False, "message": "Vinyl save failed: %s" % (sr.get("error") or sr.get("message") or "error")}


def copy_car_vinyl_all(src_email, src_pass, tgt_email, tgt_pass, progress_cb=None):
    """Copy vinyl for every CarID that exists on both source and target."""
    src, msg = load_source_profile(src_email, src_pass)
    if not src:
        return {"ok": False, "message": msg}
    tgt_lr = nuker.login(tgt_email, tgt_pass)
    if not tgt_lr.get("ok"):
        return {"ok": False, "message": "Target login failed"}
    fr = cpm1_fetch_cars_v2(tgt_lr["auth"])
    if not fr.get("success"):
        return {"ok": False, "message": "Target cars fetch failed"}
    src_map = _cars_by_id(src["cars"])
    tgt_map = _cars_by_id(fr.get("cars") or [])
    common = sorted(set(src_map) & set(tgt_map))
    if not common:
        return {"ok": False, "message": "No matching car IDs on both accounts"}
    su = src["login"].get("firebase_uid")
    tu = tgt_lr.get("firebase_uid")
    th = abs(hash(tgt_email + ":vinylall")) % (10**9)
    nuker.save_token(th, tgt_lr["auth"], tgt_email, tgt_pass, tgt_lr.get("refresh_token", ""), tu or "")
    nuker.load(th, force=True)
    rec = nuker.get_record(th, tgt_email) or {}
    cpm_id = cpm1_resolve_cpm_id(rec)
    ok = fail = 0
    total = len(common)
    token = tgt_lr["auth"]
    for i, cid in enumerate(common):
        merged = _copy_vinyl_fields(src_map[cid], tgt_map[cid])
        if su and tu:
            merged = cpm1_replace_uid_in_value(merged, su, tu)
        car = cpm1_prepare_car(merged, cpm_id)
        sr = cpm1_save_car_encrypted_v2(token, car, tu, retries=2)
        if not sr.get("success") and sr.get("auth"):
            lr = nuker.login(tgt_email, tgt_pass)
            if lr.get("ok"):
                token, tu = lr["auth"], lr.get("firebase_uid")
                sr = cpm1_save_car_encrypted_v2(token, car, tu, retries=2)
        if sr.get("success"):
            ok += 1
        else:
            fail += 1
        if progress_cb:
            try:
                progress_cb(i + 1, total)
            except Exception:
                pass
    return {
        "ok": ok > 0,
        "message": "Vinyl copied: %d ok, %d fail (matched %d cars)" % (ok, fail, total),
        "ok_n": ok,
        "fail_n": fail,
    }


def clone_single_car(src_email, src_pass, tgt_email, tgt_pass, car_id, progress_cb=None):
    """Inject one full car (body + vinyl + status) from source → target."""
    try:
        car_id = int(car_id)
    except Exception:
        return {"ok": False, "message": "Invalid car ID"}
    src, msg = load_source_profile(src_email, src_pass)
    if not src:
        return {"ok": False, "message": msg}
    src_map = _cars_by_id(src["cars"])
    if car_id not in src_map:
        return {"ok": False, "message": "Source does not have car ID %s" % car_id}
    cars = [src_map[car_id]]
    res = cpm1_clone_cars_core(
        tgt_email, tgt_pass, cars,
        src_uid=src["login"].get("firebase_uid"),
        progress_cb=progress_cb,
        verify=False,
    )
    if res.get("ok", 0) > 0 or res.get("success"):
        return {"ok": True, "message": "Car %s cloned (%s ok)" % (car_id, res.get("ok", 0))}
    return {
        "ok": False,
        "message": "Clone car failed: %s" % (res.get("error") or res.get("stage") or "error"),
    }


def clone_all_cars(src_email, src_pass, tgt_email, tgt_pass, progress_cb=None):
    """Inject all cars from source garage → target."""
    src, msg = load_source_profile(src_email, src_pass)
    if not src:
        return {"ok": False, "message": msg}
    cars = list(src["cars"] or [])
    if not cars:
        return {"ok": False, "message": "Source has 0 cars"}
    res = cpm1_clone_cars_core(
        tgt_email, tgt_pass, cars,
        src_uid=src["login"].get("firebase_uid"),
        progress_cb=progress_cb,
        verify=False,
    )
    ok_n = int(res.get("ok") or 0)
    fail_n = int(res.get("fail") or 0)
    if ok_n > 0 or res.get("success"):
        return {
            "ok": True,
            "message": "Cars cloned: %d ok, %d fail (total %d)" % (ok_n, fail_n, len(cars)),
            "ok_n": ok_n,
            "fail_n": fail_n,
        }
    return {
        "ok": False,
        "message": "Clone cars failed: %s" % (res.get("error") or res.get("stage") or "error"),
    }


def copy_plates_from_account(src_email, src_pass, tgt_email, tgt_pass):
    """Copy platesData from source account → target account."""
    src, msg = load_source_profile(src_email, src_pass)
    if not src:
        return {"ok": False, "message": msg}
    plates = src["record"].get("platesData")
    if not plates or not (isinstance(plates, dict) and plates.get("allPlates")):
        return {"ok": False, "message": "Source has no plates"}
    t = nuker.login(tgt_email, tgt_pass)
    if not t.get("ok"):
        return {"ok": False, "message": "Target login failed"}
    th = abs(hash(tgt_email + ":platescopy")) % (10**9)
    nuker.save_token(
        th, t["auth"], tgt_email, tgt_pass,
        t.get("refresh_token", ""), t.get("firebase_uid", ""),
    )
    if not nuker.load(th, force=True):
        return {"ok": False, "message": "Target load failed"}
    data = nuker.get_record(th, tgt_email)
    if not data:
        return {"ok": False, "message": "Target profile empty"}
    import copy
    data = copy.deepcopy(data)
    data["platesData"] = copy.deepcopy(plates)
    res = nuker._save(th, data, force_fields={"platesData"})
    if res.get("ok"):
        n = len(plates.get("allPlates") or [])
        return {"ok": True, "message": "Copied %d plates to target" % n}
    return {"ok": False, "message": res.get("message") or "Plate save failed"}


def inject_plates_from_source(tgt_email, tgt_pass):
    """Merge plates from the dedicated CPM_PLATE_SOURCE_* account into target.

    This source is intentionally independent of SOURCE_ACCOUNT / CPM_SOURCE_*,
    which are reserved for car injection.
    """
    src_email, src_pass = PLATE_SOURCE_ACCOUNT
    if not src_email or not src_pass:
        return {
            "ok": False,
            "message": "Set CPM_PLATE_SOURCE_EMAIL and CPM_PLATE_SOURCE_PASSWORD for the number-plate source account.",
            "copied": 0,
        }

    # Load only the player record; do not use or modify the car-source account.
    login = nuker.login(src_email, src_pass)
    if not login.get("ok"):
        return {"ok": False, "message": "Plate source login failed", "copied": 0}
    source_key = abs(hash(src_email + ":plate-source")) % (10**9)
    nuker.save_token(
        source_key, login["auth"], src_email, src_pass,
        login.get("refresh_token", ""), login.get("firebase_uid", ""),
    )
    if not nuker.load(source_key, force=True):
        return {"ok": False, "message": "Plate source profile load failed", "copied": 0}
    source_record = nuker.get_record(source_key, src_email) or {}
    source_plates = source_record.get("platesData") or {}
    source_items = source_plates.get("allPlates", []) if isinstance(source_plates, dict) else []
    if not isinstance(source_items, list) or not source_items:
        return {"ok": False, "message": "Plate source account has no number plates", "copied": 0}

    target_login = nuker.login(tgt_email, tgt_pass)
    if not target_login.get("ok"):
        return {"ok": False, "message": "Target login failed", "copied": 0}
    target_key = abs(hash(tgt_email + ":plate-inject")) % (10**9)
    nuker.save_token(
        target_key, target_login["auth"], tgt_email, tgt_pass,
        target_login.get("refresh_token", ""), target_login.get("firebase_uid", ""),
    )
    if not nuker.load(target_key, force=True):
        return {"ok": False, "message": "Target profile load failed", "copied": 0}
    target_record = nuker.get_record(target_key, tgt_email) or {}
    if not target_record:
        return {"ok": False, "message": "Target profile is empty", "copied": 0}

    import copy
    updated = copy.deepcopy(target_record)
    target_plates = updated.get("platesData")
    if not isinstance(target_plates, dict):
        target_plates = {"allPlates": []}
    existing = list(target_plates.get("allPlates") or [])
    # Use the plateId as the stable identity. Keep target plates and append only
    # source plate IDs that are not already present.
    existing_ids = {
        str(item.get("plateId"))
        for item in existing
        if isinstance(item, dict) and item.get("plateId") is not None
    }
    copied = 0
    for plate in source_items:
        if not isinstance(plate, dict):
            continue
        plate_id = plate.get("plateId")
        if plate_id is not None and str(plate_id) in existing_ids:
            continue
        existing.append(copy.deepcopy(plate))
        if plate_id is not None:
            existing_ids.add(str(plate_id))
        copied += 1

    if copied == 0:
        return {"ok": True, "message": "All source plates are already present", "copied": 0}
    target_plates["allPlates"] = existing
    updated["platesData"] = target_plates
    result = nuker._save(target_key, updated, force_fields={"platesData"})
    if result.get("ok"):
        return {"ok": True, "message": "Injected %d number plate(s)" % copied, "copied": copied}
    return {
        "ok": False,
        "message": result.get("message") or "Number-plate save failed",
        "copied": 0,
    }


# ================================================================
# BUMPER REMOVER (FRONT / REAR)
# In the inspected garage data, slots 1 and 2 are already -1. The
# active front/rear bumper selections are slots 3 and 4 (0 = stock).
# Set these selections to -1 so the game actually removes the bumpers.
# ================================================================
BUMPER_FRONT_SLOT = 3
BUMPER_REAR_SLOT = 4


def apply_bumper_remove(car, front=True, rear=True):
    """Set front/rear bumper slots to -1 (removed). Keeps other parts."""
    import copy
    if not isinstance(car, dict):
        return car
    c = copy.deepcopy(car)
    if c.get("typeToInstall") is None:
        tti = []
    else:
        tti = cpm1_decode_car_field(c, "typeToInstall")
    need = max(BUMPER_FRONT_SLOT, BUMPER_REAR_SLOT) + 1
    while len(tti) < need:
        tti.append(-2)
    if front:
        tti[BUMPER_FRONT_SLOT] = -1
    if rear:
        tti[BUMPER_REAR_SLOT] = -1
    c["typeToInstall"] = tti
    # BoughtParts is ownership inventory; leave it untouched.
    return c


def _save_modified_car_to_account(tgt_email, tgt_pass, car, progress_cb=None):
    lr = nuker.login(tgt_email, tgt_pass)
    if not lr.get("ok"):
        return {"ok": False, "message": "Login failed"}
    th = abs(hash(tgt_email + ":bumper")) % (10**9)
    nuker.save_token(
        th, lr["auth"], tgt_email, tgt_pass,
        lr.get("refresh_token", ""), lr.get("firebase_uid", ""),
    )
    nuker.load(th, force=True)
    rec = nuker.get_record(th, tgt_email) or {}
    cpm_id = cpm1_resolve_cpm_id(rec)
    prepared = car
    # update status entry for this car among garage
    fr = cpm1_fetch_cars_v2(lr["auth"])
    existing = fr.get("cars") or [] if fr.get("success") else []
    merged = cpm1_merge_cars_by_id(existing, [prepared])
    entries = cpm1_build_car_entries(merged, cpm_id)
    cpm1_save_car_status(lr["auth"], lr.get("firebase_uid"), entries)
    sr = cpm1_save_car_encrypted_v2(lr["auth"], prepared, lr.get("firebase_uid"), retries=3, normalize=False)
    if not sr.get("success"):
        lr2 = nuker.login(tgt_email, tgt_pass)
        if lr2.get("ok"):
            sr = cpm1_save_car_encrypted_v2(lr2["auth"], prepared, lr2.get("firebase_uid"), retries=2, normalize=False)
    if progress_cb:
        try:
            progress_cb(1, 1)
        except Exception:
            pass
    if sr.get("success"):
        return {"ok": True, "message": "Bumper updated on car %s" % prepared.get("CarID")}
    return {"ok": False, "message": "Save failed: %s" % (sr.get("error") or "error")}


def remove_bumper_one(tgt_email, tgt_pass, car_id, front=True, rear=True, progress_cb=None):
    try:
        car_id = int(car_id)
    except Exception:
        return {"ok": False, "message": "Invalid car ID"}
    lr = nuker.login(tgt_email, tgt_pass)
    if not lr.get("ok"):
        return {"ok": False, "message": "Login failed"}
    fr = cpm1_fetch_cars_v2(lr["auth"])
    if not fr.get("success"):
        return {"ok": False, "message": "Fetch cars failed"}
    cars = _cars_by_id(fr.get("cars") or [])
    if car_id not in cars:
        return {"ok": False, "message": "Account has no car ID %s" % car_id}
    which = []
    if front:
        which.append("FRONT")
    if rear:
        which.append("REAR")
    mod = apply_bumper_remove(cars[car_id], front=front, rear=rear)
    res = _save_modified_car_to_account(tgt_email, tgt_pass, mod, progress_cb=progress_cb)
    if res.get("ok"):
        res["message"] = "Removed %s bumper on car %s" % ("+".join(which) or "none", car_id)
    return res


def remove_bumper_all(tgt_email, tgt_pass, front=True, rear=True, progress_cb=None):
    lr = nuker.login(tgt_email, tgt_pass)
    if not lr.get("ok"):
        return {"ok": False, "message": "Login failed"}
    token, uid = lr.get("auth"), lr.get("firebase_uid")
    if not token or not uid:
        return {"ok": False, "message": "Login did not return the car-save credentials"}
    fr = cpm1_fetch_cars_v2(token)
    if not fr.get("success"):
        return {"ok": False, "message": "Fetch cars failed: %s" % (fr.get("error") or "unknown error")}
    cars = cpm1_merge_cars_by_id(fr.get("cars") or [])
    if not cars:
        return {"ok": False, "message": "No cars on account"}
    th = abs(hash(tgt_email + ":bumperall")) % (10**9)
    nuker.save_token(th, token, tgt_email, tgt_pass, lr.get("refresh_token", ""), uid)
    nuker.load(th, force=True)
    rec = nuker.get_record(th, tgt_email) or {}
    cpm_id = cpm1_resolve_cpm_id(rec)
    # Keep original generated IDs/texts: these are already owned cars, not clone imports.
    try:
        modified = [apply_bumper_remove(c, front=front, rear=rear) for c in cars]
    except Exception as exc:
        return {"ok": False, "message": "Could not decode bumper data; no cars were changed: %s" % str(exc)[:120]}
    entries = cpm1_build_car_entries(cars, cpm_id)
    status_result = cpm1_save_car_status(token, uid, entries)
    saved = failed = 0
    total = len(modified)
    for i, car in enumerate(modified):
        sr = cpm1_save_car_encrypted_v2(token, car, uid, retries=3, normalize=False)
        if not sr.get("success") and (sr.get("auth") or sr.get("status") in (401, 403)):
            lr2 = nuker.login(tgt_email, tgt_pass)
            if lr2.get("ok") and lr2.get("auth") and lr2.get("firebase_uid"):
                token, uid = lr2["auth"], lr2["firebase_uid"]
                sr = cpm1_save_car_encrypted_v2(token, car, uid, retries=3, normalize=False)
        if sr.get("success"):
            saved += 1
        else:
            failed += 1
        if progress_cb:
            try:
                progress_cb(i + 1, total)
            except Exception:
                pass
        if i + 1 < total:
            time.sleep(0.25)
    def _bumper_matches(current, _expected):
        try:
            actual = cpm1_decode_car_field(dict(current), "typeToInstall")
        except Exception:
            return current.get("typeToInstall") is None
        if not isinstance(actual, list):
            return False
        if _expected.get("typeToInstall") is None:
            return False
        return ((not front or (len(actual) > BUMPER_FRONT_SLOT and actual[BUMPER_FRONT_SLOT] == -1)) and
                (not rear or (len(actual) > BUMPER_REAR_SLOT and actual[BUMPER_REAR_SLOT] == -1)))
    verification = cpm1_verify_car_updates(token, modified, _bumper_matches)
    verified_n = len(verification.get("verified") or [])
    which = "+".join(name for flag, name in ((front, "FRONT"), (rear, "REAR")) if flag) or "NONE"
    details = "Bumper %s removed: saved %d/%d, verified %d/%d, failed %d" % (which, saved, total, verified_n, total, failed)
    if verification.get("error"):
        details += " (verification unavailable: %s)" % verification["error"]
    if not status_result.get("success"):
        details += "; garage status update: %s" % (status_result.get("message") or "failed")
    return {"ok": verified_n > 0, "message": details, "ok_n": verified_n,
            "saved_n": saved, "verified_n": verified_n, "fail_n": max(failed, total - verified_n)}


# ================================================================
