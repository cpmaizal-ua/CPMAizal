#!/usr/bin/env python3
from __future__ import annotations

import base64
import hashlib
import html
import hmac
import io
import json
import os
import re
import secrets
import sqlite3
import threading
import time
from datetime import datetime
from pathlib import Path
from urllib.parse import parse_qsl

import telebot
from telebot import types
from flask import Flask, jsonify, redirect, request  # retained for legacy API compatibility

ROOT = Path(__file__).resolve().parent
os.chdir(ROOT)

# Set BOT_TOKEN in your hosting environment. Do not keep bot tokens in source code.
BOT_TOKEN = os.environ.get("BOT_TOKEN", "9183078363:AAH3zhKvDP5pURaziHJouOjwWb4IN5BUWgc").strip()
_admin_ids_raw = os.environ.get("ADMIN_IDS", "").strip() or "7251509770"
try:
    ADMIN_IDS = {int(x.strip()) for x in _admin_ids_raw.split(",") if x.strip()}
except ValueError:
    ADMIN_IDS = {7251509770}
    print("WARNING: ADMIN_IDS contains an invalid value; using default owner ID 7251509770")
ADMIN_LOG_CHAT_ID = os.environ.get("ADMIN_LOG_CHAT_ID", "-1004370599066").strip()
WEBAPP_URL = os.environ.get("WEBAPP_URL", "https://𝘼𝙍𝙍 𝙓 𝘾𝙊𝘿miniapp-cpm1-mini-app.up.railway.app").rstrip("/")
PORT = int(os.environ.get("PORT", "8080"))
CHANNEL_USERNAME = os.environ.get("REQUIRED_CHANNEL", "@Reatcpmseller46channel").strip()
CHANNEL_USERNAME_2 = os.environ.get("REQUIRED_CHANNEL_2", "@Reatcpmseller46talk").strip()

DB = str(ROOT / "miniapp.db")
bot = telebot.TeleBot(BOT_TOKEN, parse_mode="HTML") if BOT_TOKEN else None

PLANS = {
    "7days": {
        "label": "7 Days",
        "days": 7,
        "pkr": 3.5,
        "money_label": "3.5 dollar",
    },
    "1month": {
        "label": "1 Month",
        "days": 30,
        "pkr": 6.99,
        "money_label": "6.99 dollar",
    },
    "lifetime": {
        "label": "Lifetime",
        "days": 36500000,
        "pkr": 9.99,
        "money_label": "9.99 dollar",
    },
}

# Manual payment details shown to users. EasyPaisa is the only supported manual method.
PAYMENT_DETAILS = """💚 <b>EasyPaisa</b>
👤 Account Name: Shahran
📱 Account Number: <code>03429106474</code>

✅ Send payment first.
📸 Then send the payment screenshot."""


def _money_instructions():
    return "<b>Payment Details</b>\n\n" + PAYMENT_DETAILS


def _money_instructions_plain():
    return "EasyPaisa — Shahran — 03429106474"


def db():
    c = sqlite3.connect(DB, check_same_thread=False, timeout=30)
    c.row_factory = sqlite3.Row
    return c


def init_db():
    with db() as c:
        c.execute(
            """CREATE TABLE IF NOT EXISTS users (
                tg_id INTEGER PRIMARY KEY, username TEXT, first_name TEXT, last_name TEXT,
                photo_url TEXT, sub_plan TEXT, sub_expires REAL, joined_at REAL, last_seen REAL, balance REAL NOT NULL DEFAULT 0)"""
        )
        # Upgrade existing databases without losing user/subscription data.
        user_columns = {row[1] for row in c.execute("PRAGMA table_info(users)").fetchall()}
        if "balance" not in user_columns:
            c.execute("ALTER TABLE users ADD COLUMN balance REAL NOT NULL DEFAULT 0")
        c.execute(
            """CREATE TABLE IF NOT EXISTS settings (
                key TEXT PRIMARY KEY, value TEXT)"""
        )
        c.execute(
            """CREATE TABLE IF NOT EXISTS clone_cooldown (
                tg_id INTEGER PRIMARY KEY, last_clone REAL)"""
        )
        c.execute("CREATE TABLE IF NOT EXISTS extra_admins (tg_id INTEGER PRIMARY KEY, added_by INTEGER, added_at REAL)")
        c.execute("CREATE TABLE IF NOT EXISTS blocked_users (tg_id INTEGER PRIMARY KEY, blocked_by INTEGER, blocked_at REAL, reason TEXT)")
        c.execute("CREATE TABLE IF NOT EXISTS bulk_email_access (tg_id INTEGER PRIMARY KEY, granted_by INTEGER, granted_at REAL)")
        c.execute(
            """CREATE TABLE IF NOT EXISTS redeem_codes (
                code TEXT PRIMARY KEY, plan_key TEXT NOT NULL, created_by INTEGER,
                created_at REAL NOT NULL, redeemed_by INTEGER, redeemed_at REAL)"""
        )
        c.execute(
            """CREATE TABLE IF NOT EXISTS usage_logs (
                id INTEGER PRIMARY KEY AUTOINCREMENT, tg_id INTEGER, username TEXT,
                event TEXT, account_email TEXT, created_at REAL)"""
        )
        # default free access off
        row = c.execute("SELECT value FROM settings WHERE key='free_access'").fetchone()
        if not row:
            c.execute("INSERT INTO settings (key, value) VALUES ('free_access', '0')")
        row = c.execute("SELECT value FROM settings WHERE key='bulk_clone_enabled'").fetchone()
        if not row:
            c.execute("INSERT INTO settings (key, value) VALUES ('bulk_clone_enabled', '1')")
        row = c.execute("SELECT value FROM settings WHERE key='bulk_email_enabled'").fetchone()
        if not row:
            c.execute("INSERT INTO settings (key, value) VALUES ('bulk_email_enabled', '1')")
        c.commit()


init_db()



def log_usage(tg_id, user=None, event="used bot", account_email=""):
    """Record activity and notify the configured private log group. Never log passwords/tokens."""
    try:
        user = user or {}
        username = str(user.get("username") or "").strip()
        first_name = str(user.get("first_name") or "").strip()
        last_name = str(user.get("last_name") or "").strip()
        display = ("@" + username) if username else (" ".join(x for x in (first_name, last_name) if x) or "No username")
        with db() as c:
            c.execute(
                "INSERT INTO usage_logs (tg_id, username, event, account_email, created_at) VALUES (?,?,?,?,?)",
                (int(tg_id), username, str(event)[:120], str(account_email or "")[:254], time.time()),
            )
            c.commit()
        if bot:
            msg = ("<b>Bot usage log</b>\n"
                   "User: %s\nTelegram ID: <code>%s</code>\n"
                   "Action: %s" % (html.escape(display), int(tg_id), html.escape(str(event)[:120])))
            if account_email:
                msg += "\nAccount email: <code>%s</code>" % html.escape(str(account_email)[:254])
            notify_admin_group(msg)
    except Exception as exc:
        print("usage log failed", exc)


def get_credit_balance(uid):
    """Return the current bot-wallet balance for this exact Telegram user ID."""
    uid = int(uid)
    with db() as c:
        row = c.execute("SELECT balance FROM users WHERE tg_id=?", (uid,)).fetchone()
        if row is None:
            # A user may have a wallet before their first /start; create it once.
            now = time.time()
            c.execute("INSERT OR IGNORE INTO users (tg_id, joined_at, last_seen, balance) VALUES (?,?,?,0)", (uid, now, now))
            c.commit()
            row = c.execute("SELECT balance FROM users WHERE tg_id=?", (uid,)).fetchone()
    return float(row["balance"] or 0) if row else 0.0


def extract_owned_car_count(profile):
    """Find a CPM owned-car collection in common nested/serialized response shapes.

    Returns an integer only when a recognizable car collection is present;
    None means the CPM response did not expose a usable collection.
    """
    import json as _json
    car_keys = {
        "cars", "carlist", "car_list", "vehiclelist", "vehicle_list", "vehicles",
        "garage", "cardata", "car_data", "ownedcars", "owned_cars", "cardatas",
        "mycars", "my_cars", "playercars", "player_cars", "carinventory",
        "car_inventory", "usercars", "user_cars", "garagecars", "garage_cars",
    }
    queue = [profile]
    seen = set()
    while queue:
        obj = queue.pop(0)
        if id(obj) in seen:
            continue
        seen.add(id(obj))
        if isinstance(obj, dict):
            for key, value in obj.items():
                normalized = re.sub(r"[^a-z0-9_]", "", str(key).lower())
                if normalized in car_keys:
                    if isinstance(value, (list, tuple, set, dict)):
                        return len(value)
                    if isinstance(value, str) and value.strip():
                        try:
                            parsed = _json.loads(value)
                            if isinstance(parsed, (list, dict)):
                                return len(parsed)
                        except (TypeError, ValueError):
                            pass
                if isinstance(value, (dict, list, tuple)):
                    queue.append(value)
                elif isinstance(value, str) and normalized in {
                    "alldata", "playerdata", "player_data", "userdata", "user_data", "record", "data", "result"
                }:
                    # Some CPM wrappers serialize one or more nested JSON layers.
                    candidate = value.strip()
                    for _ in range(3):
                        try:
                            parsed = _json.loads(candidate)
                        except (TypeError, ValueError):
                            break
                        if isinstance(parsed, (dict, list)):
                            queue.append(parsed)
                            break
                        if not isinstance(parsed, str):
                            break
                        candidate = parsed
        elif isinstance(obj, (list, tuple)):
            # A list is a car collection only when its parent key identified it;
            # here inspect records for nested collections instead of guessing.
            queue.extend(x for x in obj if isinstance(x, (dict, list, tuple)))
    return None


def is_admin(uid):
    try:
        uid = int(uid)
        if uid in ADMIN_IDS:
            return True
        with db() as c:
            return c.execute("SELECT 1 FROM extra_admins WHERE tg_id=?", (uid,)).fetchone() is not None
    except Exception:
        return False


def notify_admin_group(text):
    """Send audit events to the configured private Telegram group."""
    chat_id = ADMIN_LOG_CHAT_ID
    if not chat_id:
        try:
            chat_id = get_setting("admin_log_chat_id", "")
        except Exception:
            chat_id = ""
    if bot and chat_id:
        try:
            bot.send_message(int(chat_id), text, parse_mode="HTML")
        except Exception as exc:
            print("admin group log failed (chat_id=%s): %s" % (chat_id, exc))


# Free access mode: all users can use tools; clone limit 10 + 5 min cooldown
FREE_CLONE_LIMIT = 10
FREE_CLONE_COOLDOWN = 5 * 60  # seconds

def get_setting(key, default="0"):
    with db() as c:
        row = c.execute("SELECT value FROM settings WHERE key=?", (key,)).fetchone()
    return row["value"] if row else default


def set_setting(key, value):
    with db() as c:
        c.execute(
            "INSERT INTO settings (key, value) VALUES (?, ?) ON CONFLICT(key) DO UPDATE SET value=excluded.value",
            (key, str(value)),
        )
        c.commit()


def free_access_enabled():
    return str(get_setting("free_access", "0")).strip() in ("1", "true", "on", "yes")


def set_free_access(on: bool):
    set_setting("free_access", "1" if on else "0")


def bulk_clone_enabled():
    return str(get_setting("bulk_clone_enabled", "1")).strip().lower() in ("1", "true", "on", "yes")


def set_bulk_clone_enabled(on: bool):
    set_setting("bulk_clone_enabled", "1" if on else "0")


def bulk_email_enabled():
    return str(get_setting("bulk_email_enabled", "1")).strip().lower() in ("1", "true", "on", "yes")


def set_bulk_email_enabled(on: bool):
    set_setting("bulk_email_enabled", "1" if on else "0")


def bulk_email_access(uid):
    try:
        if int(uid) in ADMIN_IDS:
            return True
        with db() as c:
            return c.execute("SELECT 1 FROM bulk_email_access WHERE tg_id=?", (int(uid),)).fetchone() is not None
    except Exception:
        return False


def bulk_clone_admin_kb():
    kb = types.InlineKeyboardMarkup(row_width=1)
    label = "🟢 Turn Bulk Clone OFF" if bulk_clone_enabled() else "🔴 Turn Bulk Clone ON"
    kb.add(types.InlineKeyboardButton(label, callback_data="admin_bulk_toggle"))
    return kb


def is_paid_sub(tg_id):
    """True if user has active paid subscription (not just free mode)."""
    return bool(sub_status(tg_id).get("active"))


def get_last_clone(tg_id):
    with db() as c:
        row = c.execute("SELECT last_clone FROM clone_cooldown WHERE tg_id=?", (int(tg_id),)).fetchone()
    return float(row["last_clone"]) if row and row["last_clone"] else 0.0


def set_last_clone(tg_id):
    with db() as c:
        c.execute(
            "INSERT INTO clone_cooldown (tg_id, last_clone) VALUES (?, ?) "
            "ON CONFLICT(tg_id) DO UPDATE SET last_clone=excluded.last_clone",
            (int(tg_id), time.time()),
        )
        c.commit()


def clone_cooldown_remaining(tg_id):
    """Seconds left on clone cooldown. Admins only are exempt."""
    if is_admin(tg_id):
        return 0
    # Paid + free users: 5 minute cooldown between clone jobs
    last = get_last_clone(tg_id)
    if last <= 0:
        return 0
    left = FREE_CLONE_COOLDOWN - (time.time() - last)
    return max(0, int(left))


def clone_limit_for(tg_id):
    """Per-job account limit: owner/admin 150, active subscriber 35, free-access user 10."""
    if is_admin(tg_id):
        return 150
    if is_paid_sub(tg_id):
        return 35
    if free_access_enabled():
        return 10
    return 0




def upsert_user(tg_id, username="", first_name="", last_name="", photo_url=""):
    now = time.time()
    with db() as c:
        row = c.execute("SELECT tg_id FROM users WHERE tg_id=?", (tg_id,)).fetchone()
        if row is not None:
            c.execute(
                "UPDATE users SET username=?, first_name=?, last_name=?, "
                "photo_url=COALESCE(NULLIF(?,''), photo_url), last_seen=? WHERE tg_id=?",
                (username or "", first_name or "", last_name or "", photo_url or "", now, tg_id),
            )
        if row is None:
            c.execute(
                "INSERT INTO users (tg_id, username, first_name, last_name, photo_url, joined_at, last_seen) "
                "VALUES (?,?,?,?,?,?,?)",
                (tg_id, username or "", first_name or "", last_name or "", photo_url or "", now, now),
            )
        c.commit()


def get_user(tg_id):
    with db() as c:
        row = c.execute("SELECT * FROM users WHERE tg_id=?", (tg_id,)).fetchone()
    return dict(row) if row else None


def set_subscription(tg_id, plan_key):
    """Create/update a subscription using a named plan or a duration.

    /givesub <telegram_id> <duration>
    Examples: 30, 30m, 12h, 1day, 14days, 2w, 1month, lifetime.
    A bare number means minutes for backwards compatibility.
    """
    plan_key = str(plan_key).strip().lower()
    plan = PLANS.get(plan_key)
    if plan:
        duration_seconds = int(plan["days"] * 86400)
    else:
        match = re.fullmatch(r"(\d+)\s*(minutes?|mins?|m|hours?|hrs?|h|days?|d|weeks?|w|months?|mos?|years?|yrs?|y)", plan_key)
        if match:
            amount = int(match.group(1))
            unit = match.group(2)
            if unit in ("m", "min", "mins", "minute", "minutes"):
                multiplier, suffix = 60, "m"
            elif unit in ("h", "hr", "hrs", "hour", "hours"):
                multiplier, suffix = 3600, "h"
            elif unit in ("d", "day", "days"):
                multiplier, suffix = 86400, "d"
            elif unit in ("w", "week", "weeks"):
                multiplier, suffix = 604800, "w"
            elif unit in ("mo", "mos", "month", "months"):
                multiplier, suffix = 30 * 86400, "mo"
            else:
                multiplier, suffix = 365 * 86400, "y"
            if amount < 1:
                return False
            duration_seconds = amount * multiplier
            plan_key = f"{amount}{suffix}"
        elif plan_key.isdigit():
            minutes = int(plan_key)
            if minutes < 1:
                return False
            duration_seconds = minutes * 60
            plan_key = f"{minutes}m"
        else:
            return False
        # Guard against accidentally granting an unreasonable duration.
        if duration_seconds > 100 * 365 * 86400:
            return False
    tg_id = int(tg_id)
    expires = time.time() + duration_seconds
    now = time.time()
    with db() as c:
        cur = c.execute(
            "UPDATE users SET sub_plan=?, sub_expires=? WHERE tg_id=?",
            (plan_key, expires, tg_id),
        )
        if cur.rowcount == 0:
            c.execute(
                """INSERT INTO users
                   (tg_id, username, first_name, last_name, photo_url,
                    sub_plan, sub_expires, joined_at, last_seen)
                   VALUES (?, '', '', '', '', ?, ?, ?, ?)""",
                (tg_id, plan_key, expires, now, now),
            )
        c.commit()
    return True


def clear_subscription(tg_id):
    """Remove subscription and report whether a user row existed."""
    with db() as c:
        cur = c.execute(
            "UPDATE users SET sub_plan=NULL, sub_expires=NULL WHERE tg_id=?",
            (int(tg_id),),
        )
        c.commit()
        return cur.rowcount > 0


def sub_status(tg_id):
    u = get_user(tg_id)
    if not u or not u.get("sub_expires"):
        return {"active": False, "plan": None, "remaining": "None"}
    exp = float(u["sub_expires"])
    if exp < time.time():
        return {"active": False, "plan": u.get("sub_plan"), "remaining": "Expired"}
    left = exp - time.time()
    days, hours = int(left // 86400), int((left % 86400) // 3600)
    minutes = max(1, int((left % 3600 + 59) // 60))
    plan_key = u.get("sub_plan") or ""
    label = PLANS.get(plan_key, {}).get("label", (plan_key[:-1] + " Minutes") if plan_key.endswith("m") and plan_key[:-1].isdigit() else plan_key)
    if plan_key == "lifetime" or days > 1000:
        rem = "Lifetime"
    elif days:
        rem = "%dd %dh" % (days, hours)
    elif hours:
        rem = "%dh %dm" % (hours, minutes)
    else:
        rem = "%dm" % minutes
    return {
        "active": True,
        "plan": plan_key,
        "plan_label": label,
        "remaining": rem,
        "expires_str": datetime.utcfromtimestamp(exp).strftime("%Y-%m-%d"),
    }


def validate_init_data(init_data: str):
    try:
        parsed = dict(parse_qsl(init_data, keep_blank_values=True))
        received_hash = parsed.pop("hash", None)
        if not received_hash or not BOT_TOKEN:
            return None
        data_check = "\n".join("%s=%s" % (k, v) for k, v in sorted(parsed.items()))
        secret = hmac.new(b"WebAppData", BOT_TOKEN.encode(), hashlib.sha256).digest()
        calc = hmac.new(secret, data_check.encode(), hashlib.sha256).hexdigest()
        if not hmac.compare_digest(calc, received_hash):
            return None
        return json.loads(parsed.get("user", "{}"))
    except Exception:
        return None


def resolve_tg(body):
    body = body or {}
    init_data = body.get("initData") or body.get("init_data") or ""
    user = validate_init_data(init_data) if init_data else None
    if user and user.get("id") is not None:
        return int(user["id"]), user
    tid = body.get("tg_id") or body.get("telegram_id")
    if tid is not None and str(tid).strip() != "":
        try:
            tid = int(tid)
            return tid, {
                "id": tid,
                "username": body.get("username") or "",
                "first_name": body.get("first_name") or "User",
                "last_name": body.get("last_name") or "",
                "photo_url": body.get("photo_url") or "",
            }
        except Exception:
            pass
    return None, None


def is_blocked(tg_id):
    with db() as c:
        return c.execute("SELECT 1 FROM blocked_users WHERE tg_id=?", (int(tg_id),)).fetchone() is not None


def set_user_blocked(tg_id, blocked_by, reason=""):
    with db() as c:
        c.execute(
            "INSERT INTO blocked_users (tg_id, blocked_by, blocked_at, reason) VALUES (?,?,?,?) "
            "ON CONFLICT(tg_id) DO UPDATE SET blocked_by=excluded.blocked_by, blocked_at=excluded.blocked_at, reason=excluded.reason",
            (int(tg_id), int(blocked_by), time.time(), str(reason or "")[:200]),
        )
        c.commit()


def set_user_unblocked(tg_id):
    with db() as c:
        cur = c.execute("DELETE FROM blocked_users WHERE tg_id=?", (int(tg_id),))
        c.commit()
        return cur.rowcount > 0


def maintenance_enabled():
    return str(get_setting("maintenance", "0")).strip().lower() in ("1", "true", "on", "yes")


def owner_only(uid):
    return int(uid) in ADMIN_IDS


def require_sub(tg_id):
    """Check block status, maintenance mode, and subscription/free-access status."""
    if is_admin(tg_id):
        return True
    if is_blocked(tg_id) or maintenance_enabled():
        return False
    if free_access_enabled():
        return True
    return bool(sub_status(tg_id).get("active"))


def required_channels():
    """Return configured required Telegram channels, without empty entries."""
    return [ch for ch in (CHANNEL_USERNAME, CHANNEL_USERNAME_2) if ch]


def channel_joined(tg_id):
    """Channel membership is no longer required."""
    return True


def channel_join_kb():
    """Legacy compatibility: no channel-join buttons are shown."""
    return types.InlineKeyboardMarkup()


def require_channel_message(chat_id, tg_id):
    """Legacy compatibility: allow direct bot start without channel verification."""
    return True


# ---------- Flask ----------
flask_app = Flask(__name__)
flask_app.secret_key = os.environ.get("SECRET_KEY", "primo-cpm")
_cpm_sessions = {}
_pending_receipt = {}  # tg_id -> plan_key
_pending_payment_method = {}  # tg_id -> selected manual payment method

_jobs = {}
_job_lock = threading.Lock()
_JOBS_DIR = Path(os.environ.get("JOBS_DIR") or (Path(__file__).resolve().parent / "jobs_data"))
try:
    _JOBS_DIR.mkdir(parents=True, exist_ok=True)
except Exception:
    pass


def _new_job_id():
    return secrets.token_hex(8)


def _job_path(job_id):
    safe = re.sub(r"[^a-zA-Z0-9_-]", "", str(job_id))[:64]
    return _JOBS_DIR / ("%s.json" % safe)


def job_set(job_id, **fields):
    with _job_lock:
        j = _jobs.get(job_id) or {}
        # merge disk if missing in memory
        if not j:
            try:
                p = _job_path(job_id)
                if p.is_file():
                    j = json.loads(p.read_text(encoding="utf-8") or "{}")
            except Exception:
                j = {}
        j.update(fields)
        j["id"] = job_id
        j["updated_at"] = time.time()
        # normalize percent
        try:
            j["percent"] = max(0, min(100, int(float(j.get("percent") or 0))))
        except Exception:
            j["percent"] = 0
        _jobs[job_id] = j
        try:
            _job_path(job_id).write_text(json.dumps(j, ensure_ascii=False), encoding="utf-8")
        except Exception:
            pass
        return dict(j)


def job_get(job_id):
    with _job_lock:
        j = _jobs.get(job_id)
        if j:
            return dict(j)
        try:
            p = _job_path(job_id)
            if p.is_file():
                j = json.loads(p.read_text(encoding="utf-8") or "{}")
                _jobs[job_id] = j
                return dict(j)
        except Exception:
            pass
        return None


def start_job(name, target, *args, job_id=None, **kwargs):
    """Run work in a non-daemon thread so it keeps going after Mini App closes.
    Returns job_id. target may accept progress via kwargs if designed for it.
    """
    jid = job_id or _new_job_id()
    job_set(
        jid,
        id=jid,
        name=name,
        status="running",
        percent=0,
        message="Starting…",
        result=None,
        error=None,
        created_at=time.time(),
    )

    def runner():
        try:
            target(*args, **kwargs)
            cur = job_get(jid) or {}
            if cur.get("status") == "running":
                job_set(jid, status="done", percent=100, message=cur.get("message") or "Done")
        except Exception as e:
            print("job", name, "error", e)
            job_set(jid, status="error", percent=100, message=str(e)[:200], error=str(e)[:200])

    th = threading.Thread(target=runner, name="job-%s-%s" % (name, jid), daemon=False)
    try:
        th.start()
    except RuntimeError as exc:
        # Thread-limited hosting: run inline rather than fail with "can't start new thread".
        print("job thread unavailable; running inline:", name, str(exc)[:160])
        runner()
    return jid




def _html(name):
    path = ROOT / name
    try:
        if path.is_file():
            return path.read_text(encoding="utf-8")
    except Exception:
        pass
    if name == "login.html":
        return base64.b64decode(_LOGIN_B64).decode("utf-8")
    if name == "dashboard.html":
        return base64.b64decode(_DASH_B64).decode("utf-8")
    return "<h1>Not found</h1>"


@flask_app.route("/")
def root():
    return redirect("/login")


@flask_app.route("/login")
def login_page():
    return _html("login.html"), 200, {"Content-Type": "text/html; charset=utf-8"}


@flask_app.route("/app")
@flask_app.route("/dashboard")
def app_page():
    return _html("dashboard.html"), 200, {"Content-Type": "text/html; charset=utf-8"}


@flask_app.route("/api/me", methods=["POST"])
def api_me():
    body = request.get_json(silent=True) or {}
    tg_id, user = resolve_tg(body)
    if not tg_id or not user:
        return jsonify({"ok": False, "error": "Open from Telegram bot → Open App"}), 401
    upsert_user(tg_id, user.get("username") or "", user.get("first_name") or "", user.get("last_name") or "", user.get("photo_url") or "")
    if not is_admin(tg_id) and is_blocked(tg_id):
        return jsonify({"ok": False, "error": "Your access is blocked. Contact the owner."}), 403
    if not is_admin(tg_id) and maintenance_enabled():
        return jsonify({"ok": False, "error": "The service is under maintenance. Please try again later."}), 503
    st = sub_status(tg_id)
    if is_admin(tg_id):
        st = {
            "active": True,
            "plan": "admin",
            "plan_label": "Admin",
            "remaining": "Unlimited",
            "expires_str": "Never",
        }
    row = get_user(tg_id) or {}
    member_since = "—"
    try:
        if row.get("joined_at"):
            member_since = datetime.utcfromtimestamp(float(row["joined_at"])).strftime("%b %d, %Y")
    except Exception:
        pass
    return jsonify({
        "ok": True,
        "user": {
            "id": tg_id,
            "username": user.get("username") or "",
            "first_name": user.get("first_name") or "",
            "last_name": user.get("last_name") or "",
            "photo_url": user.get("photo_url") or "",
        },
        "subscription": st,
        "member_since": member_since,
        "is_admin": is_admin(tg_id),
    })




@flask_app.route("/api/cpm_login", methods=["POST"])
def api_cpm_login():
    body = request.get_json(silent=True) or {}
    tg_id, user = resolve_tg(body)
    if not tg_id:
        return jsonify({"ok": False, "error": "Open from Telegram bot → Open App"}), 401
    if not is_admin(tg_id) and is_blocked(tg_id):
        return jsonify({"ok": False, "error": "account_blocked"}), 403
    if not is_admin(tg_id) and maintenance_enabled():
        return jsonify({"ok": False, "error": "maintenance"}), 503
    email = (body.get("email") or "").strip()
    password = body.get("password") or ""
    log_usage(tg_id, user, "Account login attempt", email)
    try:
        from cpm1_core import nuker
        lr = nuker.login(email, password)
        if not lr.get("ok"):
            return jsonify({"ok": False, "error": lr.get("message", "login_failed")})
        uid_key = abs(hash("web_%s" % tg_id)) % (10**9)
        nuker.save_token(uid_key, lr["auth"], email, password, lr.get("refresh_token", ""), lr.get("firebase_uid", ""))
        if not nuker.load(uid_key, force=True):
            # New / empty CPM profile — seed blank so tools can load
            seed = nuker.seed_blank_profile(lr["auth"], lr.get("firebase_uid", ""), email)
            nuker.save_token(uid_key, lr["auth"], email, password, lr.get("refresh_token", ""), lr.get("firebase_uid", ""))
            if not nuker.load(uid_key, force=True) and seed.get("ok"):
                nuker.set_record(uid_key, {
                    "Name": "Player", "money": 25000, "coin": 0,
                    "localID": seed.get("localID") or "00000001",
                    "allData": '{"cars":[]}',
                }, email)
        _cpm_sessions[tg_id] = {"email": email, "password": password, "auth": lr["auth"], "fuid": lr.get("firebase_uid", ""), "uid_key": uid_key}
        return jsonify({"ok": True, "email": email})
    except Exception as e:
        return jsonify({"ok": False, "error": str(e)[:120]})


@flask_app.route("/api/cpm_register", methods=["POST"])
def api_cpm_register():
    body = request.get_json(silent=True) or {}
    tg_id, user = resolve_tg(body)
    if not tg_id:
        return jsonify({"ok": False, "error": "Open from Telegram bot → Open App"}), 401
    if not is_admin(tg_id) and is_blocked(tg_id):
        return jsonify({"ok": False, "error": "account_blocked"}), 403
    if not is_admin(tg_id) and maintenance_enabled():
        return jsonify({"ok": False, "error": "maintenance"}), 503
    email = (body.get("email") or "").strip()
    password = body.get("password") or ""
    log_usage(tg_id, user, "Account registration attempt", email)
    if not email or "@" not in email:
        return jsonify({"ok": False, "error": "Enter a valid email"})
    if len(password) < 6:
        return jsonify({"ok": False, "error": "Password min 6 chars"})
    try:
        from cpm1_core import nuker
        lr = nuker.register(email, password)
        if not lr.get("ok"):
            # if email already exists, try login path
            msg = str(lr.get("message") or "")
            if "EMAIL_EXISTS" in msg.upper():
                return jsonify({"ok": False, "error": "Email already used — switch to Login"})
            return jsonify({"ok": False, "error": lr.get("message", "register_failed")})
        # Prefer fresh login tokens
        lr2 = nuker.login(email, password)
        if lr2.get("ok"):
            lr = lr2
        auth = lr.get("auth") or ""
        fuid = lr.get("firebase_uid") or ""
        if not auth or not fuid:
            return jsonify({"ok": False, "error": "Register OK but missing token — try Login"})
        # Seed CPM player profile so load() works (new Firebase accounts have no CPM record yet)
        seed = nuker.seed_blank_profile(auth, fuid, email)
        if not seed.get("ok"):
            # one more login + seed
            lr3 = nuker.login(email, password)
            if lr3.get("ok"):
                auth = lr3.get("auth") or auth
                fuid = lr3.get("firebase_uid") or fuid
                lr = lr3
                seed = nuker.seed_blank_profile(auth, fuid, email)
        uid_key = abs(hash("web_%s" % tg_id)) % (10**9)
        nuker.save_token(
            uid_key, auth, email, password,
            lr.get("refresh_token", ""), fuid,
        )
        # Try load; if still empty, cache the blank so tools don't crash
        loaded = nuker.load(uid_key, force=True)
        if not loaded:
            blank_cache = {
                "Name": "Player",
                "money": 25000,
                "coin": 0,
                "localID": seed.get("localID") or "00000001",
                "allData": '{"cars":[]}',
                "floats": [0.0] * 50,
                "integers": [0] * 120,
            }
            nuker.set_record(uid_key, blank_cache, email)
        _cpm_sessions[tg_id] = {
            "email": email,
            "password": password,
            "auth": auth,
            "fuid": fuid,
            "uid_key": uid_key,
        }
        note = "Account created"
        if seed.get("ok"):
            note = "Account created + profile ready"
        else:
            note = "Account created (profile seed pending — open game once, then re-login)"
        return jsonify({"ok": True, "email": email, "message": note, "seed": seed.get("ok", False)})
    except Exception as e:
        return jsonify({"ok": False, "error": str(e)[:160]})



@flask_app.route("/api/cpm_logout", methods=["POST"])
def api_cpm_logout():
    body = request.get_json(silent=True) or {}
    tg_id, _ = resolve_tg(body)
    if tg_id and tg_id in _cpm_sessions:
        _cpm_sessions.pop(tg_id, None)
    return jsonify({"ok": True})


@flask_app.route("/api/cpm_session")
def api_cpm_session():
    tg_id = request.args.get("tg_id", type=int)
    if not tg_id or tg_id not in _cpm_sessions:
        return jsonify({"ok": False})
    sess = _cpm_sessions[tg_id]
    profile = None
    try:
        from cpm1_core import nuker
        uid_key = sess.get("uid_key") or abs(hash("web_%s" % tg_id)) % (10**9)
        nuker.save_token(uid_key, sess["auth"], sess["email"], sess["password"], "", sess.get("fuid", ""))
        nuker.load(uid_key, force=True)
        info = nuker.get_account_info(uid_key)
        if isinstance(info, dict) and info.get("ok"):
            profile = {
                "name": info.get("name"),
                "money": info.get("money"),
                "coin": info.get("coin"),
                "player_id": info.get("localID"),
                "localID": info.get("localID"),
            }
    except Exception:
        pass
    return jsonify({"ok": True, "email": sess["email"], "profile": profile})


def _sess(tg_id):
    return _cpm_sessions.get(tg_id)


def _format_cpm_tagged_text(raw_text, colors, upper=False):
    text = "".join(ch for ch in str(raw_text or "").strip() if ch.isprintable() and ch not in "[]")
    if upper:
        text = text.upper()
    if not text:
        return None, "Text is required"
    if len(text) > 20:
        return None, "Text must be 20 characters or fewer"
    return "".join("[%s]%s" % (colors[i % len(colors)], ch) for i, ch in enumerate(text)), None

COLOR_PRESETS = {
    "fire": ("FF3030", "FF7A24", "FFD000"),
    "ice": ("B8F4FF", "62C9FF", "FFFFFF"),
    "royal": ("7A35D8", "C49BFF", "F4D7FF"),
    "neon": ("FF35D3", "A735FF", "39E8FF"),
    "toxic": ("39E600", "A8FF00", "D8FF48"),
    "blood": ("B00020", "E00032", "FF5364"),
    "rainbow": ("FF3030", "FF9A24", "FFE600", "42E85A", "28C8FF", "5C62FF", "D44DFF"),
    "gold": ("FFD700", "FFB000", "FFF1A8"),
    "red": ("FF2020",),
    "cyan": ("00D9FF",),
    "green": ("20D850",),
    "purple": ("A020F0",),
    "white": ("FFFFFF",),
}

COLOR_LABELS = {
    "fire": "🔥 Fire", "ice": "❄️ Ice", "royal": "⚜️ Royal",
    "neon": "💜 Neon", "toxic": "🟢 Toxic", "blood": "🩸 Blood",
    "rainbow": "🌈 Rainbow", "gold": "🥇 Gold", "red": "🔴 Red",
    "cyan": "🔵 Cyan", "green": "🟢 Green", "purple": "🟣 Purple",
    "white": "⚪ White",
}

def _format_color_preset(raw_text, preset, mode="per_char", upper=False):
    text = "".join(ch for ch in str(raw_text or "").strip() if ch.isprintable() and ch not in "[]")
    if upper:
        text = text.upper()
    if not text:
        return None, "Text is required"
    if len(text) > 20:
        return None, "Text must be 20 characters or fewer"
    colors = COLOR_PRESETS.get(preset)
    if not colors:
        return None, "Unknown colour preset"
    if mode == "whole":
        return "[%s]%s" % (colors[0], text), None
    return "".join("[%s]%s" % (colors[i % len(colors)], ch) for i, ch in enumerate(text)), None

def _color_preset_keyboard(target, mode="per_char"):
    kb = types.InlineKeyboardMarkup(row_width=2)
    keys = list(COLOR_LABELS)
    for i in range(0, len(keys), 2):
        row = []
        for key in keys[i:i+2]:
            row.append(types.InlineKeyboardButton(COLOR_LABELS[key], callback_data="colorpreset_%s_%s" % (target, key)))
        kb.row(*row)
    kb.row(types.InlineKeyboardButton(
        "⚙️ Format: Per-Character" if mode == "per_char" else "⚙️ Format: Whole Name",
        callback_data="colorformat_%s" % target))
    kb.row(types.InlineKeyboardButton("❌ Cancel", callback_data="colorcancel"))
    return kb



@flask_app.route("/api/action", methods=["POST"])
def api_action():
    body = request.get_json(silent=True) or {}
    tg_id, user = resolve_tg(body)
    if not tg_id:
        return jsonify({"ok": False, "error": "telegram_required"}), 401
    if not is_admin(tg_id) and is_blocked(tg_id):
        return jsonify({"ok": False, "error": "account_blocked"}), 403
    if not is_admin(tg_id) and maintenance_enabled():
        return jsonify({"ok": False, "error": "maintenance"}), 503
    # The Bulk Clone toggle must not disable unrelated tools such as Cars, Vinyl, or Plates.
    if not require_sub(tg_id):
        return jsonify({"ok": False, "error": "subscription_required"}), 403
    action = body.get("action") or ""
    log_usage(tg_id, user, "Tool action: " + str(action)[:80])
    sess = _sess(tg_id)
    if not sess:
        return jsonify({"ok": False, "error": "login_required"})
    value = body.get("value")
    try:
        from cpm1_core import nuker
        uid = sess.get("uid_key") or abs(hash("web_%s" % tg_id)) % (10**9)
        nuker.save_token(uid, sess["auth"], sess["email"], sess["password"], "", sess.get("fuid", ""))

        if action == "acc_rainbow_name":
            raw_name = str(value or "").strip()
            visible_name = "".join(ch for ch in raw_name if ch.isprintable() and ch not in "[]")
            if not visible_name:
                return jsonify({"ok": False, "error": "Name is required"})
            if len(visible_name) > 20:
                return jsonify({"ok": False, "error": "Name must be 20 characters or fewer"})
            rainbow_colors = ("FF3030", "FF9A24", "FFE600", "42E85A", "28C8FF", "5C62FF", "D44DFF")
            formatted_name = "".join(
                "[%s]%s" % (rainbow_colors[i % len(rainbow_colors)], ch)
                for i, ch in enumerate(visible_name)
            )
            result = nuker.change_player_name(uid, formatted_name)
            if not result.get("ok"):
                return jsonify({"ok": False, "message": result.get("message", "Rainbow name save failed")})
            return jsonify({"ok": True, "message": "Rainbow name saved; reopen the game to refresh it"})

        if action == "acc_rainbow_id":
            info = nuker.get_account_info(uid, force_refresh=True)
            if not isinstance(info, dict) or not info.get("ok"):
                return jsonify({"ok": False, "error": "Could not read the current CPM ID"})
            raw_id = str(info.get("localID") or info.get("player_id") or "").strip()
            visible_id = re.sub(r"\[[0-9A-Fa-f]{6}\]", "", raw_id).strip()
            visible_id = "".join(ch for ch in visible_id if ch.isprintable() and ch not in "[]").upper()
            if not visible_id:
                return jsonify({"ok": False, "error": "Current CPM ID is empty"})
            if len(visible_id) > 20:
                return jsonify({"ok": False, "error": "Current CPM ID is too long to color-format"})
            rainbow_colors = ("FF3030", "FF9A24", "FFE600", "42E85A", "28C8FF", "5C62FF", "D44DFF")
            formatted_id = "".join(
                "[%s]%s" % (rainbow_colors[i % len(rainbow_colors)], ch)
                for i, ch in enumerate(visible_id)
            )
            result = nuker.change_player_id(uid, formatted_id)
            if not result.get("ok"):
                return jsonify({"ok": False, "message": result.get("message", "Rainbow ID save failed")})
            return jsonify({"ok": True, "message": "Rainbow ID saved. Reopen the game to refresh it."})

        if action == "acc_custom_rainbow_name":
            rainbow_colors = ("FF3030", "FF9A24", "FFE600", "42E85A", "28C8FF", "5C62FF", "D44DFF")
            formatted_name, text_error = _format_cpm_tagged_text(value, rainbow_colors)
            if text_error:
                return jsonify({"ok": False, "error": text_error})
            result = nuker.change_player_name(uid, formatted_name)
            if not result.get("ok"):
                return jsonify({"ok": False, "message": result.get("message", "Custom Rainbow Name save failed")})
            return jsonify({"ok": True, "message": "Custom rainbow name saved; reopen the game to refresh it."})

        if action == "acc_custom_rainbow_id":
            rainbow_colors = ("FF3030", "FF9A24", "FFE600", "42E85A", "28C8FF", "5C62FF", "D44DFF")
            formatted_id, text_error = _format_cpm_tagged_text(value, rainbow_colors, upper=True)
            if text_error:
                return jsonify({"ok": False, "error": text_error})
            result = nuker.change_player_id(uid, formatted_id)
            if not result.get("ok"):
                return jsonify({"ok": False, "message": result.get("message", "Custom Rainbow ID save failed")})
            return jsonify({"ok": True, "message": "Custom rainbow ID saved; reopen the game to refresh it."})

        mapping = {
            "acc_rank": lambda: nuker.set_rank(uid),
            "acc_refresh": lambda: nuker.get_account_info(uid, force_refresh=True),
            "eco_money": lambda: nuker.set_money(uid, 50_000_000),
            "eco_coin": lambda: nuker.set_coin(uid, 500_000),
            "eco_money_c": lambda: nuker.set_money(uid, int(float(value or 0))),
            "eco_coin_c": lambda: nuker.set_coin(uid, int(float(value or 0))),
            "unl_w16": lambda: nuker.unlock_w16(uid),
            "unl_smoke": lambda: nuker.unlock_smoke(uid),
            "unl_fuel": lambda: nuker.unlimited_fuel(uid),
            "unl_damage": lambda: nuker.disable_damage(uid),
            "unl_horns": lambda: nuker.unlock_horns(uid),
            "unl_anim": lambda: nuker.unlock_animations(uid),
            "unl_houses": lambda: nuker.unlock_houses(uid),
            "unl_wheels": lambda: nuker.unlock_wheels(uid),
            "unl_levels": lambda: nuker.complete_all_levels(uid),
            "unl_clothes": lambda: nuker.unlock_all_clothes(uid),
            "unl_all": lambda: nuker.unlock_all_features(uid),
            "acc_name": lambda: nuker.change_player_name(uid, str(value or "")),
            "acc_id": lambda: nuker.change_player_id(uid, str(value or "")),
        }
        if action == "acc_email":
            result = nuker.change_email(uid, str(value or "").strip())
            if result.get("ok"):
                sess["email"] = result.get("email") or str(value).strip()
                sess["auth"] = result.get("_auth") or sess.get("auth", "")
                sess["fuid"] = result.get("_firebase_uid") or sess.get("fuid", "")
                return jsonify({"ok": True, "message": result.get("message", "Email changed successfully")})
            return jsonify({"ok": False, "message": result.get("message", "Email change failed")}), 400
        if action == "acc_pass":
            new_password = str(value or "")
            result = nuker.change_password(uid, new_password)
            if result.get("ok"):
                sess["password"] = new_password
                sess["auth"] = result.get("_auth") or sess.get("auth", "")
                sess["fuid"] = result.get("_firebase_uid") or sess.get("fuid", "")
                return jsonify({"ok": True, "message": result.get("message", "Password changed successfully")})
            return jsonify({"ok": False, "message": result.get("message", "Password change failed")}), 400
        if action == "veh_siren":
            email, password = sess["email"], sess["password"]
            def work_siren():
                from siren_mod import unlock_siren
                res = unlock_siren(email, password, car_id=None)
                _send_tg(tg_id, "%s Siren all: %s" % ("✅" if res.get("ok") else "❌", res.get("message", "")))
            start_job("siren_all", work_siren)
            return jsonify({"ok": True, "message": "Siren job started — close app OK, result on Telegram"})
        if action == "veh_siren_one":
            email, password = sess["email"], sess["password"]
            cid = int(value) if value is not None else None
            def work_siren1():
                from siren_mod import unlock_siren
                res = unlock_siren(email, password, car_id=cid)
                _send_tg(tg_id, "%s Siren one: %s" % ("✅" if res.get("ok") else "❌", res.get("message", "")))
            start_job("siren_one", work_siren1)
            return jsonify({"ok": True, "message": "Siren job started — close app OK, result on Telegram"})
        if action == "plate_inject":
            email, password = sess["email"], sess["password"]
            def work_plates():
                from plate_mod import inject_plates
                res = inject_plates(email, password, merge=True)
                _send_tg(tg_id, "%s Plates: %s" % ("✅" if res.get("ok") else "❌", res.get("message", "")))
            start_job("plates", work_plates)
            return jsonify({"ok": True, "message": "Plate inject started — close app OK, result on Telegram"})
        if action == "veh_all":
            # Unlock All Cars is distinct from Clone Cars: use the configured source garage.
            email, password = sess["email"], sess["password"]
            def work_all():
                from cpm1_core import unlock_all_cars
                res = unlock_all_cars(email, password)
                _send_tg(tg_id, "%s Unlock all cars: %s" % ("✅" if res.get("ok") else "❌", res.get("message", "")))
            start_job("veh_all_unlock", work_all)
            return jsonify({"ok": True, "message": "Unlock All Cars started — result on Telegram"})
        if action == "veh_one":
            email, password = sess["email"], sess["password"]
            if value is None or str(value).strip() == "":
                return jsonify({"ok": False, "error": "Car ID required"})
            try:
                cid = int(value)
            except Exception:
                return jsonify({"ok": False, "error": "Invalid car ID"})
            def work_one():
                from cpm1_core import unlock_one_car
                res = unlock_one_car(email, password, cid)
                _send_tg(tg_id, "%s Unlock car %s: %s" % ("✅" if res.get("ok") else "❌", cid, res.get("message", "")))
            start_job("veh_one", work_one)
            return jsonify({"ok": True, "message": "Unlock car %s started — result on Telegram" % cid})
        if action == "veh_w124":
            email, password = sess["email"], sess["password"]
            def work_w124():
                from cpm1_core import unlock_one_car
                # common W124 id attempts
                last = None
                for cid in (106, 61, 107, 108):
                    last = unlock_one_car(email, password, cid)
                    if last.get("ok"):
                        break
                res = last or {"ok": False, "message": "W124 not on source"}
                _send_tg(tg_id, "%s W124: %s" % ("✅" if res.get("ok") else "❌", res.get("message", "")))
            start_job("veh_w124", work_w124)
            return jsonify({"ok": True, "message": "W124 unlock started — result on Telegram"})
        if action == "veh_camry":
            email, password = sess["email"], sess["password"]
            def work_camry():
                from cpm1_core import unlock_one_car
                last = None
                for cid in (120, 121, 122):
                    last = unlock_one_car(email, password, cid)
                    if last.get("ok"):
                        break
                res = last or {"ok": False, "message": "Camry not on source"}
                _send_tg(tg_id, "%s Camry: %s" % ("✅" if res.get("ok") else "❌", res.get("message", "")))
            start_job("veh_camry", work_camry)
            return jsonify({"ok": True, "message": "Camry unlock started — result on Telegram"})
        
        # --- vinyl / cars / plates copy ---
        if action == "vinyl_one":
            # value: "src@mail:pass|tgt@mail:pass|carId"; legacy source|carId uses logged-in target
            email, password = sess["email"], sess["password"]
            raw = str(value or "")
            parts = [p.strip() for p in raw.split("|")]
            if len(parts) >= 3:
                sp, tp, cid = parts[0], parts[1], parts[2]
                if ":" not in sp or ":" not in tp or not cid:
                    return jsonify({"ok": False, "error": "need source email:password | target email:password | car ID"})
            elif len(parts) == 2:
                sp, cid = parts[0], parts[1]
                tp = "%s:%s" % (email, password)
            else:
                return jsonify({"ok": False, "error": "need source email:password | target email:password | car ID"})
            if not str(cid).strip().isdigit():
                return jsonify({"ok": False, "error": "Car ID must be a number"})
            def work_v1():
                se, spa = sp.split(":", 1) if ":" in sp else (sp, "")
                te, tpa = tp.split(":", 1) if ":" in tp else (tp, "")
                from cpm1_core import copy_car_vinyl_single
                res = copy_car_vinyl_single(se, spa, te, tpa, cid)
                _send_tg(tg_id, "%s Vinyl single: %s" % ("✅" if res.get("ok") else "❌", res.get("message", "")))
            start_job("vinyl_one", work_v1)
            return jsonify({"ok": True, "message": "Vinyl single started — result on Telegram"})
        if action == "vinyl_all":
            email, password = sess["email"], sess["password"]
            raw = str(value or "")
            # value: source email:pass | target email:pass; source-only remains supported for older clients
            if "|" in raw:
                sp, tp = raw.split("|", 1)
            else:
                sp, tp = raw, "%s:%s" % (email, password)
            if ":" not in sp or ":" not in tp:
                return jsonify({"ok": False, "error": "need source email:password | target email:password"})
            def work_va():
                se, spa = sp.split(":", 1)
                te, tpa = tp.split(":", 1) if ":" in tp else (email, password)
                from cpm1_core import copy_car_vinyl_all
                res = copy_car_vinyl_all(se, spa, te, tpa)
                _send_tg(tg_id, "%s Vinyl all: %s" % ("✅" if res.get("ok") else "❌", res.get("message", "")))
            start_job("vinyl_all", work_va)
            return jsonify({"ok": True, "message": "Vinyl all cars started — result on Telegram"})
        if action == "car_one":
            email, password = sess["email"], sess["password"]
            raw = str(value or "")
            parts = [p.strip() for p in raw.split("|")]
            if len(parts) >= 3:
                sp, tp, cid = parts[0], parts[1], parts[2]
                if ":" not in sp or ":" not in tp or not cid:
                    return jsonify({"ok": False, "error": "need source email:password | target email:password | car ID"})
            elif len(parts) == 2:
                sp, cid = parts[0], parts[1]
                tp = "%s:%s" % (email, password)
            else:
                return jsonify({"ok": False, "error": "need source email:password | target email:password | car ID"})
            if not str(cid).strip().isdigit():
                return jsonify({"ok": False, "error": "Car ID must be a number"})
            def work_c1():
                se, spa = sp.split(":", 1) if ":" in sp else (sp, "")
                te, tpa = tp.split(":", 1) if ":" in tp else (tp, "")
                from cpm1_core import clone_single_car
                res = clone_single_car(se, spa, te, tpa, cid)
                _send_tg(tg_id, "%s Clone car: %s" % ("✅" if res.get("ok") else "❌", res.get("message", "")))
            start_job("car_one", work_c1)
            return jsonify({"ok": True, "message": "Clone single car started — result on Telegram"})
        if action == "car_all":
            email, password = sess["email"], sess["password"]
            raw = str(value or "")
            if "|" in raw:
                sp, tp = raw.split("|", 1)
            else:
                sp, tp = raw, "%s:%s" % (email, password)
            if ":" not in sp or ":" not in tp:
                return jsonify({"ok": False, "error": "need source email:password | target email:password"})
            def work_ca():
                se, spa = sp.split(":", 1)
                te, tpa = tp.split(":", 1) if ":" in tp else (email, password)
                from cpm1_core import clone_all_cars
                res = clone_all_cars(se, spa, te, tpa)
                _send_tg(tg_id, "%s Clone cars: %s" % ("✅" if res.get("ok") else "❌", res.get("message", "")))
            start_job("car_all", work_ca)
            return jsonify({"ok": True, "message": "Clone all cars started — result on Telegram"})
        if action == "plate_copy":
            email, password = sess["email"], sess["password"]
            raw = str(value or "")
            if "|" in raw:
                sp, tp = raw.split("|", 1)
            else:
                sp, tp = raw, "%s:%s" % (email, password)
            if ":" not in sp or ":" not in tp:
                return jsonify({"ok": False, "error": "need source email:password | target email:password"})
            def work_pc():
                se, spa = sp.split(":", 1)
                te, tpa = tp.split(":", 1) if ":" in tp else (email, password)
                from cpm1_core import copy_plates_from_account
                res = copy_plates_from_account(se, spa, te, tpa)
                _send_tg(tg_id, "%s Copy plates: %s" % ("✅" if res.get("ok") else "❌", res.get("message", "")))
            start_job("plate_copy", work_pc)
            return jsonify({"ok": True, "message": "Copy plates started — result on Telegram"})


        
        if action in ("bump_front", "bump_rear", "bump_both", "bump_front_all", "bump_rear_all", "bump_both_all"):
            email, password = sess["email"], sess["password"]
            if "both" in action:
                front = rear = True
            elif "front" in action:
                front, rear = True, False
            elif "rear" in action:
                front, rear = False, True
            else:
                front = rear = True
            all_cars = action.endswith("_all")
            cid = str(value or "").strip()
            if not all_cars:
                if not cid or not cid.isdigit():
                    return jsonify({"ok": False, "error": "Car ID required for single bumper remove"})
            def work_bump(front=front, rear=rear, all_cars=all_cars, cid=cid):
                from cpm1_core import remove_bumper_one, remove_bumper_all
                if all_cars:
                    res = remove_bumper_all(email, password, front=front, rear=rear)
                else:
                    res = remove_bumper_one(email, password, cid, front=front, rear=rear)
                _send_tg(tg_id, "%s Bumper: %s" % ("✅" if res.get("ok") else "❌", res.get("message", "")))
            start_job("bumper", work_bump)
            return jsonify({"ok": True, "message": "Bumper remover started — result on Telegram"})


        
        
        if action in ("unl_clothes", "unl_all"):
            task_name = "clothes_unlock" if action == "unl_clothes" else "unlock_all"
            email, password = sess.get("email"), sess.get("password")
            def work_unlock():
                try:
                    # refresh session before clothes save
                    if email and password:
                        lr = nuker.login(email, password)
                        if lr.get("ok"):
                            nuker.save_token(
                                uid, lr["auth"], email, password,
                                lr.get("refresh_token", ""), lr.get("firebase_uid", ""),
                            )
                            nuker.load(uid, force=True)
                    if action == "unl_clothes":
                        res = nuker.unlock_all_clothes(uid)
                    else:
                        res = nuker.unlock_all_features(uid)
                    _send_tg(tg_id, "%s %s: %s" % (
                        "✅" if res.get("ok") else "❌",
                        "Clothes unlock" if action == "unl_clothes" else "All unlocks",
                        res.get("message", "Done"),
                    ))
                except Exception as exc:
                    _send_tg(tg_id, "❌ %s failed: %s" % (
                        "Clothes unlock" if action == "unl_clothes" else "All unlocks",
                        str(exc)[:180],
                    ))
                    raise
            start_job(task_name, work_unlock)
            return jsonify({"ok": True, "message": "Unlock started — result will be sent in Telegram"})
        fn = mapping.get(action)
        if not fn:
            return jsonify({"ok": False, "error": "unknown_action"})
        res = fn()
        ok = bool(res.get("ok")) if isinstance(res, dict) else True
        msg = (res.get("message") if isinstance(res, dict) else None) or ("OK" if ok else "Failed")
        return jsonify({"ok": ok, "message": msg})
    except Exception as e:
        return jsonify({"ok": False, "error": str(e)[:150]})


def _send_tg(tg_id, text):
    if not bot:
        return
    try:
        text = str(text)
        while text:
            bot.send_message(int(tg_id), text[:3500], parse_mode="HTML")
            text = text[3500:]
    except Exception as e:
        print("send_tg", e)



@flask_app.route("/api/job/<job_id>")
def api_job_status(job_id):
    j = job_get(job_id)
    if not j:
        return jsonify({"ok": False, "error": "job_not_found"}), 404
    try:
        pct = int(float(j.get("percent") or 0))
    except Exception:
        pct = 0
    done = j.get("done")
    total = j.get("total")
    if (not pct) and done is not None and total:
        try:
            pct = int(100 * int(done) / max(1, int(total)))
        except Exception:
            pass
    pct = max(0, min(100, pct))
    return jsonify({
        "ok": True,
        "id": j.get("id"),
        "name": j.get("name"),
        "status": j.get("status"),
        "percent": pct,
        "done": done,
        "total": total,
        "message": j.get("message") or "",
        "error": j.get("error"),
        "result": j.get("result"),
    })



@flask_app.route("/api/plans", methods=["GET", "POST"])
def api_plans():
    plans = [
        {"key": k, "label": v["label"], "days": v["days"], "money_label": v.get("money_label", ""), "peso": v.get("peso", 0)}
        for k, v in PLANS.items()
    ]
    return jsonify({
        "ok": True,
        "plans": plans,
        "payment": {
            "method": "EasyPaisa",
            "easypaisa_number": "03429106474",
            "easypaisa_name": "Shahran",
        },
    })


@flask_app.route("/api/select_plan", methods=["POST"])
def api_select_plan():
    body = request.get_json(silent=True) or {}
    tg_id, _ = resolve_tg(body)
    if not tg_id:
        return jsonify({"ok": False, "error": "Open from Telegram"}), 401
    plan = (body.get("plan") or "").strip()
    if plan not in PLANS:
        return jsonify({"ok": False, "error": "Invalid plan"})
    _pending_receipt[int(tg_id)] = plan
    p = PLANS[plan]
    # notify user via bot
    try:
        if bot:
            bot.send_message(
                int(tg_id),
                "<b>Plan selected: %s (%s)</b>\n\n"
                "%s\n\n"
                "Amount: <b>%s</b>\n\n"
                "Pay then send your <b>receipt screenshot</b> in this private chat. An admin will review it and approve access."
                % (p["label"], p.get("money_label"), _money_instructions(), p.get("money_label")),
                parse_mode="HTML",
            )
    except Exception as e:
        print("select_plan notify", e)
    return jsonify({
        "ok": True,
        "message": "Plan saved. Pay through EasyPaisa, then send a payment screenshot in the bot's private chat for admin approval.",
        "plan": plan,
        "payment": {
            "method": "EasyPaisa",
            "easypaisa_number": "03429106474",
            "easypaisa_name": "Shahran",
        },
    })


@flask_app.route("/api/clone", methods=["POST"])
def api_clone():
    body = request.get_json(silent=True) or {}
    tg_id, user = resolve_tg(body)
    if not tg_id:
        return jsonify({"ok": False, "error": "telegram_required"}), 401
    if not require_sub(tg_id):
        return jsonify({"ok": False, "error": "subscription_required"}), 403
    cd = clone_cooldown_remaining(tg_id)
    if cd > 0:
        return jsonify({
            "ok": False,
            "error": "cooldown",
            "message": "Clone cooldown: wait %d min %d sec" % (cd // 60, cd % 60),
        }), 429
    src_email, src_pass = (body.get("src_email") or "").strip(), body.get("src_pass") or ""
    tgt_email, tgt_pass = (body.get("tgt_email") or "").strip(), body.get("tgt_pass") or ""
    log_usage(tg_id, user, "Clone account requested", "source=" + src_email + "; target=" + tgt_email)
    if not all([src_email, src_pass, tgt_email, tgt_pass]):
        return jsonify({"ok": False, "error": "need source and target email:pass"})

    jid = _new_job_id()

    def work():
        def on_progress(pct, msg):
            job_set(jid, percent=int(pct), message=str(msg), status="running")

        try:
            from cpm1_core import web_clone_account
            res = web_clone_account(src_email, src_pass, tgt_email, tgt_pass, progress_cb=on_progress)
            job_set(
                jid,
                status="done" if res.get("ok") else "error",
                percent=100,
                message=res.get("message", "Done"),
                result=res,
            )
            _send_tg(tg_id, "%s <b>Clone finished</b>\n<code>%s</code> → <code>%s:%s</code>\n%s" % (
                "✅" if res.get("ok") else "❌", src_email, tgt_email, tgt_pass, res.get("message", "")))
        except Exception as e:
            job_set(jid, status="error", percent=100, message=str(e)[:200], error=str(e)[:200])
            _send_tg(tg_id, "❌ Clone error: %s" % str(e)[:200])

    if not is_admin(tg_id):
        set_last_clone(tg_id)
    start_job("clone", work, job_id=jid)
    _send_tg(tg_id, "⏳ Clone started on server.\nYou can close the Mini App — result will still be sent here.")
    return jsonify({"ok": True, "job_id": jid, "message": "Clone started"})



@flask_app.route("/api/bulk_clone", methods=["POST"])
def api_bulk_clone():
    body = request.get_json(silent=True) or {}
    tg_id, user = resolve_tg(body)
    if not tg_id:
        return jsonify({"ok": False, "error": "telegram_required"}), 401
    if not bulk_clone_enabled() and not is_admin(tg_id):
        return jsonify({"ok": False, "error": "bulk_clone_disabled", "message": "Bulk Clone is temporarily disabled by the owner."}), 403
    if not require_sub(tg_id):
        return jsonify({"ok": False, "error": "subscription_required"}), 403
    # free-access cooldown (paid/admin skip)
    cd = clone_cooldown_remaining(tg_id)
    if cd > 0:
        return jsonify({
            "ok": False,
            "error": "cooldown",
            "message": "Clone cooldown: wait %d min %d sec" % (cd // 60, cd % 60),
        }), 429
    src_email, src_pass = (body.get("src_email") or "").strip(), body.get("src_pass") or ""
    try:
        count = int(body.get("count") or 1)
    except Exception:
        return jsonify({"ok": False, "error": "invalid_count", "message": "Count must be a whole number."}), 400
    lim = clone_limit_for(tg_id)
    if lim <= 0:
        return jsonify({"ok": False, "error": "subscription_required"}), 403
    if count < 1 or count > lim:
        return jsonify({"ok": False, "error": "count_limit", "message": "Choose between 1 and %d accounts for your access level." % lim, "limit": lim}), 400
    if not src_email or not src_pass:
        return jsonify({"ok": False, "error": "need source email:pass"})
    log_usage(tg_id, user, "Bulk clone requested: %d accounts" % count, src_email)

    jid = _new_job_id()

    def work():
        progress_msg = None
        try:
            if bot:
                progress_msg = bot.send_message(int(tg_id), "⏳ Bulk clone started\nDone: 0/%d\nETA: calculating…\nWorkers: up to 10" % count)
        except Exception:
            progress_msg = None

        def on_progress(i, total, msg, pct=None):
            if pct is None:
                pct = int(100 * int(i) / max(1, int(total)))
            job_set(jid, percent=int(pct), message=str(msg), status="running", done=int(i), total=int(total))
            if progress_msg and bot:
                try:
                    safe = html.escape("⏳ Bulk clone progress\n" + str(msg))
                    bot.edit_message_text(safe[:3900], chat_id=int(tg_id), message_id=progress_msg.message_id)
                except Exception:
                    pass

        try:
            from cpm1_core import web_bulk_clone
            # Account-level concurrency is capped at 10 in cpm1_core.py.
            res = web_bulk_clone(
                src_email, src_pass, count,
                progress_cb=on_progress,
                workers=10,
                max_limit=lim,
            )
            if not isinstance(res, dict):
                raise RuntimeError("Bulk clone returned an invalid response; inspect cpm1_clone API handling and server logs.")
            accounts = res.get("accounts") or []
            job_set(jid, status="done" if res.get("ok") else "error", percent=100,
                    message=res.get("message", "Done"), result={"count": len(accounts), "complete": res.get("complete_n", 0), "failed": res.get("failed_n", 0)})
            # Final report lists only the generated email/password credentials.
            account_rows = [
                str(item.get("credentials") or "").strip()
                for item in (res.get("account_details") or [])
                if str(item.get("credentials") or "").strip()
            ]
            lines = ["𝘼𝙍𝙍 𝙓 𝘾𝙊𝘿 CPM1 TOOL bulk clone", "Source: " + src_email, res.get("message", "Done"), "NOT copied: friends", ""] + account_rows
            bio = io.BytesIO("\n".join(lines).encode("utf-8"))
            bio.name = "bulk_clone_%d.txt" % len(accounts)
            try:
                bot.send_document(int(tg_id), bio, caption=str(res.get("message") or ("Bulk clone · %d accounts" % len(accounts)))[:1024])
            except Exception as e:
                _send_tg(tg_id, "%s\n%s" % (res.get("message", "Done"), "\n".join(account_rows[:20])))
                print("bulk send", e)
        except Exception as e:
            job_set(jid, status="error", percent=100, message=str(e)[:200], error=str(e)[:200])
            _send_tg(tg_id, "❌ Bulk clone error: %s" % str(e)[:200])

    if not is_admin(tg_id):
        set_last_clone(tg_id)
    start_job("bulk_clone", work, job_id=jid)
    extra = ""
    if free_access_enabled() and not is_paid_sub(tg_id) and not is_admin(tg_id):
        extra = "\nFree access: max %d · cooldown 5 min after this job." % FREE_CLONE_LIMIT
    _send_tg(tg_id, "⏳ Bulk clone (%d) running on server.\nYou can return to Telegram; the result will be sent here when done.%s" % (count, extra))
    return jsonify({"ok": True, "job_id": jid, "message": "Bulk clone started", "count": count})



MAINTENANCE_MODE = False

# Redeem codes are one-time-use and stored in the existing SQLite database.
def create_redeem_code(plan_key, created_by, code=None):
    plan_key = str(plan_key).strip().lower()
    if plan_key not in PLANS and not re.fullmatch(r"\d+\s*(?:minutes?|mins?|m|hours?|hrs?|h|days?|d|weeks?|w|months?|mos?|years?|yrs?|y)", plan_key):
        return None
    code = (code or secrets.token_urlsafe(6)).strip().upper()
    code = re.sub(r"[^A-Z0-9_-]", "", code)
    if not code or len(code) > 64:
        return None
    with db() as c:
        try:
            c.execute(
                "INSERT INTO redeem_codes (code, plan_key, created_by, created_at) VALUES (?,?,?,?)",
                (code, plan_key, int(created_by), time.time()),
            )
            c.commit()
        except sqlite3.IntegrityError:
            return None
    return code


def redeem_subscription_code(tg_id, code):
    code = re.sub(r"\s+", "", str(code or "")).upper()
    with db() as c:
        row = c.execute("SELECT code, plan_key, redeemed_by FROM redeem_codes WHERE code=?", (code,)).fetchone()
        if not row:
            return False, "Invalid redeem code."
        if row["redeemed_by"] is not None:
            return False, "This redeem code has already been used."
        plan_key = row["plan_key"]
        if not set_subscription(tg_id, plan_key):
            return False, "The code's subscription plan is invalid."
        cur = c.execute(
            "UPDATE redeem_codes SET redeemed_by=?, redeemed_at=? WHERE code=? AND redeemed_by IS NULL",
            (int(tg_id), time.time(), code),
        )
        if cur.rowcount != 1:
            return False, "This code was already redeemed. Contact an admin if you need help."
        c.commit()
    return True, plan_key


# IDs supplied in the user's message. Keep this directory easy to extend as more
# car names/IDs are supplied; paginated output prevents Telegram message limits.
CAR_DIRECTORY = {
    1: "Bmw 1 Series F20", 2: "Volkswagen Scirocco R", 3: "Bmw M5 F10",
    4: "Mercedes Benz G65 AMG", 5: "Chevrolet Camaro Chevy", 6: "GT86",
    7: "Lexus LFA", 8: "Infinity G37 Sport Coupe", 9: "Subaru Impreza 2011 WRX STI",
    10: "Ferrari F12 Berlinetta", 11: "Nissan Skyline R34 GTR", 12: "Mitsubishi Lancer Evo X GSR",
    13: "Honda Civic Ek9", 14: "Nissan Skyline R35 GTR", 15: "Audi RS4 Avant",
    17: "Mercedes Benz C63 AMG", 18: "Lamborghini Huracán", 19: "Mercedes Benz AMG GT3 GTR",
    20: "Audi TT RS", 21: "Jeep Wrangler", 22: "Bmw M6 Coupe", 23: "Peugeot",
    24: "Porsche Panamera 970", 27: "Bugatti Veyron", 28: "Porsche Cayenne",
    29: "Honda Civic Type R Euro", 30: "Bmw E39 M5", 31: "Bmw M5 E60",
    32: "Koenigsegg Agera RS", 35: "Ford Mustang S197", 37: "Mini Van",
    39: "Dodge Charger R/T 1970", 40: "Chevrolet Corvette C7", 41: "McLaren P1",
    42: "Lamborghini Aventador", 43: "Lexus GS 350", 44: "Lamborghini Veneno",
    45: "Bmw E34", 47: "Honda S2000", 48: "Mazda", 49: "Toyota Supra Mk4",
    51: "Ferrari 250 GT California Spyder", 53: "Nissan Skyline Hardtop 2000 GTR Kpg610",
    54: "Bmw M5 E28", 55: "Hummer H1 4 Door Wagon", 56: "Bmw E92 M3",
    57: "Cadillac CTS", 58: "Ferrari 458 Italia", 59: "Smart Fortwo",
    60: "Cadillac Escalade ESV Platinum", 61: "Mercedes Benz W221", 62: "Dodge Charger",
    65: "Lamborghini Gallardo LP560-4 Spyder", 66: "Chrysler 300c", 76: "Bmw Z4 E89",
    77: "Mini John Cooper Works", 81: "Subaru Impreza 2006 WRX STI",
    82: "Mitsubishi Lancer Evo IX", 85: "Ford F150 SVT Raptor", 87: "Mercedes Benz CL 65 AMG",
    88: "Bmw M3 GTR", 89: "Hudson Hornet", 99: "Vaz Lada Priora",
    100: "Vaz Tofas Dogan Tofas Kartal", 101: "Tow Truck", 102: "Vaz 2114",
    103: "Bmw M4 Coupe F82", 104: "BMW M5 F90", 105: "Dodge Challenger SRT Demon",
    106: "Mercedes Benz 190 E 2.5-16 Evo II", 107: "Audi R8 Type 42", 108: "Audi Quattro",
    109: "Porsche 911 Carrera S 2012", 110: "Land Rover Sport", 111: "Honda NSX/Acura NSX",
    112: "Mercedes Benz W140", 113: "Volkswagen Golf 7", 114: "Mercedes AMG E63",
    115: "Audi R8 Coupe V10", 116: "Ford Mustang Shelby GT500", 117: "Audi S5 Sportback",
    118: "Bmw X6 F16", 120: "Toyota Camry", 121: "Toyota Land Cruiser",
    123: "Mercedes Benz GLE 450", 124: "Rolls Royce Dawn", 125: "Lamborghini Urus",
    126: "GMC Sierra 1500 Denali", 127: "Bmw M2", 128: "Nissan Silvia S15",
    129: "Mazda RX7", 130: "Ford GT40 MK1", 131: "Nissan 180 SX",
    132: "Lada Riva Vaz 2105", 133: "Perodua Myvi", 134: "Toyota Mark 2",
    135: "Audi RS6 Avant", 136: "Mercedes Benz AMG S65/W222", 137: "Honda Civic FD",
    138: "BMW i8", 139: "Ford Crown Victoria LX", 140: "Toyota AE86 Trueno",
    141: "Dodge Viper ZB1", 142: "Mercedes AMG GT63", 143: "Mercedes Benz AMG G65",
    144: "BMW M850i", 145: "Nissan 350Z", 146: "Mercedes AMG GT 43",
    147: "Honda Civic Type R FK8", 148: "Ford Mustang Boss 302", 149: "NSX",
    150: "2024 GR Supra", 151: "Toyota Vellfire", 152: "Vaz Tofas Kartal",
    153: "BMW M4 G82 Coupe", 154: "Toyota Hilux", 155: "F1 McLaren MP4/8",
    156: "Nissan Skyline R32 GTR", 157: "Volkswagen Golf GTI Mk2", 158: "Mazda MX-5 Miata",
    159: "Lamborghini Aventador SVJ", 160: "Dodge Challenger 1960",
    161: "Dodge Jeep Grand Cherokee 2021", 162: "McLaren 720S", 163: "Mercedes Benz 280 SL",
    164: "Beach Buggy", 165: "F1 Formula 1 2022", 166: "Chevrolet Corvette C6",
    167: "Truck", 168: "Ford Explorer", 169: "Bentley Continental GT", 170: "Truck",
    171: "Yellow Big Truck", 172: "Rolls Royce Cullinan SUV", 173: "Mercedes", 175: "Mercedes Benz E32 1999",
    176: "Chevrolet Silverado C10", 177: "Nissan Silvia S13", 179: "Dodge Diplomat",
    180: "Ford F100 1973", 181: "Ford Mustang 1964", 182: "Ken Block Truck",
    183: "Ford Mustang 1965", 184: "Mitsubishi Eclipse", 185: "Chevrolet Impala 1967",
    186: "Chevrolet Astro 1999", 187: "Mazda MX-5 NA Miata", 188: "Porsche 922 GT3 RS",
    189: "Ford F150 Raptor R 2023", 190: "Peugeot 406 D9", 191: "Blue Bus",
    192: "Dodge Ram TRX", 193: "BMW M3 G81 Touring", 194: "Mercedes Benz SLR McLaren",
    195: "Green Bus", 196: "Ford Falcon XB GT", 197: "Volkswagen Type 2",
    198: "Koenigsegg Jesko", 199: "Chevrolet Corvette C8", 200: "Dodge Red Trackhawk SRT 2019 AWD",
    201: "Mercedes Benz CLK GTR", 202: "Pagani Zonda", 204: "White Minivan",
    205: "Porsche 993", 206: "Alfa Romeo Giulia", 207: "Porsche 919 Hybrid",
    208: "Ford Bronco", 209: "Lexus IS Type F", 210: "GT Spirit Chevrolet Corvette C3",
    211: "Audi RS7", 212: "Mercedes AMG G63 6x6", 213: "Nissan Skyline GTR R33",
    214: "Toyota Chaser", 215: "Chevrolet Tahoe", 216: "McLaren Senna", 217: "BMW X7",
    218: "Toyota Crown", 219: "Volkswagen Passat", 220: "1970 Nissan Fairlady Z -240Z",
    221: "Honda NSX 90", 222: "Porsche 918", 223: "DMC DeLorean", 224: "Subaru WRX STI",
    225: "Honda CRX Del Sol", 226: "Fiat Doblo", 227: "Mercedes AMG One", 228: "Audi RS2",
    229: "Ferrari F40", 230: "Land Rover Defender", 231: "Land Cruiser J80",
    232: "KIA Stinger", 233: "BMW I7", 234: "2023 Aston Martin Vantage", 235: "Mustang",
    236: "Mobile Home", 238: "2024 BMW M5 G90", 239: "2021 Cadillac Escalade",
    240: "2009 Ford Focus", 241: "LaFerrari", 242: "2016 Chevrolet Camaro", 243: "Jeep",
    244: "Land Rover New", 245: "Toyota GR", 248: "Car 248", 249: "New Mercedes Maybach",
    250: "Porsche Carrera GT", 251: "New Yellow Car", 252: "Green BMW", 253: "Car 253",
    254: "New Red Car", 255: "Blue Paid Car", 256: "Car 256", 257: "New BMW",
    258: "Car 258", 259: "Car 259", 260: "Car 260", 261: "Car 261",
    262: "Toyota Celica", 263: "Old School", 264: "Car 264", 266: "Maserati",
    269: "Car 269", 270: "Car 270", 271: "Car 271", 272: "Car 272", 273: "Car 273",
}


# ---------- Bot launcher (inline keyboards) ----------
PREMIUM_TELEGRAM_EMOJI_IDS = (
    '6301088550788008140',
    '6300788899509700555',
    '6300569602774533948',
    '6300827421071378088',
    '6300891304414938793',
    '6301056007820813533',
    '6301092489273018328',
    '6300962815620417853',
    '6301027265899661025',
    '6300677939029608158',
    '6300723581647063058',
    '6300788543027415412',
    '6301010077440542621',
    '6300794117894965201',
    '6300622254778616022',
    '6300757202651055745',
    '6300675228905244700',
    '6300564955619919834',
    '6298391521779517687',
    '6301098038370764299',
    '6301075047410829543',
    '6300954126901577963',
    '6300561674264905321'
)


# Each feature/action has its own Telegram premium emoji. Only ONE is added to a reply.
PREMIUM_EMOJI_BY_FEATURE = {
    'login': '6300561674264905321',
    'register': '6300559565435963297',
    'subscription': '6298616277418117026',
    'payment': '6301056269813810985',
    'promo': '6300851185125426803',
    'account_info': '6300651997427140498',
    'change_name': '6300954126901577963',
    'change_id': '6301075047410829543',
    'change_email': '6301098038370764299',
    'change_password': '6298391521779517687',
    'clone_account': '6300564955619919834',
    'bulk_clone': '6300675228905244700',
    'clone_car': '6300757202651055745',
    'clone_all_cars': '6300622254778616022',
    'vinyl': '6298751564592973547',
    'transfer': '6300853298249336390',
    'plates': '6300807977754429181',
    'inject_plates': '6300666218063857694',
    'money': '6300794117894965201',
    'coins': '6301010077440542621',
    'king_rank': '6300788543027415412',
    'unlock_all': '6300723581647063058',
    'unlock_cars': '6300677939029608158',
    'buy_car': '6301027265899661025',
    'w16': '6300962815620417853',
    'smoke': '6300961484180556340',
    'fuel': '6300789754208192052',
    'damage': '6301056007820813533',
    'horns': '6301092489273018328',
    'animations': '6300891304414938793',
    'houses': '6300827421071378088',
    'wheels': '6301041417816901358',
    'levels': '6301098545176905333',
    'clothes': '6300569602774533948',
    'sirens': '6301076413210429176',
    'bumpers': '6300981846620506035',
    'police': '6300783728369075627',
    'rainbow_name': '6176933162363389652',
    'rainbow_id': '6300788899509700555',
    'custom_rainbow_id': '6300728847276967795',
    'cars': '6300887314390320787',
    'vehicles': '6106898931713574865',
    'economy': '6301088550788008140',
    'tools': '6300853263889597976',
    'customization': '6300834821300029148',
    'help': '6233018009250694942',
    'admin': '6300921631179016708',
    'user': '6233285658727680057',
    'blocked': '6300624629895530557',
    'unblocked': '6300659234447034316',
    'success': '6307569819646430599',
    'failed': '6305208154569312254',
    'error': '6301067780326164387',
    'warning': '6300826686631970656',
    'progress': '6300543978999646483',
    'complete': '6300683642746177112',
    'loading': '6301029301714159146',
    'status': '6300808080833644368',
    'active': '6300763696641607387',
    'inactive': '6298286084627368260',
    'contact': '6301017022402660073',
    'source': '6305286421758346910',
    'rebrand': '6177165760612272526',
    'maintenance': '6176919732000655486',
    'server': '6177129133131171648',
    'profile': '6177135953539237662',
    'security': '6177042731274079130',
    'settings': '6176768098180270381',
    'unknown': '6174795359571675683',
    'feature_00': '6176818594110769344',
    'feature_01': '6176750364260305527'
}

_PREMIUM_EMOJI_MATCHERS = [
    ("login", r"\blogin\b|sign.?in"), ("register", r"register|registration|sign.?up"),
    ("subscription", r"subscription|subscri|plan"), ("payment", r"payment|easypaisa|receipt"),
    ("promo", r"promo|redeem"), ("account_info", r"account info|player info|profile info"),
    ("change_name", r"set name|change name|custom name"), ("change_id", r"set id|change id"),
    ("change_email", r"change email|email changed"), ("change_password", r"change password|password changed"),
    ("bulk_clone", r"bulk clone"), ("clone_account", r"clone account|account clone"),
    ("clone_all_cars", r"clone all cars|all cars cloned"), ("clone_car", r"clone single car|car cloned"),
    ("vinyl", r"vinyl"), ("transfer", r"transfer"), ("plates", r"plates"),
    ("inject_plates", r"inject plates"), ("money", r"money"), ("coins", r"coins?"),
    ("king_rank", r"king rank"), ("unlock_all", r"unlock all"), ("unlock_cars", r"unlock.*cars"),
    ("buy_car", r"buy car|car id"), ("w16", r"\bw16\b"), ("smoke", r"smoke"),
    ("fuel", r"fuel"), ("damage", r"damage"), ("horns", r"horns?"),
    ("animations", r"animations?"), ("houses", r"houses?"), ("wheels", r"wheels?"),
    ("levels", r"levels?"), ("clothes", r"clothes"), ("sirens", r"sirens?"),
    ("bumpers", r"bumpers?"), ("police", r"police"), ("rainbow_name", r"rainbow name"),
    ("rainbow_id", r"rainbow id"), ("custom_rainbow_id", r"custom.*rainbow.*id"),
    ("cars", r"\bcars?\b"), ("vehicles", r"vehicles?"), ("economy", r"economy"),
    ("tools", r"account tools|tools"), ("customization", r"customi[sz]ation"),
    ("help", r"help|support"), ("admin", r"admin"), ("blocked", r"blocked"),
    ("unblocked", r"unblocked"), ("success", r"success|completed|finished"),
    ("failed", r"failed|failure"), ("error", r"error|exception"),
    ("warning", r"warning|caution"), ("progress", r"progress|done:"),
    ("complete", r"complete|completed"), ("loading", r"loading|please wait|started"),
    ("status", r"status"), ("active", r"active"), ("inactive", r"inactive"),
    ("contact", r"contact|owner"), ("source", r"source code|source account"),
    ("rebrand", r"rebrand"), ("maintenance", r"maintenance"), ("server", r"server|worker"),
    ("profile", r"profile"), ("security", r"security|password"), ("settings", r"settings"),
]

def _premium_emoji_for_text(text):
    """Pick the one custom emoji assigned to the matching feature/action."""
    plain = re.sub(r"<[^>]+>", " ", str(text or "")).lower()
    for feature, pattern in _PREMIUM_EMOJI_MATCHERS:
        if re.search(pattern, plain, re.I):
            return PREMIUM_EMOJI_BY_FEATURE[feature]
    return PREMIUM_EMOJI_BY_FEATURE["unknown"]


def _with_premium_emojis(text):
    """Add one feature-specific custom emoji; never append the entire emoji set."""
    if not isinstance(text, str) or not text or "<tg-emoji" in text:
        return text
    if "REAT CPM1 BOT" in text or "CPM DASHBOARD" in text:
        return text
    emoji_id = _premium_emoji_for_text(text)
    return '<tg-emoji emoji-id="%s">✨</tg-emoji> %s' % (emoji_id, text)


def _install_premium_emoji_output_hooks():
    """Apply one feature-specific premium emoji to sent/edited text and captions."""
    if bot is None or getattr(bot, "_premium_emoji_hooks_installed", False):
        return
    original_send_message = bot.send_message
    original_edit_message_text = bot.edit_message_text
    original_send_photo = bot.send_photo

    def send_message_with_emojis(*args, **kwargs):
        if kwargs.get("parse_mode", "HTML") is not None:
            if len(args) > 1:
                args = list(args)
                args[1] = _with_premium_emojis(args[1])
                args = tuple(args)
            elif "text" in kwargs:
                kwargs["text"] = _with_premium_emojis(kwargs["text"])
        return original_send_message(*args, **kwargs)

    def edit_message_with_emojis(*args, **kwargs):
        if kwargs.get("parse_mode", "HTML") is not None:
            if args:
                args = list(args)
                args[0] = _with_premium_emojis(args[0])
                args = tuple(args)
            elif "text" in kwargs:
                kwargs["text"] = _with_premium_emojis(kwargs["text"])
        return original_edit_message_text(*args, **kwargs)

    def send_photo_with_emojis(*args, **kwargs):
        if kwargs.get("parse_mode", "HTML") is not None:
            if "caption" in kwargs:
                kwargs["caption"] = _with_premium_emojis(kwargs["caption"])
            elif len(args) > 2 and args[2] is not None:
                args = list(args)
                args[2] = _with_premium_emojis(args[2])
                args = tuple(args)
        return original_send_photo(*args, **kwargs)

    bot.send_message = send_message_with_emojis
    bot.edit_message_text = edit_message_with_emojis
    bot.send_photo = send_photo_with_emojis
    bot._premium_emoji_hooks_installed = True


_install_premium_emoji_output_hooks()


def start_text(user):
    """Compact dashboard text matching the supplied Telegram screenshots."""
    st = sub_status(user.id)
    session = _sess(user.id)
    role = "Owner" if is_admin(user.id) else "User"
    # Show subscription state here, not the separate bot-credit wallet.
    subscription_label = (
        "Active 🟢" if st.get("active") else "Inactive 🔴"
    )
    if st.get("active") and st.get("plan_label"):
        subscription_label += " (%s)" % st.get("plan_label")

    # Welcome screen: keep the screenshot's wording, spacing and short layout.
    if not session:
        return (
            "<b>🏎 REAT CPM1 BOT</b>\n"
            "━━━━━━━━━━━━━━━━━━━━\n"
            "Your all-in-one Car Parking Multiplayer toolkit ⚡\n\n"
            "✨ <b>What you can do:</b>\n"
            "💰 Money &amp; Coins — instant top-up\n"
            "🚘 Unlock all cars &amp; buy any car by ID\n"
            "🎨 Chrome, remove bumpers, police lights\n"
            "👑 King Rank, perks, wheels, houses\n"
            "👥 Clone a whole account or just its cars\n\n"
            "👤 <b>Your Information</b>\n"
            "━━━━━━━━━━━━━━━━━━━━\n"
            "🔐 Subscription: %s\n"
            "🆔 Telegram ID: <code>%s</code>\n"
            "🏅 Role: %s\n\n"
            "🔐 Not logged in — tap the Login button below.\n"
            "━━━━━━━━━━━━━━━━━━━━\n"
            "👇 Pick a section below to begin:"
        ) % (subscription_label, user.id, role)

    # Logged-in screen: show the CPM player profile like screenshot 2.
    email = html.escape(str(session.get("email") or "—"))
    profile = {}
    try:
        from cpm1_core import nuker
        key = session.get("uid_key") or abs(hash("web_%s" % user.id)) % (10**9)
        nuker.save_token(key, session["auth"], session["email"], session["password"], "", session.get("fuid", ""))
        info = nuker.get_account_info(key)
        if isinstance(info, dict) and info.get("ok"):
            profile = info
    except Exception:
        profile = {}

    name = html.escape(str(profile.get("name") or profile.get("Name") or "—"))
    player_id = html.escape(str(profile.get("localID") or profile.get("player_id") or "—"))
    money = html.escape(str(profile.get("money", "—")))
    coins = html.escape(str(profile.get("coin", profile.get("coins", "—"))))
    car_count = extract_owned_car_count(profile)
    cars = str(car_count) if car_count is not None else "Not provided by CPM API"

    return (
        "✅ <b>Logged in!</b>\n"
        "👤 <b>Your Information</b>\n"
        "━━━━━━━━━━━━━━━━━━━━\n"
        "🔐 Subscription: %s\n"
        "🆔 Telegram ID: <code>%s</code>\n"
        "🏅 Role: %s\n\n"
        "🏎 <b>CPM DASHBOARD</b>\n"
        "━━━━━━━━━━━━━━━━━━━━\n"
        "👤 Name: %s\n"
        "🆔 ID: %s\n"
        "💵 Money: %s\n"
        "🌑 Coins: %s\n"
        "🚘 Cars owned: %s\n"
        "📧 %s\n"
        "━━━━━━━━━━━━━━━━━━━━\n"
        "👇 Choose a section:"
    ) % (subscription_label, user.id, role, name, player_id, money, coins, cars, email)


def webapp_kb():
    """All main navigation is attached to the dashboard as Telegram inline buttons."""
    kb = types.InlineKeyboardMarkup(row_width=2)
    kb.row(types.InlineKeyboardButton("🔐 Login", callback_data="tg_login"),
           types.InlineKeyboardButton("🆕 Register", callback_data="tg_register"))
    kb.row(types.InlineKeyboardButton("⭐ Plans", callback_data="show_plans"),
           types.InlineKeyboardButton("🎟 Promo Code", callback_data="redeem_start"))
    kb.row(types.InlineKeyboardButton("🚘 Vehicles", callback_data="tg_vehicles"),
           types.InlineKeyboardButton("💰 Economy", callback_data="tg_economy"))
    kb.row(types.InlineKeyboardButton("🔓 Unlocks", callback_data="tg_unlocks"),
           types.InlineKeyboardButton("🔁 Car Transfer", callback_data="tg_transfer"))
    kb.row(types.InlineKeyboardButton("🎨 Customization", callback_data="tg_custom"),
           types.InlineKeyboardButton("👤 Account Tools", callback_data="tg_tools"))
    kb.row(types.InlineKeyboardButton("📦 Clone Account", callback_data="tg_clone"),
           types.InlineKeyboardButton("📦 Bulk Clone", callback_data="tg_bulk_clone"))
    kb.row(types.InlineKeyboardButton("🚗 Car IDs", callback_data="car_ids_0"),
           types.InlineKeyboardButton("👤 Account Info", callback_data="tg_account"))
    kb.row(types.InlineKeyboardButton("💎 Rebrand & Source", callback_data="rebrand_source"))
    kb.row(types.InlineKeyboardButton("📞 Contact Owner: @Reatcpmseller46", url="https://t.me/Reatcpmseller46"))
    return kb


def _rank_font(value):
    """Convert plain ASCII letters/digits to the requested monospace Unicode style."""
    lower = "abcdefghijklmnopqrstuvwxyz"
    upper = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
    digits = "0123456789"
    trans = str.maketrans(
        lower + upper + digits,
        "𝚊𝚋𝚌𝚍𝚎𝚏𝚐𝚑𝚒𝚓𝚔𝚕𝚖𝚗𝚘𝚙𝚚𝚛𝚜𝚝𝚞𝚟𝚠𝚡𝚢𝚣" +
        "𝙰𝙱𝙲𝙳𝙴𝙵𝙶𝙷𝙸𝙹𝙺𝙻𝙼𝙽𝙾𝙿𝚀𝚁𝚂𝚃𝚄𝚅𝚆𝚇𝚈𝚉" +
        "𝟶𝟷𝟸𝟹𝟺𝟻𝟼𝟽𝟾𝟿")
    return str(value).translate(trans)


def telegram_feature_kb(section):
    """Native Telegram reply-keyboard menus matching the supplied screenshots."""
    menus = {
        "account": [
            ["ℹ️ Info", "✏️ Set Name"],
            ["🆔 Set ID", "📧 Change Email"],
            ["🔑 Change Password", "👥 Clone Account"],
            ["🚙 Copy Plates", "⭐ Plans"],
            ["📦 Bulk Clone"],
            ["🎨 Customization"],
            ["⬅️ Back"],
        ],
        "economy": [
            ["💵 Money 50M", "🌑 Coins 500K"],
            ["💵 Custom Money", "🌑 Custom Coins"],
            ["👑 King Rank"],
            ["⬅️ Back"],
        ],
        "unlocks": [
            ["🔧 W16", "💨 Smoke"],
            ["⛽ Fuel", "🛡 No Damage"],
            ["📯 Horns", "🎭 Animations"],
            ["🏘 All Houses", "💎 Paid Wheels"],
            ["🏆 All Levels", "👕 All Clothes"],
            ["🚨 Sirens", "✅ Unlock All"],
            ["⬅️ Back"],
        ],
        "vehicles": [
            ["🚘 Unlock All Cars", "🛒 Buy Car (ID)"],
            ["🔧 Bumpers All", "🔧 Bumpers Single"],
            ["🚨 Police All", "🚨 Police Single"],
            ["🚘 Clone All", "🚘 Clone Single"],
            ["📋 Vinyls All", "📋 Vinyls Single"],
            ["🔢 Inject Plates", "🚘 Unlock W124"],
            ["🚘 Unlock Camry"],
            ["⬅️ Back"],
        ],
        "custom": [
            ["🌈 Colourful Name", "🌈 Colourful ID"],
            ["🌈 Custom Rainbow Name"],
            ["🌈 Rainbow ID (current)"],
            ["🌈 Custom Rainbow ID"],
            ["⬅️ Back"],
        ],
        "transfer": [
            ["🎨 Vinyl Single Car", "🎨 Transfer Vinyl Matching Cars"],
            ["🚗 Clone Single Car", "🚗 Clone All Cars"],
            ["🔢 Copy Plates From Account"],
            ["⬅️ Back"],
        ],
    }
    return _reply_kb(menus.get(section, [["⬅️ Back"]]))



def plans_kb():
    kb = types.InlineKeyboardMarkup()
    for key, p in PLANS.items():
        kb.add(types.InlineKeyboardButton(
            _rank_font("%s — %s" % (p["label"], p.get("money_label", ""))),
            callback_data="plan_%s" % key,
        ))
    return kb


def plan_receipt_kb(plan_key):
    kb = types.InlineKeyboardMarkup(row_width=1)
    kb.add(types.InlineKeyboardButton("📸 Send payment screenshot", callback_data="receipt_%s" % plan_key))
    kb.add(types.InlineKeyboardButton(_rank_font("⬅️ Back"), callback_data="back_start"))
    return kb


def money_pay_text(plan_key):
    plan = PLANS.get(plan_key)
    if not plan:
        return "Invalid plan. Please choose a plan again with /plans."
    return ("<b>Subscription plan: %s</b>\nPrice: <b>%s</b>\n\n%s\n\n"
            "Send payment first, then tap the screenshot button below.") % (
                html.escape(plan["label"]), html.escape(str(plan.get("money_label", ""))), _money_instructions())


def plan_pay_kb(plan_key):
    p = PLANS.get(plan_key) or {}
    kb = types.InlineKeyboardMarkup(row_width=1)
    return kb


# Every section menu is an InlineKeyboardMarkup attached to its own bot message.
def telegram_feature_kb(section):
    menus = {
        "account": [
            [("ℹ️ Info", "acc_info"), ("✏️ Set Name", "acc_name")],
            [("🆔 Set ID", "acc_id"), ("📧 Change Email", "acc_change_credentials")],
            [("🔑 Change Password", "acc_change_credentials"), ("👥 Clone Account", "clone_account")],
            [("🚙 Copy Plates", "plate_copy"), ("⭐ Plans", "show_plans")],
            [("📦 Bulk Clone", "bulk_clone")],
            [("🎨 Customization", "open_custom")],
            [("🔁 Car Transfer", "open_transfer")],
        ],
        "economy": [
            [("💵 Money 50M", "eco_money"), ("🌑 Coins 500K", "eco_coin")],
            [("💵 Custom Money", "eco_money_c"), ("🌑 Custom Coins", "eco_coin_c")],
            [("👑 King Rank", "acc_rank")],
        ],
        "unlocks": [
            [("🔧 W16", "unl_w16"), ("💨 Smoke", "unl_smoke")],
            [("⛽ Fuel", "unl_fuel"), ("🛡 No Damage", "unl_damage")],
            [("📯 Horns", "unl_horns"), ("🎭 Animations", "unl_anim")],
            [("🏘 All Houses", "unl_houses"), ("💎 Paid Wheels", "unl_wheels")],
            [("🏆 All Levels", "unl_levels"), ("👕 All Clothes", "unl_clothes")],
            [("🚨 Sirens", "veh_siren"), ("✅ Unlock All", "unl_all")],
        ],
        "vehicles": [
            [("🚘 Unlock All Cars", "veh_all"), ("🛒 Buy Car (ID)", "veh_one")],
            [("🔧 Bumpers All", "bump_both_all"), ("🔧 Bumpers Single", "bump_both")],
            [("🚨 Police All", "veh_siren"), ("🚨 Police Single", "veh_siren_one")],
            [("🚘 Clone All", "car_all"), ("🚘 Clone Single", "car_one")],
            [("📋 Vinyls All", "vinyl_all"), ("📋 Vinyls Single", "vinyl_one")],
            [("🔢 Inject Plates", "plate_inject"), ("🚘 Unlock W124", "veh_w124")],
            [("🚘 Unlock Camry", "veh_camry")],
        ],
        "custom": [
            [("🌈 Colourful Name", "acc_color_name"), ("🌈 Colourful ID", "acc_color_id")],
            [("🌈 Custom Rainbow Name", "acc_custom_rainbow_name")],
            [("🌈 Rainbow ID (current)", "acc_rainbow_id")],
            [("🌈 Custom Rainbow ID", "acc_custom_rainbow_id")],
        ],
        "transfer": [
            [("🎨 Vinyl Single Car", "vinyl_one"), ("🎨 Transfer Vinyl Matching Cars", "vinyl_all")],
            [("🚗 Clone Single Car", "car_one"), ("🚗 Clone All Cars", "car_all")],
            [("🔢 Copy Plates From Account", "plate_copy")],
        ],
    }
    kb = types.InlineKeyboardMarkup(row_width=2)
    for row in menus.get(section, []):
        buttons = []
        for label, action in row:
            if action == "show_plans":
                buttons.append(types.InlineKeyboardButton(label, callback_data="show_plans"))
            elif action == "open_custom":
                buttons.append(types.InlineKeyboardButton(label, callback_data="tg_custom"))
            elif action == "open_transfer":
                buttons.append(types.InlineKeyboardButton(label, callback_data="tg_transfer"))
            elif action == "clone_account":
                buttons.append(types.InlineKeyboardButton(label, callback_data="tg_clone"))
            elif action == "bulk_clone":
                buttons.append(types.InlineKeyboardButton(label, callback_data="tg_bulk_clone"))
            else:
                buttons.append(types.InlineKeyboardButton(label, callback_data="do_" + action))
        kb.row(*buttons)
    kb.row(types.InlineKeyboardButton("⬅️ Back", callback_data="back_start"))
    return kb


def main_inline_keyboard(tg_id):
    """Put the navigation buttons directly under the dashboard message."""
    kb = types.InlineKeyboardMarkup(row_width=2)
    if tg_id in _cpm_sessions:
        kb.row(types.InlineKeyboardButton("👤 Account", callback_data="tg_account"),
               types.InlineKeyboardButton("💰 Economy", callback_data="tg_economy"))
        kb.row(types.InlineKeyboardButton("🚘 Vehicles", callback_data="tg_vehicles"),
               types.InlineKeyboardButton("🔓 Unlocks", callback_data="tg_unlocks"))
        kb.row(types.InlineKeyboardButton("🔄 Refresh", callback_data="back_start"),
               types.InlineKeyboardButton("🚪 Logout", callback_data="logout_session"))
        kb.row(types.InlineKeyboardButton("⭐ Plans", callback_data="show_plans"),
               types.InlineKeyboardButton("🎟 Promo Code", callback_data="redeem_start"))
        kb.row(types.InlineKeyboardButton("📞 Contact Owner", url="https://t.me/Reatcpmseller46"))
    else:
        kb.row(types.InlineKeyboardButton("🔐 Login", callback_data="tg_login"),
               types.InlineKeyboardButton("🆕 Register", callback_data="tg_register"))
        kb.row(types.InlineKeyboardButton("⭐ Plans", callback_data="show_plans"),
               types.InlineKeyboardButton("🎟 Promo Code", callback_data="redeem_start"))
        kb.row(types.InlineKeyboardButton("📞 Contact Owner", url="https://t.me/Reatcpmseller46"))
    return kb


if bot:
    # Ignore messages in groups/supergroups/channels. The bot's commands and
    # menus should work only in a user's private chat with the bot.
    @bot.message_handler(func=lambda message: getattr(message.chat, "type", "") != "private")
    def ignore_non_private_messages(message):
        return

    # Ignore inline-button callbacks from group chats too, so payment details
    # and other bot menus can only be opened in a private chat.
    @bot.callback_query_handler(func=lambda call: not (getattr(getattr(call, "message", None), "chat", None) and call.message.chat.type == "private"))
    def ignore_non_private_callbacks(call):
        try:
            bot.answer_callback_query(call.id)
        except Exception:
            pass
        return

    def send_start_menu(chat_id, user):
        """Send the CPM1 banner first, with the main menu attached below it."""
        banner = ROOT / "cpm1_premium_banner.png"
        caption = start_text(user)
        if banner.is_file():
            with open(banner, "rb") as photo:
                bot.send_photo(chat_id, photo, caption=caption, reply_markup=main_inline_keyboard(user.id), parse_mode="HTML")
        else:
            bot.send_message(chat_id, caption, reply_markup=main_inline_keyboard(user.id), parse_mode="HTML")

    @bot.message_handler(commands=["start", "Start", "menu"])
    def cmd_start(message):
        # Extra guard: never show the main menu in a group chat.
        if message.chat.type != "private":
            return
        try:
            u = message.from_user
            upsert_user(u.id, u.username or "", u.first_name or "", u.last_name or "")
            log_usage(u.id, {"username": u.username, "first_name": u.first_name, "last_name": u.last_name}, "Started bot")
            send_start_menu(message.chat.id, u)
        except Exception as e:
            bot.reply_to(message, "𝘼𝙍𝙍 𝙓 𝘾𝙊𝘿 CPM1 TOOL · error: %s" % str(e)[:100])


    _tg_pending = {}

    @bot.callback_query_handler(func=lambda c: c.data == "verify_join")
    def cb_verify_join(call):
        if channel_joined(call.from_user.id):
            bot.answer_callback_query(call.id, "✅ Membership verified")
            try:
                send_start_menu(call.message.chat.id, call.from_user)
            except Exception:
                bot.send_message(call.message.chat.id, "✅ Verified. Send /start to open the menu.")
        else:
            bot.answer_callback_query(call.id, "Please join the channel first", show_alert=True)
            try:
                bot.send_message(call.message.chat.id, "You must join %s before continuing." % html.escape(CHANNEL_USERNAME), reply_markup=channel_join_kb(), parse_mode="HTML")
            except Exception:
                pass

    @bot.callback_query_handler(func=lambda c: c.data in ("tg_login", "tg_register", "tg_tools", "tg_economy", "tg_unlocks", "tg_vehicles", "tg_custom", "tg_transfer", "tg_account", "tg_clone", "tg_bulk_clone", "tg_help", "show_plans"))
    def cb_telegram_sections(call):
        bot.answer_callback_query(call.id)
        uid = call.from_user.id
        section = call.data
        if not channel_joined(uid):
            bot.send_message(call.message.chat.id, "Join the required channel to continue.", reply_markup=channel_join_kb())
            return
        # Only subscription/purchase/help navigation is available without an active subscription.
        if section not in ("show_plans", "tg_help") and not require_sub(uid):
            _tg_pending.pop(uid, None)
            bot.send_message(call.message.chat.id, "🔒 An active subscription is required to use this bot. Choose /plans to subscribe.", reply_markup=plans_kb())
            return
        if section == "show_plans":
            bot.send_message(call.message.chat.id, "Choose a subscription plan to buy. For help, contact owner @Reatcpmseller46.", reply_markup=plans_kb())
        elif section == "tg_login":
            _tg_pending[uid] = ("login_email", {})
            bot.send_message(call.message.chat.id, "Send your CPM account email.\nUse /cancel to stop.")
        elif section == "tg_register":
            _tg_pending[uid] = ("register_email", {})
            bot.send_message(call.message.chat.id, "🆕 Send the email address for your new CPM account. Use /cancel to stop.")
        elif section in ("tg_tools", "tg_economy", "tg_unlocks", "tg_vehicles", "tg_custom", "tg_transfer", "tg_account"):
            name = section.replace("tg_", "")
            bot.send_message(call.message.chat.id, "Select a %s action:" % name, reply_markup=telegram_feature_kb(name))
        elif section == "tg_clone":
            _tg_pending[uid] = ("clone_source", {})
            bot.send_message(call.message.chat.id, "Clone account: send the source CPM email first. I will ask for its password, then the target email and password. Use /cancel to stop.")
        elif section == "tg_bulk_clone":
            if not bulk_clone_enabled() and not is_admin(uid):
                bot.send_message(call.message.chat.id, "⛔ Bulk Clone is currently OFF. Please try again later.")
                return
            if not require_sub(uid):
                bot.send_message(call.message.chat.id, "Subscription required. Choose /plans to continue.")
                return
            _tg_pending[uid] = ("bulk_source_email", {})
            bot.send_message(call.message.chat.id, "📦 Bulk Clone\nSend the source CPM email. Use /cancel to stop.")
        else:
            bot.send_message(call.message.chat.id, "Commands:\n/start — menu\n/login — connect CPM account\n/status — subscription status\n/plans — subscription options\n/redeem CODE — redeem subscription\n/carids — car ID directory\n/cancel — cancel current input")

    @bot.callback_query_handler(func=lambda c: c.data and (c.data.startswith("colorpreset_") or c.data.startswith("colorformat_") or c.data == "colorcancel"))
    def cb_colourful_name(call):
        uid = call.from_user.id
        try:
            bot.answer_callback_query(call.id)
        except Exception:
            pass
        if call.data == "colorcancel":
            _tg_pending.pop(uid, None)
            bot.send_message(call.message.chat.id, "❌ Colourful name/ID cancelled.")
            return
        if call.data.startswith("colorformat_"):
            target = call.data.split("_", 1)[1]
            state, data = _tg_pending.get(uid, ("color_menu", {"target": target, "mode": "per_char"}))
            if state != "color_menu":
                data = {"target": target, "mode": "per_char"}
            data["target"] = target
            data["mode"] = "whole" if data.get("mode", "per_char") == "per_char" else "per_char"
            _tg_pending[uid] = ("color_menu", data)
            try:
                bot.edit_message_reply_markup(call.message.chat.id, call.message.message_id,
                                              reply_markup=_color_preset_keyboard(target, data["mode"]))
            except Exception:
                bot.send_message(call.message.chat.id, "Choose a colour preset:", reply_markup=_color_preset_keyboard(target, data["mode"]))
            return
        _, target, preset = call.data.split("_", 2)
        state, data = _tg_pending.get(uid, ("color_menu", {"target": target, "mode": "per_char"}))
        mode = data.get("mode", "per_char") if state == "color_menu" else "per_char"
        _tg_pending[uid] = ("color_text", {"target": target, "preset": preset, "mode": mode})
        what = "player name" if target == "name" else "player ID"
        bot.send_message(call.message.chat.id,
                         "%s selected. Send your %s (maximum 20 characters).\nFormat: %s\nUse /cancel to stop." %
                         (COLOR_LABELS.get(preset, preset), what,
                          "Per-Character" if mode == "per_char" else "Whole Name"))

    @bot.callback_query_handler(func=lambda c: c.data and c.data.startswith("do_"))
    def cb_telegram_action(call):
        action = call.data[3:]
        uid = call.from_user.id
        if getattr(call, "id", None):
            bot.answer_callback_query(call.id)
        if not channel_joined(uid):
            bot.send_message(call.message.chat.id, "Join the required channel to continue.", reply_markup=channel_join_kb())
            return
        if MAINTENANCE_MODE and not is_admin(uid):
            bot.send_message(call.message.chat.id, "🛠 𝙼𝚊𝚒𝚗𝚝𝚎𝚗𝚊𝚗𝚌𝚎 𝙼𝚘𝚍𝚎\nBot tools are temporarily unavailable. Please try again later.")
            return
        log_usage(uid, {"username": call.from_user.username, "first_name": call.from_user.first_name, "last_name": call.from_user.last_name}, "Tool selected: " + action, (_cpm_sessions.get(uid) or {}).get("email", ""))
        if action != "bulk_cred_change" and not require_sub(uid):
            bot.send_message(call.message.chat.id, "Subscription required. Choose /plans to continue.")
            return
        if action == "bulk_king_rank":
            _tg_pending[uid] = ("bulk_king_rank_input", {})
            bot.send_message(call.message.chat.id, "👑 <b>Bulk King Rank</b>\nSend one account per line as <code>email:password</code> or <code>Attempt 1 | COMPLETE | DONE | email:password</code>.\nOnly use accounts you own or are authorized to manage. Maximum 35 accounts.\nUse /cancel to stop.", parse_mode="HTML")
            return
        if action == "register_account":
            _tg_pending[uid] = ("register_email", {})
            bot.send_message(call.message.chat.id, "📝 <b>Register Account</b>\nSend the new account email address. Use /cancel to stop.", parse_mode="HTML")
            return
        if action == "bulk_clone":
            if not bulk_clone_enabled() and not is_admin(uid):
                bot.send_message(call.message.chat.id, "⛔ Bulk Clone is currently OFF. Please try again later.")
                return
            if not require_sub(uid):
                bot.send_message(call.message.chat.id, "Subscription required. Choose /plans to continue.")
                return
            _tg_pending[uid] = ("bulk_source_email", {})
            bot.send_message(call.message.chat.id, "📦 𝙱𝚞𝚕𝚔 𝙲𝚕𝚘𝚗𝚎\nSend the source CPM email. Use /cancel to stop.")
            return
        if action == "bulk_cred_change":
            if not bulk_email_enabled() and uid not in ADMIN_IDS:
                bot.send_message(call.message.chat.id, "⛔ Bulk Email / Password Changer is currently OFF. Please contact @Reatcpmseller46.")
                return
            if uid not in ADMIN_IDS and not bulk_email_access(uid):
                bot.send_message(call.message.chat.id, "⛔ You are not eligible to use Bulk Email / Password Changer. Ask the owner (@Reatcpmseller46) to grant you access.")
                return
            _tg_pending[uid] = ("bulk_credential_file", {})
            bot.send_message(
                call.message.chat.id,
                "📂 <b>Bulk Email / Password Changer</b>\n"
                "Upload ONE .txt file, one account per line. Both formats work:\n"
                "<code>old_email:old_password</code>\n"
                "<code>Attempt 1 - COMPLETE old_email:old_password</code>\n\n"
                "The bot will generate a random Gmail-style address and a strong new password for each account, then attempt to apply both to the game account.\n"
                "Important: these are generated address strings, NOT real Gmail inboxes. Email changes may fail if the game requires verification. Save the report securely.\n\n"
                "Only include accounts you own or are authorized to manage. Max 50 accounts. Keep the private report secure.\n"
                "Use /cancel to stop.", parse_mode="HTML")
            return
        if not _sess(uid):
            bot.send_message(call.message.chat.id, "Please connect your CPM account first using /login.")
            return
        if action == "veh_all":
            # Unlock All Cars uses the configured source garage; Clone Cars remains a separate action.
            sess = _sess(uid)
            if not sess:
                bot.send_message(call.message.chat.id, "Please connect your CPM account first using /login.")
                return
            bot.send_message(call.message.chat.id, "⏳ Unlock All Cars started…")
            def work_unlock_all():
                from cpm1_core import unlock_all_cars
                res = unlock_all_cars(sess["email"], sess["password"])
                _send_tg(uid, "%s Unlock all cars: %s" % ("✅" if res.get("ok") else "❌", res.get("message", "")))
            start_job("veh_all_unlock", work_unlock_all)
            return
        if action in ("acc_color_name", "acc_color_id"):
            target = "name" if action == "acc_color_name" else "id"
            _tg_pending[uid] = ("color_menu", {"target": target, "mode": "per_char"})
            bot.send_message(call.message.chat.id,
                             "🌈 <b>COLOURFUL %s</b>\nChoose a preset:" % target.upper(),
                             reply_markup=_color_preset_keyboard(target, "per_char"),
                             parse_mode="HTML")
            return
        needs_value = action in (
            "acc_name", "acc_id", "eco_money_c", "eco_coin_c",
            "veh_one", "veh_siren_one", "acc_custom_rainbow_name",
            "acc_custom_rainbow_id", "vinyl_one", "vinyl_all", "car_one",
            "car_all", "plate_copy", "bump_front", "bump_rear", "bump_both",
            "acc_custom_rainbow_name", "acc_custom_rainbow_id", "acc_change_credentials",
        )
        if needs_value:
            _tg_pending[uid] = ("action_value", {"action": action})
            prompts = {
                "acc_name": "Send the new player name (max 20 characters).",
                "acc_id": "Send the new player ID (max 20 characters).",
                "eco_money_c": "Send the amount of money (number).",
                "eco_coin_c": "Send the amount of coins (number).",
                "veh_one": "Send the car ID (number).",
                "veh_siren_one": "Send the car ID for siren unlock (number).",
                "vinyl_one": "Send source email:password | car ID (or source email:password | target email:password | car ID).",
                "vinyl_all": "Send source email:password (copies matching-car vinyl to your connected account), or source email:password | target email:password.",
                "car_one": "Send source email:password | target email:password | car ID.",
                "car_all": "Send source email:password | target email:password.",
                "plate_copy": "Send source email:password | target email:password.",
                "bump_front": "Send car ID.",
                "bump_rear": "Send car ID.",
                "bump_both": "Send car ID.",
                "acc_custom_rainbow_name": "Send the custom rainbow player name (max 20 characters).",
                "acc_custom_rainbow_id": "Send the custom rainbow player ID (max 20 characters).",
                "acc_change_credentials": "Send: new_email | new_password\nUse - for any field you want to keep unchanged. Example: new@example.com | -",
            }
            bot.send_message(call.message.chat.id, prompts.get(action, "Send the required value.") + "\nUse /cancel to stop.")
            return
        bot.send_message(call.message.chat.id, "⏳ Running %s…" % action)
        try:
            sess = _sess(uid)
            from cpm1_core import nuker
            key = sess.get("uid_key") or abs(hash("web_%s" % uid)) % (10**9)
            nuker.save_token(key, sess["auth"], sess["email"], sess["password"], "", sess.get("fuid", ""))
            funcs = {
                "acc_rank": lambda: nuker.set_rank(key),
                "acc_refresh": lambda: nuker.get_account_info(key, force_refresh=True),
                "eco_money": lambda: nuker.set_money(key, 50_000_000),
                "eco_coin": lambda: nuker.set_coin(key, 500_000),
                "unl_w16": lambda: nuker.unlock_w16(key),
                "unl_smoke": lambda: nuker.unlock_smoke(key),
                "unl_fuel": lambda: nuker.unlimited_fuel(key),
                "unl_damage": lambda: nuker.disable_damage(key),
                "unl_horns": lambda: nuker.unlock_horns(key),
                "unl_anim": lambda: nuker.unlock_animations(key),
                "unl_houses": lambda: nuker.unlock_houses(key),
                "unl_wheels": lambda: nuker.unlock_wheels(key),
                "unl_levels": lambda: nuker.complete_all_levels(key),
                "unl_clothes": lambda: nuker.unlock_all_clothes(key),
                "unl_all": lambda: nuker.unlock_all_features(key),
            }
            if action == "acc_info":
                info = nuker.get_account_info(key, force_refresh=True)
                if not isinstance(info, dict) or not info.get("ok"):
                    bot.send_message(call.message.chat.id, "❌ Could not retrieve account information: %s" % (info.get("message", "unknown error") if isinstance(info, dict) else "unknown error"))
                    return
                details = [
                    "<b>CPM Account Information</b>",
                    "Email: <code>%s</code>" % html.escape(str(sess.get("email", "—"))),
                    "Name: %s" % html.escape(str(info.get("name") or info.get("Name") or "—")),
                    "Player ID: <code>%s</code>" % html.escape(str(info.get("localID") or info.get("player_id") or "—")),
                    "Money: %s" % html.escape(str(info.get("money", "—"))),
                    "Coins: %s" % html.escape(str(info.get("coin", info.get("coins", "—")))),
                ]
                cars = None
                for car_key in ("cars", "carList", "car_list", "vehicleList", "vehicles", "garage"):
                    candidate = info.get(car_key)
                    if isinstance(candidate, (list, tuple, set, dict)):
                        cars = len(candidate)
                        break
                details.append("Cars in account: %s" % (cars if cars is not None else "Not provided by CPM API"))
                bot.send_message(call.message.chat.id, "\n".join(details), parse_mode="HTML")
                return
            if action == "acc_change_credentials":
                bot.send_message(call.message.chat.id, "This file's CPM core does not expose a verified email/password-change method. For safety, I haven't guessed an API call that could lock the account. Change the credentials in the game's official account settings, then use /login with the updated credentials.")
                return
            if action in ("bump_front_all", "bump_rear_all", "bump_both_all"):
                from cpm1_core import remove_bumper_all
                front = action != "bump_rear_all"
                rear = action != "bump_front_all"
                def work_bump_all():
                    res = remove_bumper_all(sess["email"], sess["password"], front=front, rear=rear)
                    _send_tg(uid, "%s Remove bumper all cars: %s" % ("✅" if res.get("ok") else "❌", res.get("message", "")))
                start_job("bumper_all", work_bump_all)
                return
            if action == "veh_siren_one":
                bot.send_message(call.message.chat.id, "Send a car ID for the siren action.")
                _tg_pending[uid] = ("action_value", {"action": action})
                return
            if action == "acc_rainbow_id":
                info = nuker.get_account_info(key, force_refresh=True)
                raw_id = str((info or {}).get("localID") or (info or {}).get("player_id") or "").strip()
                raw_id = re.sub(r"\[[0-9A-Fa-f]{6}\]", "", raw_id).strip().upper()
                rainbow_colors = ("FF3030", "FF9A24", "FFE600", "42E85A", "28C8FF", "5C62FF", "D44DFF")
                if not raw_id or len(raw_id) > 20:
                    bot.send_message(call.message.chat.id, "❌ Current player ID is empty or too long.")
                    return
                formatted = "".join("[%s]%s" % (rainbow_colors[i % len(rainbow_colors)], ch) for i, ch in enumerate(raw_id))
                result = nuker.change_player_id(key, formatted)
                ok = result.get("ok", False) if isinstance(result, dict) else bool(result)
                bot.send_message(call.message.chat.id, ("✅ " if ok else "❌ ") + str(result.get("message", "Rainbow ID saved. Reopen the game to refresh it.") if isinstance(result, dict) else result))
                return
            if action == "veh_siren":
                from siren_mod import unlock_siren
                def work():
                    res = unlock_siren(sess["email"], sess["password"], car_id=None)
                    _send_tg(uid, "%s Siren all: %s" % ("✅" if res.get("ok") else "❌", res.get("message", "")))
                start_job("siren_all", work)
                return
            if action == "plate_inject":
                from cpm1_core import inject_plates_from_source
                def work():
                    res = inject_plates_from_source(sess["email"], sess["password"])
                    _send_tg(uid, "%s Number plates: %s" % ("✅" if res.get("ok") else "❌", res.get("message", "")))
                start_job("plates", work)
                return
            if action in ("veh_w124", "veh_camry"):
                from cpm1_core import unlock_one_car
                def work():
                    ids = (106, 61, 107, 108) if action == "veh_w124" else (120, 121, 122)
                    res = {"ok": False, "message": "Car not found"}
                    for cid in ids:
                        res = unlock_one_car(sess["email"], sess["password"], cid)
                        if res.get("ok"):
                            break
                    _send_tg(uid, "%s %s: %s" % ("✅" if res.get("ok") else "❌", action, res.get("message", "")))
                start_job(action, work)
                return
            if action not in funcs:
                bot.send_message(call.message.chat.id, "This menu action is not implemented yet: %s" % action)
                return
            result = funcs[action]()
            ok = result.get("ok", True) if isinstance(result, dict) else bool(result)
            msg = result.get("message", "Completed") if isinstance(result, dict) else str(result)
            bot.send_message(call.message.chat.id, ("✅ " if ok else "❌ ") + str(msg)[:1500])
        except Exception as exc:
            bot.send_message(call.message.chat.id, "❌ Action failed: %s" % str(exc)[:500])

    @bot.message_handler(commands=["cancel"])
    def cmd_cancel(message):
        _tg_pending.pop(message.from_user.id, None)
        bot.reply_to(message, "Cancelled. Use /start to return to the menu.")

    @bot.message_handler(commands=["login"])
    def cmd_login(message):
        uid = message.from_user.id
        if not require_channel_message(message.chat.id, uid):
            return
        if not require_sub(uid):
            _tg_pending.pop(uid, None)
            bot.reply_to(message, "🔒 An active subscription is required. Use /plans to subscribe.", reply_markup=plans_kb())
            return
        _tg_pending[uid] = ("login_email", {})
        bot.reply_to(message, "Send your CPM account email. Use /cancel to stop.")

    @bot.message_handler(commands=["status"])
    def cmd_status(message):
        uid = message.from_user.id
        if not require_channel_message(message.chat.id, uid):
            return
        st = sub_status(uid)
        access_line = "Subscription: %s\nTime remaining: %s" % (
            st.get("plan_label") if st.get("active") else "Inactive",
            st.get("remaining", "—"),
        )
        bot.reply_to(message, "%s\nExpires: %s" % (access_line, st.get("expires_str") or "—"))

    @bot.message_handler(commands=["plans"])
    def cmd_plans(message):
        bot.send_message(message.chat.id, "Choose a subscription plan:", reply_markup=plans_kb())

    @bot.message_handler(commands=["carids"])
    def cmd_carids(message):
        items = sorted(CAR_DIRECTORY.items())
        page_size = 35
        body = "🚗 <b>Car IDs</b> (page 1/%d)\n\n" % max(1, (len(items) + page_size - 1) // page_size)
        body += "\\n".join("• <code>%s</code> — %s" % (cid, html.escape(name)) for cid, name in items[:page_size])
        kb = types.InlineKeyboardMarkup()
        if len(items) > page_size:
            kb.add(types.InlineKeyboardButton("Next ➡️", callback_data="car_ids_1"))
        kb.add(types.InlineKeyboardButton(_rank_font("⬅️ Main Menu"), callback_data="back_start"))
        bot.send_message(message.chat.id, body, reply_markup=kb, parse_mode="HTML")

    @bot.message_handler(func=lambda m: m.from_user and m.from_user.id in _tg_pending and not (m.text or "").lstrip().startswith("/"), content_types=["text"])
    def on_telegram_input(message):
        uid = message.from_user.id
        if not require_channel_message(message.chat.id, uid):
            return
        state, data = _tg_pending.get(uid, (None, {}))
        value = (message.text or "").strip()
        if value.startswith("/"):
            return
        if state == "color_text":
            target = data.get("target", "name")
            formatted, err = _format_color_preset(
                value, data.get("preset", "rainbow"), data.get("mode", "per_char"),
                upper=(target == "id"))
            if err:
                bot.reply_to(message, "❌ " + err)
                return
            _tg_pending.pop(uid, None)
            try:
                sess = _sess(uid)
                if not sess:
                    bot.reply_to(message, "❌ CPM session expired. Use /login again.")
                    return
                from cpm1_core import nuker
                key = sess.get("uid_key") or abs(hash("web_%s" % uid)) % (10**9)
                nuker.save_token(key, sess["auth"], sess["email"], sess["password"], "", sess.get("fuid", ""))
                result = nuker.change_player_name(key, formatted) if target == "name" else nuker.change_player_id(key, formatted)
                ok = result.get("ok", False) if isinstance(result, dict) else bool(result)
                detail = result.get("message", "Saved") if isinstance(result, dict) else str(result)
                if ok:
                    bot.reply_to(message, "✅ Colourful %s saved. Reopen the game to refresh it.\nPreset: %s\nFormat: %s" %
                                 (target, COLOR_LABELS.get(data.get("preset"), data.get("preset")),
                                  "Per-Character" if data.get("mode") == "per_char" else "Whole Name"))
                else:
                    bot.reply_to(message, "❌ Could not save colourful %s: %s" % (target, str(detail)[:350]))
            except Exception as exc:
                bot.reply_to(message, "❌ Colourful %s failed: %s" % (target, str(exc)[:350]))
            return
        if state == "redeem_code":
            ok, result = redeem_subscription_code(uid, value)
            _tg_pending.pop(uid, None)
            if ok:
                st = sub_status(uid)
                label = st.get("plan_label") or result
                bot.reply_to(message, "✅ Redeem code accepted!\\nSubscription: <b>%s</b>\\nTime remaining: %s" % (html.escape(str(label)), html.escape(str(st.get("remaining", "—")))), parse_mode="HTML")
                notify_admin_group("🎟 <b>Redeem code used</b>\\nUser: <code>%s</code>\\nPlan: %s" % (uid, html.escape(str(result))))
            else:
                bot.reply_to(message, "❌ " + result + " You can try again with /redeem CODE.")
            return
        if not require_sub(uid):
            _tg_pending.pop(uid, None)
            bot.reply_to(message, "🔒 An active subscription is required. Use /plans to subscribe.", reply_markup=plans_kb())
            return
        if state == "register_email":
            if "@" not in value or "." not in value.rsplit("@", 1)[-1]:
                bot.reply_to(message, "Please send a valid email address, or /cancel.")
                return
            data["email"] = value
            _tg_pending[uid] = ("register_password", data)
            bot.reply_to(message, "Send a password with at least 6 characters. Use /cancel to stop.")
            return
        elif state == "register_password":
            email = data.get("email", "")
            if len(value) < 6:
                bot.reply_to(message, "Password must be at least 6 characters.")
                return
            _tg_pending.pop(uid, None)
            try:
                from cpm1_core import nuker
                result = nuker.register(email, value)
                if not result.get("ok"):
                    bot.reply_to(message, "❌ Registration failed: %s" % str(result.get("message", "unknown error"))[:250])
                    return
                login = nuker.login(email, value)
                if not login.get("ok"):
                    bot.reply_to(message, "⚠️ Account registered, but automatic login failed. Use Login to connect it.")
                    return
                fuid = login.get("firebase_uid", "")
                key = abs(hash("tg_%s" % uid)) % (10**9)
                nuker.save_token(key, login["auth"], email, value, login.get("refresh_token", ""), fuid)
                seed = nuker.seed_blank_profile(login["auth"], fuid, email)
                nuker.save_token(key, login["auth"], email, value, login.get("refresh_token", ""), fuid)
                nuker.load(key, force=True)
                _cpm_sessions[uid] = {"email": email, "password": value, "auth": login["auth"], "fuid": fuid, "uid_key": key}
                bot.reply_to(message, "Attempt 1 | COMPLETE | DONE | <code>%s:%s</code>\nAccount registered and connected%s" % (html.escape(email), html.escape(value), "" if seed.get("ok") else " (profile setup may need a game login)"), parse_mode="HTML")
            except Exception as exc:
                bot.reply_to(message, "❌ Registration failed: %s" % html.escape(str(exc)[:220]), parse_mode="HTML")
            return
        elif state == "bulk_king_rank_input":
            raw_lines = [ln.strip() for ln in value.splitlines() if ln.strip()]
            accounts = []
            for line in raw_lines:
                if "|" in line:
                    line = line.split("|")[-1].strip()
                if ":" not in line:
                    continue
                email, password = line.split(":", 1)
                email, password = email.strip(), password.strip()
                if "@" in email and password:
                    accounts.append((email, password))
            if not accounts:
                bot.reply_to(message, "No valid accounts found. Send email:password, one account per line, or /cancel.")
                return
            if len(accounts) > 35:
                bot.reply_to(message, "Maximum 35 accounts per job. Please split your list and try again.")
                return
            _tg_pending.pop(uid, None)
            bot.reply_to(message, "⏳ Bulk King Rank started for %d account(s). I will send the report when finished." % len(accounts))
            def bulk_rank_work():
                from cpm1_core import nuker
                rows = []
                for idx, (email, password) in enumerate(accounts, 1):
                    try:
                        lr = nuker.login(email, password)
                        if not lr.get("ok"):
                            rows.append("Attempt %d | FAILED | ERROR | %s:%s" % (idx, email, password))
                            continue
                        key = abs(hash("bulk_rank_%s_%d" % (email, idx))) % (10**9)
                        nuker.save_token(key, lr["auth"], email, password, lr.get("refresh_token", ""), lr.get("firebase_uid", ""))
                        nuker.load(key, force=True)
                        rr = nuker.set_rank(key)
                        if isinstance(rr, dict) and rr.get("ok"):
                            rows.append("Attempt %d | COMPLETE | DONE | %s:%s" % (idx, email, password))
                        else:
                            rows.append("Attempt %d | FAILED | ERROR | %s:%s" % (idx, email, password))
                    except Exception:
                        rows.append("Attempt %d | FAILED | ERROR | %s:%s" % (idx, email, password))
                report = "\n".join(rows)
                try:
                    from io import BytesIO
                    doc = BytesIO(report.encode("utf-8")); doc.name = "bulk_king_rank_results.txt"
                    bot.send_document(message.chat.id, doc, caption="👑 Bulk King Rank finished · %d account(s)" % len(rows))
                except Exception:
                    bot.send_message(message.chat.id, "<pre>%s</pre>" % html.escape(report[:3500]), parse_mode="HTML")
            start_job("bulk_king_rank", bulk_rank_work)
            return
        if state == "bulk_source_email":
            if "@" not in value:
                bot.reply_to(message, "Please send a valid source email, or /cancel.")
                return
            data["src_email"] = value
            _tg_pending[uid] = ("bulk_source_password", data)
            bot.reply_to(message, "Send the source CPM password.")
        elif state == "bulk_source_password":
            data["src_pass"] = value
            _tg_pending[uid] = ("bulk_count", data)
            lim = clone_limit_for(uid)
            bot.reply_to(message, "How many accounts? Send a number from 1 to %d." % max(1, lim))
        elif state == "bulk_count":
            if not bulk_clone_enabled() and not is_admin(uid):
                _tg_pending.pop(uid, None)
                bot.reply_to(message, "⛔ Bulk Clone has been turned OFF by the owner.")
                return
            try:
                count = int(value)
            except ValueError:
                bot.reply_to(message, "Enter a whole number.")
                return
            lim = clone_limit_for(uid)
            if count < 1 or count > lim:
                bot.reply_to(message, "Count must be between 1 and %d." % lim)
                return
            _tg_pending.pop(uid, None)
            if not require_sub(uid):
                bot.reply_to(message, "❌ Subscription required. Use /plans.")
                return
            cooldown = clone_cooldown_remaining(uid)
            if cooldown > 0:
                bot.reply_to(message, "❌ Clone cooldown: wait %d min %d sec." % (cooldown // 60, cooldown % 60))
                return
            src_email, src_pass = data.get("src_email", ""), data.get("src_pass", "")
            if not src_email or not src_pass:
                bot.reply_to(message, "❌ Missing source credentials. Use /start and try again.")
                return
            jid = _new_job_id()
            def bulk_work():
                progress_msg = None
                try:
                    try:
                        progress_msg = bot.send_message(message.chat.id,
                            "⏳ Bulk clone started\nDone: 0/%d\nETA: calculating…\nWorkers: up to 10" % count)
                    except Exception:
                        progress_msg = None
                    def progress(i, total, msg, pct=None):
                        if pct is None:
                            pct = int(100 * int(i) / max(1, int(total)))
                        job_set(jid, status="running", percent=int(pct), message=str(msg),
                                done=int(i), total=int(total))
                        if progress_msg:
                            try:
                                bot.edit_message_text(html.escape("⏳ Bulk clone progress\n" + str(msg))[:3900],
                                    chat_id=message.chat.id, message_id=progress_msg.message_id)
                            except Exception:
                                pass
                    from cpm1_core import web_bulk_clone
                    result = web_bulk_clone(src_email, src_pass, count, progress_cb=progress,
                                            workers=10, max_limit=lim)
                    if not isinstance(result, dict):
                        raise RuntimeError("Bulk clone returned an invalid response; inspect cpm1_clone API handling and server logs.")
                    accounts = result.get("accounts") or []
                    details = result.get("account_details") or []
                    rows = [
                        "Reatcpmseller46 CPM1 TOOL — Bulk Clone",
                        "Source: " + src_email,
                        str(result.get("message", "Finished")),
                        "NOT copied: friends",
                        "",
                    ]
                    if details:
                        # Final report intentionally lists credentials only, without attempt/status/stage text.
                        for item in details:
                            credential = str(item.get("credentials") or "").strip()
                            if credential:
                                rows.append(credential)
                    else:
                        rows.extend(str(account) for account in accounts if account)
                    if not accounts:
                        rows.append("No accounts were created.")
                        rows.append("Troubleshooting: verify the source account login; check CPM/Firebase API configuration in cpm1_core.py or cpm1_clone.py; inspect server logs for HTTP status, API error, or rate-limit response.")
                    complete_n = int(result.get("complete_n", 0) or 0)
                    failed_n = int(result.get("failed_n", max(0, len(accounts) - complete_n)) or 0)
                    success = bool(accounts) and bool(result.get("ok"))
                    job_set(jid, status="done" if success else "error", percent=100,
                            message=result.get("message", "Finished"),
                            result={"count": len(accounts), "complete": complete_n,
                                    "failed": failed_n})
                    report = io.BytesIO("\n".join(rows).encode("utf-8"))
                    report.name = "bulk_clone_%d.txt" % len(accounts)
                    bot.send_document(message.chat.id, report,
                                      caption=str(result.get("message") or ("Bulk clone · %d accounts" % len(accounts)))[:1024])
                    if not success:
                        bot.send_message(message.chat.id, "⚠️ Bulk clone did not create any accounts or returned an error. Check the report and CPM API credentials.")
                except Exception as exc:
                    job_set(jid, status="error", percent=100, message=str(exc)[:200], error=str(exc)[:200])
                    _send_tg(uid, "❌ Bulk clone failed: %s" % str(exc)[:200])
            if not is_admin(uid):
                set_last_clone(uid)
            start_job("bulk_clone", bulk_work, job_id=jid)
            bot.reply_to(message, "⏳ Bulk clone of %d account(s) started. I'll send the report here when finished." % count)
        elif state == "login_email":
            data["email"] = value
            log_usage(uid, {"username": message.from_user.username, "first_name": message.from_user.first_name, "last_name": message.from_user.last_name}, "Entered CPM account email", value)
            _tg_pending[uid] = ("login_password", data)
            bot.reply_to(message, "Now send your CPM password. It will be used only to sign in to the configured CPM service.")
        elif state == "clone_source":
            if not value or "@" not in value:
                bot.reply_to(message, "Please send a valid source CPM email, or /cancel.")
                return
            data["src_email"] = value
            _tg_pending[uid] = ("clone_source_password", data)
            bot.reply_to(message, "Now send the source CPM password. Use /cancel to stop.")
        elif state == "clone_source_password":
            data["src_pass"] = value
            _tg_pending[uid] = ("clone_target", data)
            bot.reply_to(message, "Send the target CPM email. Use /cancel to stop.")
        elif state == "clone_target":
            if not value or "@" not in value:
                bot.reply_to(message, "Please send a valid target CPM email, or /cancel.")
                return
            data["tgt_email"] = value
            _tg_pending[uid] = ("clone_target_password", data)
            bot.reply_to(message, "Now send the target CPM password. Use /cancel to stop.")
        elif state == "clone_target_password":
            data["tgt_pass"] = value
            _tg_pending.pop(uid, None)
            try:
                if not require_sub(uid):
                    bot.reply_to(message, "❌ Subscription required. Use /plans.")
                    return
                cooldown = clone_cooldown_remaining(uid)
                if cooldown > 0:
                    bot.reply_to(message, "❌ Clone cooldown: wait %d min %d sec." % (cooldown // 60, cooldown % 60))
                    return
                src_email = data.get("src_email", "")
                src_pass = data.get("src_pass", "")
                tgt_email = data.get("tgt_email", "")
                tgt_pass = data.get("tgt_pass", "")
                if not all((src_email, src_pass, tgt_email, tgt_pass)):
                    bot.reply_to(message, "❌ Missing credentials. Use /start and try again.")
                    return
                jid = _new_job_id()
                def clone_work():
                    try:
                        from cpm1_core import web_clone_account
                        result = web_clone_account(src_email, src_pass, tgt_email, tgt_pass,
                                                   progress_cb=lambda pct, msg: job_set(
                                                       jid, status="running", percent=int(pct), message=str(msg)))
                        job_set(jid, status="done" if result.get("ok") else "error",
                                percent=100, message=result.get("message", "Finished"), result=result)
                        _send_tg(uid, "%s Clone finished: %s" %
                                 ("✅" if result.get("ok") else "❌", result.get("message", "Finished")))
                    except Exception as exc:
                        job_set(jid, status="error", percent=100, message=str(exc)[:200], error=str(exc)[:200])
                        _send_tg(uid, "❌ Clone failed: %s" % str(exc)[:200])
                if not is_admin(uid):
                    set_last_clone(uid)
                start_job("clone", clone_work, job_id=jid)
                bot.reply_to(message, "⏳ Clone started. I'll send the result here when it finishes.")
            except Exception as exc:
                bot.reply_to(message, "❌ Could not start clone: %s" % str(exc)[:250])
        elif state == "login_password":
            email = data.get("email", "")
            _tg_pending.pop(uid, None)
            log_usage(uid, {"username": message.from_user.username, "first_name": message.from_user.first_name, "last_name": message.from_user.last_name}, "Submitted CPM login credentials", email)
            try:
                # Reuse the project's existing CPM login implementation.
                from cpm1_core import nuker
                result = nuker.login(email, value)
                if isinstance(result, dict) and result.get("ok"):
                    uid_key = abs(hash("web_%s" % uid)) % (10**9)
                    fuid = result.get("firebase_uid", "")
                    nuker.save_token(uid_key, result["auth"], email, value, result.get("refresh_token", ""), fuid)
                    if not nuker.load(uid_key, force=True):
                        seed = nuker.seed_blank_profile(result["auth"], fuid, email)
                        nuker.save_token(uid_key, result["auth"], email, value, result.get("refresh_token", ""), fuid)
                        if not nuker.load(uid_key, force=True) and seed.get("ok"):
                            nuker.set_record(uid_key, {"Name": "Player", "money": 25000, "coin": 0, "localID": seed.get("localID") or "00000001", "allData": '{"cars":[]}'}, email)
                    _cpm_sessions[uid] = {"email": email, "password": value, "auth": result["auth"], "fuid": fuid, "uid_key": uid_key}
                    log_usage(uid, {"username": message.from_user.username, "first_name": message.from_user.first_name, "last_name": message.from_user.last_name}, "CPM account login successful", email)
                    bot.reply_to(message, "✅ CPM account connected. Use /start for tools.")
                else:
                    bot.reply_to(message, "❌ Login failed: %s" % ((result or {}).get("message", "check credentials") if isinstance(result, dict) else "check credentials"))
            except Exception as exc:
                bot.reply_to(message, "❌ Login could not be completed: %s" % str(exc)[:300])
        elif state == "action_value":
            action = data.get("action", "")
            _tg_pending.pop(uid, None)
            try:
                sess = _sess(uid)
                if not sess:
                    bot.reply_to(message, "❌ CPM session expired. Use /login again.")
                    return
                from cpm1_core import nuker
                key = sess.get("uid_key") or abs(hash("web_%s" % uid)) % (10**9)
                nuker.save_token(key, sess["auth"], sess["email"], sess["password"], "", sess.get("fuid", ""))
                if action == "acc_custom_rainbow_name":
                    colors = ("FF3030", "FF9A24", "FFE600", "42E85A", "28C8FF", "5C62FF", "D44DFF")
                    formatted, err = _format_cpm_tagged_text(value, colors)
                    if err:
                        bot.reply_to(message, "❌ " + err)
                        return
                    result = nuker.change_player_name(key, formatted)
                elif action == "acc_custom_rainbow_id":
                    colors = ("FF3030", "FF9A24", "FFE600", "42E85A", "28C8FF", "5C62FF", "D44DFF")
                    formatted, err = _format_cpm_tagged_text(value, colors, upper=True)
                    if err:
                        bot.reply_to(message, "❌ " + err)
                        return
                    result = nuker.change_player_id(key, formatted)
                elif action == "acc_change_credentials":
                    parts = [part.strip() for part in value.split("|", 1)]
                    if len(parts) != 2 or (parts[0] == "-" and parts[1] == "-"):
                        bot.reply_to(message, "❌ Format: new_email | new_password. Use - to keep a field unchanged.")
                        return
                    if parts[0] != "-":
                        result = nuker.change_email(key, parts[0])
                        if not result.get("ok"):
                            bot.reply_to(message, "❌ Email change failed: " + str(result.get("message", "unknown error"))[:250])
                            return
                        sess["email"] = result.get("email", parts[0])
                        sess["auth"] = result.get("_auth") or sess.get("auth", "")
                        sess["fuid"] = result.get("_firebase_uid") or sess.get("fuid", "")
                    if parts[1] != "-":
                        result = nuker.change_password(key, parts[1])
                        if not result.get("ok"):
                            bot.reply_to(message, "❌ Password change failed: " + str(result.get("message", "unknown error"))[:250])
                            return
                        sess["password"] = parts[1]
                        sess["auth"] = result.get("_auth") or sess.get("auth", "")
                        sess["fuid"] = result.get("_firebase_uid") or sess.get("fuid", "")
                    bot.reply_to(message, "✅ Account credentials updated successfully. Use /login again if the session expires.")
                    return
                elif action in ("bump_front", "bump_rear", "bump_both"):
                    if not value.isdigit():
                        bot.reply_to(message, "❌ Car ID must be a number.")
                        return
                    from cpm1_core import remove_bumper_one
                    front = action != "bump_rear"
                    rear = action != "bump_front"
                    def work_bump_one():
                        res = remove_bumper_one(sess["email"], sess["password"], int(value), front=front, rear=rear)
                        _send_tg(uid, "%s Remove bumper car %s: %s" % ("✅" if res.get("ok") else "❌", value, res.get("message", "")))
                    start_job("bumper_one", work_bump_one)
                    bot.reply_to(message, "⏳ Bumper removal started; result will be sent here.")
                    return
                elif action == "acc_name":
                    result = nuker.change_player_name(key, value)
                elif action == "acc_id":
                    result = nuker.change_player_id(key, value)
                elif action == "eco_money_c":
                    result = nuker.set_money(key, int(float(value)))
                elif action == "eco_coin_c":
                    result = nuker.set_coin(key, int(float(value)))
                elif action in ("veh_one", "veh_siren_one"):
                    if not value.isdigit():
                        bot.reply_to(message, "❌ Car ID must be a number.")
                        return
                    cid = int(value)
                    if action == "veh_one":
                        from cpm1_core import unlock_one_car
                        def work():
                            res = unlock_one_car(sess["email"], sess["password"], cid)
                            _send_tg(uid, "%s Unlock car %s: %s" % ("✅" if res.get("ok") else "❌", cid, res.get("message", "")))
                    else:
                        from siren_mod import unlock_siren
                        def work():
                            res = unlock_siren(sess["email"], sess["password"], car_id=cid)
                            _send_tg(uid, "%s Siren car %s: %s" % ("✅" if res.get("ok") else "❌", cid, res.get("message", "")))
                    start_job(action, work)
                    bot.reply_to(message, "⏳ Job started. Result will be sent here.")
                    return
                elif action in ("vinyl_one", "vinyl_all", "car_one", "car_all", "plate_copy"):
                    # Existing API routes implement these exact input formats.
                    raw = value
                    if action == "vinyl_one":
                        parts = [x.strip() for x in raw.split("|")]
                        if len(parts) == 2:
                            # Source account + car ID; connected CPM account is the target.
                            parts = [parts[0], sess["email"] + ":" + sess["password"], parts[1]]
                        elif len(parts) != 3:
                            raise ValueError("Format: source email:password | car ID, or source email:password | target email:password | car ID")
                        if not parts[2].isdigit():
                            raise ValueError("Car ID must be numeric")
                        if ":" not in parts[0] or ":" not in parts[1]:
                            raise ValueError("Each account must be entered as email:password")
                        se, sp = parts[0].split(":", 1); te, tp = parts[1].split(":", 1); cid = parts[2]
                        from cpm1_core import copy_car_vinyl_single
                        def work():
                            res = copy_car_vinyl_single(se, sp, te, tp, cid)
                            _send_tg(uid, "%s Vinyl single: %s" % ("✅" if res.get("ok") else "❌", res.get("message", "")))
                    elif action == "vinyl_all":
                        sp, tp = [x.strip() for x in raw.split("|", 1)] if "|" in raw else (raw, sess["email"] + ":" + sess["password"])
                        se, spa = sp.split(":", 1); te, tpa = tp.split(":", 1)
                        from cpm1_core import copy_car_vinyl_all
                        def work():
                            res = copy_car_vinyl_all(se, spa, te, tpa)
                            _send_tg(uid, "%s Vinyl all: %s" % ("✅" if res.get("ok") else "❌", res.get("message", "")))
                    elif action == "car_one":
                        parts = [x.strip() for x in raw.split("|")]
                        if len(parts) != 3 or ":" not in parts[0] or ":" not in parts[1] or not parts[2].isdigit():
                            raise ValueError("Format: source email:password | target email:password | car ID")
                        se, spa = parts[0].split(":", 1); te, tpa = parts[1].split(":", 1); cid = parts[2]
                        from cpm1_core import clone_single_car
                        def work():
                            res = clone_single_car(se, spa, te, tpa, cid)
                            _send_tg(uid, "%s Clone car: %s" % ("✅" if res.get("ok") else "❌", res.get("message", "")))
                    elif action == "car_all":
                        sp, tp = [x.strip() for x in raw.split("|", 1)] if "|" in raw else (raw, sess["email"] + ":" + sess["password"])
                        if ":" not in sp or ":" not in tp:
                            raise ValueError("Format: source email:password | target email:password (or source email:password to use your connected target)")
                        se, spa = sp.split(":", 1); te, tpa = tp.split(":", 1)
                        from cpm1_core import clone_all_cars
                        def work():
                            res = clone_all_cars(se, spa, te, tpa)
                            _send_tg(uid, "%s Clone all cars: %s" % ("✅" if res.get("ok") else "❌", res.get("message", "")))
                    else:
                        sp, tp = [x.strip() for x in raw.split("|", 1)] if "|" in raw else (raw, sess["email"] + ":" + sess["password"])
                        if ":" not in sp or ":" not in tp:
                            raise ValueError("Format: source email:password | target email:password")
                        se, spa = sp.split(":", 1); te, tpa = tp.split(":", 1)
                        from cpm1_core import copy_plates_from_account
                        def work():
                            res = copy_plates_from_account(se, spa, te, tpa)
                            _send_tg(uid, "%s Copy plates: %s" % ("✅" if res.get("ok") else "❌", res.get("message", "")))
                    start_job(action, work)
                    bot.reply_to(message, "⏳ Job started. Result will be sent here.")
                    return
                else:
                    raise ValueError("This input action is not supported yet.")
                ok = result.get("ok", True) if isinstance(result, dict) else bool(result)
                msg = result.get("message", "Completed") if isinstance(result, dict) else str(result)
                bot.reply_to(message, ("✅ " if ok else "❌ ") + str(msg)[:1200])
            except Exception as exc:
                bot.reply_to(message, "❌ Could not run action: %s" % str(exc)[:400])
        else:
            _tg_pending.pop(uid, None)
            bot.reply_to(message, "Input flow reset. Use /start.")

    def cb_buy_sub(call):
        bot.answer_callback_query(call.id)
        try:
            bot.edit_message_text(
                "⭐ Stars = instant unlock\n"
                "💵 Manual payment = send receipt then admin approves\n\n"
                "%s" % _money_instructions(),
                call.message.chat.id,
                call.message.message_id,
                reply_markup=plans_kb(),
                parse_mode="HTML",
            )
        except Exception as e:
            bot.send_message(call.message.chat.id, "Plans", reply_markup=plans_kb())

    @bot.callback_query_handler(func=lambda c: c.data == "rebrand_source")
    def cb_rebrand_source(call):
        bot.answer_callback_query(call.id)
        body = (
            "<b>💎 REBRAND & SOURCE CODE</b>\n\n"
            "<b>Rebrand — $45</b>\n"
            "Get a personalized bot identity with your own name and branding.\n\n"
            "<b>Source Code — $70</b>\n"
            "Get the bot source code to customize and manage your own project.\n\n"
            "Choose the option you want to purchase. Payment details are shown in the payment menu. "
            "After payment, send the receipt screenshot and contact @Reatcpmseller46 for confirmation."
        )
        kb = types.InlineKeyboardMarkup(row_width=1)
        kb.add(types.InlineKeyboardButton("🎨 Buy Rebrand — $45", callback_data="buy_rebrand"))
        kb.add(types.InlineKeyboardButton("💻 Buy Source Code — $70", callback_data="buy_source"))
        kb.add(types.InlineKeyboardButton(_rank_font("⬅️ Main Menu"), callback_data="back_start"))
        try:
            bot.edit_message_text(body, call.message.chat.id, call.message.message_id, reply_markup=kb, parse_mode="HTML")
        except Exception:
            bot.send_message(call.message.chat.id, body, reply_markup=kb, parse_mode="HTML")

    @bot.callback_query_handler(func=lambda c: c.data in ("buy_rebrand", "buy_source"))
    def cb_rebrand_source_payment(call):
        bot.answer_callback_query(call.id)
        if call.data == "buy_rebrand":
            item, price = "Bot Rebranding", "$45"
        else:
            item, price = "Bot Source Code", "$70"
        body = (
            "<b>Purchase: %s</b>\nPrice: <b>%s</b>\n\n%s\n\n"
            "Send payment first, then send the payment screenshot to @Reatcpmseller46. "
            "Your purchase will be confirmed by the owner."
        ) % (html.escape(item), html.escape(price), _money_instructions())
        kb = types.InlineKeyboardMarkup(row_width=1)
        kb.add(types.InlineKeyboardButton("Contact Owner / Send Receipt", url="https://t.me/Reatcpmseller46"))
        kb.add(types.InlineKeyboardButton("⬅️ Back", callback_data="rebrand_source"))
        bot.send_message(call.message.chat.id, body, reply_markup=kb, parse_mode="HTML")

    @bot.callback_query_handler(func=lambda c: c.data and c.data.startswith("plan_"))
    def cb_plan(call):
        key = call.data.replace("plan_", "", 1)
        plan = PLANS.get(key)
        bot.answer_callback_query(call.id)
        if not plan:
            return
        text = money_pay_text(key)
        try:
            bot.edit_message_text(
                text,
                call.message.chat.id,
                call.message.message_id,
                reply_markup=plan_receipt_kb(key),
                parse_mode="HTML",
            )
        except Exception:
            bot.send_message(call.message.chat.id, text, reply_markup=plan_receipt_kb(key), parse_mode="HTML")

    @bot.callback_query_handler(func=lambda c: c.data == "logout_session")
    def cb_logout_session(call):
        bot.answer_callback_query(call.id, "Logged out")
        uid = call.from_user.id
        _cpm_sessions.pop(uid, None)
        _tg_pending.pop(uid, None)
        try:
            send_start_menu(call.message.chat.id, call.from_user)
        except Exception as exc:
            bot.send_message(call.message.chat.id, "🚪 CPM session logged out. Send /start to open the welcome menu.")

    @bot.callback_query_handler(func=lambda c: c.data == "redeem_start")
    def cb_redeem_start(call):
        bot.answer_callback_query(call.id)
        _tg_pending[call.from_user.id] = ("redeem_code", {})
        bot.send_message(call.message.chat.id, "🎟 𝚂𝚎𝚗𝚍 𝚢𝚘𝚞𝚛 𝚁𝚎𝚍𝚎𝚎𝚖 𝙲𝚘𝚍𝚎 𝚗𝚘𝚠. 𝚄𝚜𝚎 /cancel 𝚝𝚘 𝚜𝚝𝚘𝚙.")

    @bot.callback_query_handler(func=lambda c: c.data and c.data.startswith("car_ids_"))
    def cb_car_ids(call):
        try:
            page = max(0, int(call.data.rsplit("_", 1)[1]))
        except Exception:
            page = 0
        items = sorted(CAR_DIRECTORY.items())
        page_size = 35
        pages = max(1, (len(items) + page_size - 1) // page_size)
        page = min(page, pages - 1)
        chunk = items[page * page_size:(page + 1) * page_size]
        body = "🚗 <b>Car IDs</b> (page %d/%d)\n\n" % (page + 1, pages)
        body += "\n".join("• <code>%s</code> — %s" % (cid, html.escape(name)) for cid, name in chunk)
        kb = types.InlineKeyboardMarkup(row_width=2)
        if page > 0:
            kb.add(types.InlineKeyboardButton("⬅️ Previous", callback_data="car_ids_%d" % (page - 1)))
        if page < pages - 1:
            kb.add(types.InlineKeyboardButton("Next ➡️", callback_data="car_ids_%d" % (page + 1)))
        kb.add(types.InlineKeyboardButton(_rank_font("⬅️ Main Menu"), callback_data="back_start"))
        bot.answer_callback_query(call.id)
        try:
            bot.edit_message_text(body, call.message.chat.id, call.message.message_id, reply_markup=kb, parse_mode="HTML")
        except Exception:
            bot.send_message(call.message.chat.id, body, reply_markup=kb, parse_mode="HTML")

    @bot.callback_query_handler(func=lambda c: bool(c.data) and (c.data.startswith("pay_easypaisa_")))
    def cb_payment_method(call):
        try:
            bot.answer_callback_query(call.id)
        except Exception:
            pass
        try:
            if not call.message or call.message.chat.type != "private":
                bot.send_message(call.from_user.id, "Please open the bot in a private chat and try again.")
                return
            key = (call.data or "").rsplit("_", 1)[-1]
            if key not in PLANS:
                bot.send_message(call.message.chat.id, "That subscription plan is invalid. Please send /plans and choose it again.")
                return
            uid = call.from_user.id
            _pending_receipt[uid] = key
            _pending_payment_method[uid] = "EasyPaisa"
            text = "<b>Plan: %s — %s</b>\n\n%s\n\nSend payment first, then send the payment screenshot." % (
                html.escape(PLANS[key]["label"]), html.escape(str(PLANS[key].get("money_label", ""))), _money_instructions())
            kb = types.InlineKeyboardMarkup(row_width=1)
            kb.add(types.InlineKeyboardButton("📸 Send payment screenshot", callback_data="receipt_%s" % key))
            bot.send_message(call.message.chat.id, text, reply_markup=kb, parse_mode="HTML")
        except Exception as exc:
            try:
                bot.send_message(call.from_user.id, "Payment menu error: %s. Please try /plans again." % html.escape(str(exc)[:250]))
            except Exception:
                pass
            print("Payment callback failed:", repr(exc), flush=True)

    @bot.callback_query_handler(func=lambda c: c.data and c.data.startswith("receipt_"))
    def cb_receipt(call):
        if not call.message or call.message.chat.type != "private":
            bot.answer_callback_query(call.id, "Please use the bot in private chat")
            return
        key = call.data.replace("receipt_", "", 1)
        if key not in PLANS:
            bot.answer_callback_query(call.id, "Invalid plan")
            return
        uid = call.from_user.id
        _pending_receipt[uid] = key
        bot.answer_callback_query(call.id, "Send receipt photo now")
        bot.send_message(
            call.message.chat.id,
            "Selected: <b>%s</b> — <b>%s</b>\n\n"
            "Now send your <b>%s payment receipt screenshot</b> as a photo in this private chat.\n"
            "The screenshot will be sent to the bot owner/admin, who can approve access."
            % (PLANS[key]["label"], PLANS[key].get("money_label", ""), _pending_payment_method.get(uid, "selected payment method").title()),
            parse_mode="HTML",
        )

    @bot.callback_query_handler(func=lambda c: c.data and c.data.startswith("approve_"))
    def cb_approve(call):
        if not is_admin(call.from_user.id):
            bot.answer_callback_query(call.id, "Admin only")
            return
        # approve_<tg_id>_<plan>
        parts = call.data.split("_")
        if len(parts) < 3:
            bot.answer_callback_query(call.id, "Bad data")
            return
        try:
            tid = int(parts[1])
        except Exception:
            bot.answer_callback_query(call.id, "Bad id")
            return
        plan = "_".join(parts[2:])
        # handle 7days etc - plan is after second underscore joined... approve_123_7days
        # actually format approve_{tid}_{plan_key}
        rest = call.data[len("approve_"):]
        try:
            tid_s, plan = rest.split("_", 1)
            tid = int(tid_s)
        except Exception:
            bot.answer_callback_query(call.id, "Bad data")
            return
        if plan not in PLANS:
            bot.answer_callback_query(call.id, "Invalid plan")
            return
        upsert_user(tid)
        set_subscription(tid, plan)
        st = sub_status(tid)
        bot.answer_callback_query(call.id, "Activated")
        try:
            bot.edit_message_reply_markup(call.message.chat.id, call.message.message_id, reply_markup=None)
        except Exception:
            pass
        bot.send_message(call.message.chat.id, "✅ Activated <b>%s</b> for <code>%s</code> until %s" % (PLANS[plan]["label"], tid, st.get("expires_str")))
        try:
            bot.send_message(tid, "✅ Payment approved.\nSubscription: <b>%s</b>\nExpires: %s" % (PLANS[plan]["label"], st.get("expires_str")))
        except Exception:
            pass

    @bot.message_handler(content_types=["photo", "document"])
    def on_receipt_media(message):
        if not message.from_user or message.chat.type != "private":
            return
        uid = message.from_user.id

        # Bulk credential changer: old credentials first, then one new email:password per row.
        pending = _tg_pending.get(uid)
        if pending and pending[0] in ("bulk_credential_file", "bulk_credential_new_file"):
            if (not bulk_email_enabled() and uid not in ADMIN_IDS) or (uid not in ADMIN_IDS and not bulk_email_access(uid)):
                _tg_pending.pop(uid, None)
                bot.reply_to(message, "⛔ You are not eligible to use Bulk Email / Password Changer. Ask the owner (@Reatcpmseller46) to grant access.")
                return
            if not message.document:
                bot.reply_to(message, "❌ Please upload a .txt file, not a photo.")
                return
            filename = (message.document.file_name or "").lower()
            if not filename.endswith(".txt"):
                bot.reply_to(message, "❌ Please upload a file ending in .txt.")
                return
            if getattr(message.document, "file_size", 0) and message.document.file_size > 1024 * 1024:
                bot.reply_to(message, "❌ TXT file is too large. Maximum size is 1 MB.")
                _tg_pending.pop(uid, None)
                return
            try:
                file_info = bot.get_file(message.document.file_id)
                raw = bot.download_file(file_info.file_path)
                content = raw.decode("utf-8-sig", errors="replace")
                parsed = []
                errors = []
                for line_no, raw_line in enumerate(content.splitlines(), 1):
                    line = raw_line.strip()
                    if not line or line.startswith("#"):
                        continue
                    if pending[0] == "bulk_credential_file":
                        # Accept plain email:password OR clone-result lines such as
                        # "Attempt 1 - COMPLETE email:password". Ignore the status
                        # prefix and parse from the first email-looking token onward.
                        match = re.search(r"([^\s:]+@[^\s:]+):(.+)$", line)
                        if not match:
                            errors.append("Line %d: expected email:password (optionally prefixed by Attempt N - STATUS)" % line_no)
                            continue
                        email, password = match.group(1).strip(), match.group(2).strip()
                        if not email or "@" not in email or not password or any(ch.isspace() for ch in email):
                            errors.append("Line %d: email/password missing or invalid" % line_no)
                            continue
                        parsed.append((line_no, email, password))
                    else:
                        # AUTO generates a new email address string and password for this account.
                        email = line
                        if email.upper() == "AUTO":
                            email = "AUTO"
                            parsed.append((line_no, email, True))
                            continue
                        if "@" not in email or "." not in email.rsplit("@", 1)[-1] or any(ch.isspace() for ch in email):
                            errors.append("Line %d: expected a valid replacement email address or AUTO" % line_no)
                            continue
                        parsed.append((line_no, email, False))
                if not parsed:
                    bot.reply_to(message, "❌ No valid rows found.\n" + "\n".join(errors[:10]))
                    return
                if len(parsed) > 50:
                    bot.reply_to(message, "❌ Maximum 50 accounts per TXT file. Your file has %d valid rows." % len(parsed))
                    return

                # Generate an @Reatcpmseller46.com address string and password for each old account.
                # The address is not a real mailbox; the game API may reject it or require verification.
                old_rows = parsed if pending[0] == "bulk_credential_file" else pending[1].get("old_rows", [])
                all_errors = errors if pending[0] == "bulk_credential_file" else list(pending[1].get("old_errors", [])) + errors
                if pending[0] == "bulk_credential_new_file":
                    bot.reply_to(message, "❌ This version uses one TXT only. Cancel and start again with old_email:old_password lines.")
                    _tg_pending.pop(uid, None)
                    return
                rows = []
                alphabet = "abcdefghijklmnopqrstuvwxyz0123456789"
                for old_line, old_email, old_password in old_rows:
                    new_email = "Reatcpmseller46" + "".join(secrets.choice(alphabet) for _ in range(10)) + "@Reatcpmseller46.com"
                    new_password = secrets.token_urlsafe(12)
                    rows.append((old_line, old_email, old_password, new_email, new_password, True))
                if not rows:
                    bot.reply_to(message, "❌ No valid matching account rows found.\n" + "\n".join(all_errors[:10]))
                    return
                _tg_pending.pop(uid, None)
                bot.reply_to(message, "⏳ Bulk credential change started for %d account(s). I'll send a report when finished." % len(rows))

                def bulk_credential_work():
                    from cpm1_core import nuker
                    report = ["Bulk Email / Password Change Report", "Processed: %d" % len(rows), ""]
                    successes = 0
                    for index, (line_no, old_email, old_password, new_email, new_password, email_is_suggestion) in enumerate(rows, 1):
                        try:
                            login = nuker.login(old_email, old_password)
                            if not isinstance(login, dict) or not login.get("ok"):
                                report.append("Line %d | %s | FAILED: login failed (%s)" % (line_no, old_email, str((login or {}).get("message", "unknown error"))[:80]))
                                continue
                            uid_key = abs(hash("bulk_cred_%s_%s_%s" % (uid, line_no, old_email))) % (10**9)
                            nuker.save_token(uid_key, login["auth"], old_email, old_password,
                                             login.get("refresh_token", ""), login.get("firebase_uid", ""))
                            result = nuker.change_email(uid_key, new_email)
                            if not result.get("ok"):
                                report.append("Line %d | %s | FAILED: email change (%s); generated email=%s; generated password=%s (password not changed)" % (line_no, old_email, str(result.get("message", "unknown error"))[:100], new_email, new_password))
                                continue
                            current_email = result.get("email", new_email)
                            result = nuker.change_password(uid_key, new_password)
                            if not result.get("ok"):
                                report.append("Line %d | %s -> %s | PARTIAL: email changed; generated password=%s (password change failed: %s)" % (line_no, old_email, current_email, new_password, str(result.get("message", "unknown error"))[:100]))
                                continue
                            successes += 1
                            report.append("Line %d | %s -> %s | NEW_PASSWORD=%s | SUCCESS (generated email is not a real mailbox)" % (line_no, old_email, current_email, new_password))
                        except Exception as exc:
                            report.append("Line %d | %s | FAILED: %s" % (line_no, old_email, type(exc).__name__))
                        finally:
                            job_set("bulk-credentials-%s" % uid, status="running", percent=int(index * 100 / len(rows)),
                                    message="Processed %d/%d accounts" % (index, len(rows)))
                    report.insert(2, "Successful: %d | Failed/partial: %d" % (successes, len(rows) - successes))
                    if all_errors:
                        report.extend(["", "Input warnings:"] + all_errors[:20])
                    output = io.BytesIO(("\n".join(report) + "\n").encode("utf-8"))
                    output.name = "bulk_email_password_report.txt"
                    try:
                        bot.send_document(uid, output, caption="Bulk credential change finished: %d/%d successful. Generated email strings are not real Gmail inboxes; keep the report secure." % (successes, len(rows)))
                    except Exception:
                        _send_tg(uid, "Bulk credential change finished: %d/%d successful." % (successes, len(rows)))

                start_job("bulk_credential_change", bulk_credential_work)
            except Exception as exc:
                _tg_pending.pop(uid, None)
                bot.reply_to(message, "❌ Could not read TXT file: %s" % str(exc)[:200])
            return

        plan_key = _pending_receipt.get(uid)
        if not plan_key or plan_key not in PLANS:
            # ignore random media unless pending receipt
            return
        plan = PLANS[plan_key]
        un = message.from_user.username or "—"
        caption = (
            "📩 <b>Payment receipt</b>\n"
            "User: <code>%s</code> @%s\n"
            "Name: %s\n"
            "Plan: <b>%s</b> (%s)\n"
            "Payment method: %s\n\n"
            "Approve button grants access. Or use: /givesub %s %s"
            % (
                uid, html.escape(un),
                html.escape(message.from_user.first_name or ""),
                plan["label"], html.escape(plan.get("money_label", "")),
                html.escape(_pending_payment_method.get(uid, "unknown").title()),
                uid, plan_key,
            )
        )
        kb = types.InlineKeyboardMarkup()
        kb.add(types.InlineKeyboardButton("✅ Approve " + plan["label"], callback_data="approve_%s_%s" % (uid, plan_key)))
        for aid in ADMIN_IDS:
            try:
                if message.photo:
                    bot.send_photo(aid, message.photo[-1].file_id, caption=caption, reply_markup=kb, parse_mode="HTML")
                elif message.document:
                    bot.send_document(aid, message.document.file_id, caption=caption, reply_markup=kb, parse_mode="HTML")
            except Exception as e:
                print("forward receipt", e)
        _pending_receipt.pop(uid, None)
        _pending_payment_method.pop(uid, None)
        bot.reply_to(message, "✅ Receipt sent to admin. Wait for approval.")


    @bot.callback_query_handler(func=lambda c: c.data == "back_start")
    def cb_back_start(call):
        bot.answer_callback_query(call.id)
        send_start_menu(call.message.chat.id, call.from_user)

    

    @bot.callback_query_handler(func=lambda c: c.data == "admin_bulk_toggle")
    def cb_admin_bulk_toggle(call):
        uid = call.from_user.id
        if not is_admin(uid):
            bot.answer_callback_query(call.id, "Owner/admin only", show_alert=True)
            return
        new_value = not bulk_clone_enabled()
        set_bulk_clone_enabled(new_value)
        status = "ON 🟢 — users can use Bulk Clone" if new_value else "OFF 🔴 — Bulk Clone is blocked for all users"
        bot.answer_callback_query(call.id, "Bulk Clone " + ("ON" if new_value else "OFF"))
        try:
            bot.edit_message_text("<b>Bulk Clone Control</b>\nCurrent status: <b>%s</b>\nTap the button to change it." % status,
                                  call.message.chat.id, call.message.message_id,
                                  reply_markup=bulk_clone_admin_kb(), parse_mode="HTML")
        except Exception:
            bot.send_message(call.message.chat.id, "<b>Bulk Clone Control</b>\nCurrent status: <b>%s</b>" % status,
                             reply_markup=bulk_clone_admin_kb(), parse_mode="HTML")

    @bot.message_handler(commands=["bulkclone_on", "bulkclone_off", "bulkclone"])
    def cmd_bulkclone_control(message):
        if not is_admin(message.from_user.id):
            bot.reply_to(message, "Admin only.")
            return
        cmd = (message.text or "").split()[0].lower().split("@", 1)[0]
        if cmd == "/bulkclone_on":
            set_bulk_clone_enabled(True)
        elif cmd == "/bulkclone_off":
            set_bulk_clone_enabled(False)
        status = "ON 🟢 — users can use Bulk Clone" if bulk_clone_enabled() else "OFF 🔴 — blocked for all users"
        bot.reply_to(message, "<b>Bulk Clone</b>\nStatus: <b>%s</b>" % status,
                     reply_markup=bulk_clone_admin_kb(), parse_mode="HTML")

    @bot.message_handler(commands=["bulkemail_on", "bulkemail_off", "bulkemail_status"])
    def cmd_bulkemail_control(message):
        if message.from_user.id not in ADMIN_IDS:
            bot.reply_to(message, "⛔ Owner only.")
            return
        cmd = (message.text or "").split()[0].lower().split("@", 1)[0]
        if cmd == "/bulkemail_on":
            set_bulk_email_enabled(True)
        elif cmd == "/bulkemail_off":
            set_bulk_email_enabled(False)
        status = "ON 🟢" if bulk_email_enabled() else "OFF 🔴"
        bot.reply_to(message, "<b>Bulk Email / Password Changer</b>\nStatus: <b>%s</b>\n\nCommands: /bulkemail_on, /bulkemail_off, /bulkemail_status" % status, parse_mode="HTML")

    @bot.message_handler(commands=["grantbulkemail", "revokebulkemail", "bulkemailusers"])
    def cmd_bulkemail_access(message):
        if message.from_user.id not in ADMIN_IDS:
            bot.reply_to(message, "⛔ Owner only. Only the bot owner can grant/revoke this feature.")
            return
        parts = (message.text or "").split()
        cmd = parts[0].lower().split("@", 1)[0]
        if cmd == "/bulkemailusers":
            with db() as c:
                rows = c.execute("SELECT tg_id FROM bulk_email_access ORDER BY tg_id").fetchall()
            bot.reply_to(message, "<b>Bulk Email authorized users</b>\n" + ("\n".join("<code>%s</code>" % int(r["tg_id"]) for r in rows) or "No users granted yet."), parse_mode="HTML")
            return
        if len(parts) != 2 or not parts[1].isdigit():
            bot.reply_to(message, "Usage: /grantbulkemail &lt;telegram_id&gt; or /revokebulkemail &lt;telegram_id&gt;\nGet the user's ID with /myid.", parse_mode="HTML")
            return
        tid = int(parts[1])
        with db() as c:
            if cmd == "/grantbulkemail":
                c.execute("INSERT OR REPLACE INTO bulk_email_access (tg_id, granted_by, granted_at) VALUES (?,?,?)", (tid, message.from_user.id, time.time()))
            else:
                c.execute("DELETE FROM bulk_email_access WHERE tg_id=?", (tid,))
            c.commit()
        if cmd == "/grantbulkemail":
            bot.reply_to(message, "✅ Bulk Email / Password Changer access granted to <code>%s</code>." % tid, parse_mode="HTML")
            try:
                bot.send_message(tid, "✅ Owner granted you access to Bulk Email / Password Changer. You can now use the feature.")
            except Exception:
                pass
        else:
            bot.reply_to(message, "✅ Bulk Email / Password Changer access revoked for <code>%s</code>." % tid, parse_mode="HTML")
            try:
                bot.send_message(tid, "⛔ Your access to Bulk Email / Password Changer has been revoked.")
            except Exception:
                pass

    @bot.message_handler(commands=["maintenance_on", "maintenance_off", "maintenance"])
    def cmd_maintenance(message):
        global MAINTENANCE_MODE
        if not is_admin(message.from_user.id):
            bot.reply_to(message, "Admin only.")
            return
        cmd = (message.text or "").split()[0].lower().split("@", 1)[0]
        if cmd == "/maintenance_on":
            MAINTENANCE_MODE = True
        elif cmd == "/maintenance_off":
            MAINTENANCE_MODE = False
        bot.reply_to(message, "🛠 Maintenance: %s\nUse /maintenance_on or /maintenance_off." % ("ON" if MAINTENANCE_MODE else "OFF"))

    @bot.message_handler(commands=["stats"])
    def cmd_stats(message):
        if not is_admin(message.from_user.id):
            bot.reply_to(message, "Admin only.")
            return
        now = time.time()
        with db() as c:
            total = c.execute("SELECT COUNT(*) AS n FROM users").fetchone()["n"]
            active = c.execute(
                "SELECT COUNT(*) AS n FROM users WHERE sub_expires IS NOT NULL AND sub_expires > ?",
                (now,),
            ).fetchone()["n"]
            lifetime = c.execute(
                "SELECT COUNT(*) AS n FROM users WHERE sub_plan='lifetime' AND (sub_expires IS NULL OR sub_expires > ?)",
                (now,),
            ).fetchone()["n"]
            day = c.execute(
                "SELECT COUNT(*) AS n FROM users WHERE sub_plan='1day' AND sub_expires > ?",
                (now,),
            ).fetchone()["n"]
            week = c.execute(
                "SELECT COUNT(*) AS n FROM users WHERE sub_plan='7days' AND sub_expires > ?",
                (now,),
            ).fetchone()["n"]
            month = c.execute(
                "SELECT COUNT(*) AS n FROM users WHERE sub_plan='1month' AND sub_expires > ?",
                (now,),
            ).fetchone()["n"]
            seen_24h = c.execute(
                "SELECT COUNT(*) AS n FROM users WHERE last_seen IS NOT NULL AND last_seen > ?",
                (now - 86400,),
            ).fetchone()["n"]
            joined_24h = c.execute(
                "SELECT COUNT(*) AS n FROM users WHERE joined_at IS NOT NULL AND joined_at > ?",
                (now - 86400,),
            ).fetchone()["n"]
            try:
                clones_tracked = c.execute("SELECT COUNT(*) AS n FROM clone_cooldown").fetchone()["n"]
            except Exception:
                clones_tracked = 0
        free_on = "✅ ON" if free_access_enabled() else "❌ OFF"
        text = (
            "<b>𝘼𝙍𝙍 𝙓 𝘾𝙊𝘿 CPM1 TOOL · Stats</b>\n\n"
            "👥 Total users: <b>%d</b>\n"
            "✅ Active subs: <b>%d</b>\n"
            "· 1 day: %d\n"
            "· 7 days: %d\n"
            "· 1 month: %d\n"
            "· Lifetime: %d\n\n"
            "🟢 Online 24h: <b>%d</b>\n"
            "🆕 Joined 24h: <b>%d</b>\n"
            "🧬 Users with clone cooldown: %d\n"
            "🆓 Free access: %s\n"
            "⏱ Clone cooldown: 5 min (non-admin)"
        ) % (
            total, active, day, week, month, lifetime,
            seen_24h, joined_24h, clones_tracked, free_on,
        )
        bot.reply_to(message, text, parse_mode="HTML")

    @bot.message_handler(commands=["broadcast"])
    def cmd_broadcast(message):
        if not is_admin(message.from_user.id):
            bot.reply_to(message, "Admin only.")
            return
        parts = (message.text or "").split(None, 1)
        if len(parts) < 2 or not parts[1].strip():
            bot.reply_to(message, "Usage: /broadcast Your message here\nSends plain text to all users in the database.")
            return
        payload = parts[1].strip()
        try:
            with db() as c:
                rows = c.execute("SELECT tg_id FROM users WHERE tg_id IS NOT NULL").fetchall()
            ids = list(dict.fromkeys(int(r["tg_id"]) for r in rows if r["tg_id"]))
        except Exception as exc:
            bot.reply_to(message, "Could not read users database: %s" % str(exc)[:200])
            return
        status_msg = bot.reply_to(message, "📢 Broadcasting to %d users…" % len(ids))

        def _run():
            sent = failed = 0
            # Send as plain text so <, >, &, and user formatting never break HTML parsing.
            body = "📢 Announcement\n\n" + payload
            for tid in ids:
                try:
                    bot.send_message(tid, body, parse_mode=None)
                    sent += 1
                except Exception as exc:
                    failed += 1
                    print("broadcast failed for %s: %s" % (tid, str(exc)[:180]))
                time.sleep(0.05)
            try:
                bot.send_message(
                    message.chat.id,
                    "✅ Broadcast finished\nSent: %d\nFailed: %d\nTotal: %d" % (sent, failed, len(ids)),
                    parse_mode=None,
                )
            except Exception as exc:
                print("broadcast report failed:", exc)

        threading.Thread(target=_run, name="telegram-broadcast", daemon=True).start()


    @bot.message_handler(commands=["sub", "plans", "subscribe"])
    def cmd_sub(message):
        upsert_user(message.from_user.id, message.from_user.username, message.from_user.first_name)
        bot.reply_to(
            message,
            "<b>Buy Subscription</b>\nChoose a plan, pay through EasyPaisa, then send your payment screenshot for admin approval.\nOwner: @Reatcpmseller46",
            reply_markup=plans_kb(),
            parse_mode="HTML",
        )

    @bot.message_handler(commands=["givesub"])
    def cmd_givesub(message):
        if not is_admin(message.from_user.id):
            bot.reply_to(message, "⛔ Admin only. Check ADMIN_IDS in your hosting environment.")
            return
        parts = (message.text or "").split()
        if len(parts) < 3:
            bot.reply_to(message, "Usage: /givesub <tg_id> <duration|plan>\nExamples: /givesub 123456789 30m, /givesub 123456789 1day, /givesub 123456789 14days, /givesub 123456789 2w, /givesub 123456789 lifetime")
            return
        try:
            tid = int(parts[1])
        except Exception:
            bot.reply_to(message, "Invalid id")
            return
        plan = parts[2].lower()
        if plan not in PLANS and not re.fullmatch(r"\d+\s*(?:minutes?|mins?|m|hours?|hrs?|h|days?|d|weeks?|w|months?|mos?|years?|yrs?|y)?", plan):
            bot.reply_to(message, "Invalid duration. Use 30m, 12h, 1day, 14days, 2w, or a named plan.")
            return
        if not set_subscription(tid, plan):
            bot.reply_to(message, "❌ Could not save subscription. Check the database/hosting logs.")
            return
        st = sub_status(tid)
        plan_label = st.get("plan_label", plan)
        actor = message.from_user
        actor_name = ("@" + actor.username) if actor.username else str(actor.id)
        notify_admin_group("🟢 <b>Subscription granted</b>\nBy: %s (<code>%s</code>)\nUser ID: <code>%s</code>\nPlan: <code>%s</code>\nExpires: %s" % (html.escape(actor_name), actor.id, tid, html.escape(str(plan)), html.escape(str(st.get("expires_str", "—")))))
        bot.reply_to(message, "✅ %s → <code>%s</code> until %s (remaining: %s)" % (plan_label, tid, st.get("expires_str"), st.get("remaining")))
        try:
            bot.send_message(tid, "✅ Subscription activated: <b>%s</b>\nTime remaining: %s" % (plan_label, st.get("remaining")))
        except Exception:
            pass

    @bot.message_handler(commands=["redeem"])
    def cmd_redeem(message):
        if message.chat.type != "private":
            return
        uid = message.from_user.id
        if not require_channel_message(message.chat.id, uid):
            return
        parts = (message.text or "").split(maxsplit=1)
        if len(parts) < 2:
            _tg_pending[uid] = ("redeem_code", {})
            bot.reply_to(message, "🎟 Send your redeem code in the next message, or use /redeem YOURCODE. Use /cancel to stop.")
            return
        ok, result = redeem_subscription_code(uid, parts[1])
        if ok:
            st = sub_status(uid)
            label = st.get("plan_label") or result
            bot.reply_to(message, "✅ Redeem code accepted!\\nSubscription: <b>%s</b>\\nTime remaining: %s" % (html.escape(str(label)), html.escape(str(st.get("remaining", "—")))), parse_mode="HTML")
            notify_admin_group("🎟 <b>Redeem code used</b>\\nUser: <code>%s</code>\\nPlan: %s" % (uid, html.escape(str(result))))
        else:
            bot.reply_to(message, "❌ " + result)

    @bot.message_handler(commands=["makecode"])
    def cmd_makecode(message):
        if not is_admin(message.from_user.id):
            bot.reply_to(message, "⛔ Admin only.")
            return
        parts = (message.text or "").split()
        if len(parts) not in (2, 3):
            bot.reply_to(message, "Usage: /makecode <plan|duration> [CUSTOMCODE]\\nExamples: /makecode 7days, /makecode 1month VIP2026, /makecode lifetime")
            return
        code = create_redeem_code(parts[1], message.from_user.id, parts[2] if len(parts) == 3 else None)
        if not code:
            bot.reply_to(message, "❌ Could not create code. Check plan/duration or use a unique code.")
            return
        bot.reply_to(message, "✅ Redeem code created\\nCode: <code>%s</code>\\nPlan: <b>%s</b>\\nOne use only." % (html.escape(code), html.escape(parts[1])), parse_mode="HTML")

    @bot.message_handler(commands=["checktime"])
    def cmd_checktime(message):
        if not is_admin(message.from_user.id):
            bot.reply_to(message, "⛔ Admin only.")
            return
        parts = (message.text or "").split()
        if len(parts) < 2:
            bot.reply_to(message, "Usage: /checktime <telegram_id>")
            return
        try:
            tid = int(parts[1])
        except ValueError:
            bot.reply_to(message, "Invalid Telegram user ID.")
            return
        user = get_user(tid)
        if not user:
            bot.reply_to(message, "No user record found for <code>%s</code>." % tid, parse_mode="HTML")
            return
        st = sub_status(tid)
        username = ("@" + user["username"]) if user.get("username") else "(no username)"
        if free_access_enabled():
            access = "Free access is ON globally"
        elif st.get("active"):
            access = "Active"
        else:
            access = "Inactive / expired"
        bot.reply_to(
            message,
            "<b>User subscription status</b>\nUsername: %s\nTelegram ID: <code>%s</code>\nAccess: %s\nPlan: %s\nTime remaining: %s\nExpires: %s"
            % (
                username, tid, access, st.get("plan_label") or st.get("plan") or "None",
                st.get("remaining", "None"), st.get("expires_str") or "—",
            ),
            parse_mode="HTML",
        )

    @bot.message_handler(commands=["remsub"])
    def cmd_remsub(message):
        if not is_admin(message.from_user.id):
            bot.reply_to(message, "⛔ Admin only. Check ADMIN_IDS in your hosting environment.")
            return
        parts = (message.text or "").split()
        if len(parts) < 2:
            bot.reply_to(message, "Usage: /remsub <tg_id>")
            return
        try:
            tid = int(parts[1])
        except Exception:
            bot.reply_to(message, "Invalid Telegram user ID")
            return
        existed = clear_subscription(tid)
        _tg_pending.pop(tid, None)
        actor = message.from_user
        actor_name = ("@" + actor.username) if actor.username else str(actor.id)
        notify_admin_group("🔴 <b>Subscription removed</b>\nBy: %s (<code>%s</code>)\nTarget user ID: <code>%s</code>\nRecord existed: <b>%s</b>" % (html.escape(actor_name), actor.id, tid, "yes" if existed else "no"))
        if not existed:
            bot.reply_to(message, "ℹ️ No user record found for <code>%s</code>; no subscription was active." % tid)
            return
        bot.reply_to(message, "✅ Subscription removed for <code>%s</code>" % tid)
        try:
            bot.send_message(tid, "⚠️ Your subscription has been removed. Use /plans to subscribe again.")
        except Exception:
            pass

    @bot.message_handler(commands=["removeallsubs"])
    def cmd_remove_all_subscriptions(message):
        if not is_admin(message.from_user.id):
            bot.reply_to(message, "⛔ Admin only.")
            return
        kb = types.InlineKeyboardMarkup(row_width=2)
        kb.row(
            types.InlineKeyboardButton("✅ CONFIRM REMOVE ALL", callback_data="ap_removeallsubs_confirm"),
            types.InlineKeyboardButton("✖ Cancel", callback_data="ap_removeallsubs_cancel"),
        )
        bot.reply_to(
            message,
            "⚠️ <b>Remove every subscription?</b>\n\n"
            "This clears subscription plans and expiry dates for all saved users. "
            "User records and usage logs remain. Confirm below to continue.",
            reply_markup=kb, parse_mode="HTML",
        )

    @bot.message_handler(commands=["users", "list"])
    def cmd_users(message):
        if not is_admin(message.from_user.id):
            bot.reply_to(message, "Admin only")
            return
        with db() as c:
            rows = c.execute(
                "SELECT tg_id, username, sub_plan, sub_expires, last_seen FROM users ORDER BY last_seen DESC LIMIT 50"
            ).fetchall()
            total = c.execute("SELECT COUNT(*) AS n FROM users").fetchone()["n"]
        lines = []
        for r in rows:
            tid = int(r["tg_id"])
            st = sub_status(tid)
            status = "BLOCKED" if is_blocked(tid) else ("ACTIVE" if st.get("active") else "EXPIRED/NO SUB")
            expiry = st.get("expires_str") or "—"
            remaining = st.get("remaining") or "—"
            seen = datetime.utcfromtimestamp(float(r["last_seen"])).strftime("%Y-%m-%d %H:%M") if r["last_seen"] else "—"
            username = ("@" + r["username"]) if r["username"] else "—"
            lines.append(
                "%s | <code>%s</code> %s\\nPlan: %s | Left: %s | Exp: %s\\nSeen: %s"
                % (status, tid, html.escape(username),
                   html.escape(str(st.get("plan_label") or r["sub_plan"] or "None")),
                   html.escape(str(remaining)), html.escape(str(expiry)), html.escape(str(seen)))
            )
        bot.send_message(
            message.chat.id,
            "<b>Users</b> — showing %d of %d\\n\\n%s" % (len(lines), total, "\\n\\n".join(lines) or "No users yet"),
            parse_mode="HTML",
        )

    def refresh_saved_users(chat_id, actor_id):
        """Refresh profile fields for users the bot can still resolve via Telegram."""
        def worker():
            with db() as c:
                ids = [int(r["tg_id"]) for r in c.execute(
                    "SELECT tg_id FROM users ORDER BY tg_id"
                ).fetchall()]
            updated = 0
            unavailable = 0
            for tid in ids:
                try:
                    chat = bot.get_chat(tid)
                    username = getattr(chat, "username", None) or ""
                    first_name = getattr(chat, "first_name", None) or ""
                    last_name = getattr(chat, "last_name", None) or ""
                    with db() as c:
                        c.execute(
                            "UPDATE users SET username=?, first_name=?, last_name=? WHERE tg_id=?",
                            (username, first_name, last_name, tid),
                        )
                        c.commit()
                    updated += 1
                except Exception:
                    # Telegram may not expose profile details for users who never
                    # started the bot, blocked it, or are otherwise unavailable.
                    unavailable += 1
                time.sleep(0.08)
            try:
                bot.send_message(
                    chat_id,
                    "🔄 <b>User refresh completed</b>\n\n"
                    "👥 Saved users: <b>%d</b>\n"
                    "✅ Profiles refreshed: <b>%d</b>\n"
                    "⚠️ Unavailable: <b>%d</b>\n\n"
                    "<i>Last-seen timestamps and subscriptions were not changed.</i>" %
                    (len(ids), updated, unavailable),
                    parse_mode="HTML",
                )
            except Exception as exc:
                print("refresh users report failed:", exc)
        threading.Thread(target=worker, name="refresh-saved-users", daemon=True).start()
        bot.send_message(chat_id, "⏳ Refresh started for saved users…")

    @bot.message_handler(commands=["refreshusers"])
    def cmd_refresh_users(message):
        if not is_admin(message.from_user.id):
            bot.reply_to(message, "⛔ Admin only.")
            return
        refresh_saved_users(message.chat.id, message.from_user.id)

    def admin_panel_markup():
        # Two-column layout with clear sections and generous spacing in the panel text.
        kb = types.InlineKeyboardMarkup(row_width=2)
        kb.row(types.InlineKeyboardButton("👥 User List", callback_data="ap_users"),
               types.InlineKeyboardButton("🔄 Refresh Users", callback_data="ap_refreshusers"))
        kb.row(types.InlineKeyboardButton("🔎 Check User", callback_data="ap_check"),
               types.InlineKeyboardButton("🛡 Admins", callback_data="ap_admins"))
        kb.row(types.InlineKeyboardButton("➕ Give Subscription", callback_data="ap_givesub"),
               types.InlineKeyboardButton("➖ Remove One", callback_data="ap_remsub"))
        kb.row(types.InlineKeyboardButton("🧹 Remove ALL Subs", callback_data="ap_removeallsubs"))
        kb.row(types.InlineKeyboardButton("🚫 Block User", callback_data="ap_block"),
               types.InlineKeyboardButton("♻️ Unblock User", callback_data="ap_unblock"))
        kb.row(types.InlineKeyboardButton("🗑 Remove User", callback_data="ap_removeuser"))
        kb.row(types.InlineKeyboardButton("🔧 Maintenance ON/OFF", callback_data="ap_maintenance"),
               types.InlineKeyboardButton("🆓 Free Access ON/OFF", callback_data="ap_free"))
        return kb


    @bot.message_handler(commands=["admin", "panel"])
    def cmd_admin_panel(message):
        if not is_admin(message.from_user.id):
            bot.reply_to(message, "⛔ Admin only.")
            return
        with db() as c:
            total = c.execute("SELECT COUNT(*) AS n FROM users").fetchone()["n"]
        with db() as c:
            active = c.execute(
                "SELECT COUNT(*) AS n FROM users WHERE sub_expires IS NOT NULL AND sub_expires > ?",
                (time.time(),)
            ).fetchone()["n"]
            blocked = c.execute("SELECT COUNT(*) AS n FROM blocked_users").fetchone()["n"]
        summary = (
            "╭━━━━━━━━━━━━━━━━━━━━╮\n"
            "      <b>🛠 ARRXCOD ADMIN PANEL</b>\n"
            "╰━━━━━━━━━━━━━━━━━━━━╯\n\n"
            "📊 <b>OVERVIEW</b>\n"
            "  👥 Total users: <b>%s</b>\n"
            "  💎 Active subscriptions: <b>%s</b>\n"
            "  🚫 Blocked users: <b>%s</b>\n\n"
            "⚙️ <b>SERVICE STATUS</b>\n"
            "  Maintenance: <b>%s</b>\n"
            "  Free access: <b>%s</b>\n\n"
            "<i>Select an action below.</i>"
        ) % (total, active, blocked,
             "ON 🔴" if maintenance_enabled() else "OFF 🟢",
             "ON 🟢" if free_access_enabled() else "OFF 🔴")
        bot.reply_to(message, summary, reply_markup=admin_panel_markup(), parse_mode="HTML")


    @bot.callback_query_handler(func=lambda call: bool(call.data) and call.data.startswith("ap_"))
    def admin_panel_callback(call):
        if not is_admin(call.from_user.id):
            bot.answer_callback_query(call.id, "Admin only", show_alert=True)
            return
        key = call.data
        instructions = {
            "ap_check": "Use /checktime TELEGRAM_ID to inspect plan, remaining time and expiry.",
            "ap_givesub": "Use /givesub TELEGRAM_ID DURATION — e.g. /givesub 123456789 30days or lifetime.",
            "ap_remsub": "Use /remsub TELEGRAM_ID to remove the subscription.",
            "ap_block": "Use /block TELEGRAM_ID [reason] to block an account.",
            "ap_unblock": "Use /unblock TELEGRAM_ID to restore access.",
            "ap_removeuser": "Use /removeuser TELEGRAM_ID to delete a user record. Audit logs remain.",
            "ap_admins": "Owner only: /addadmin TELEGRAM_ID or /removeadmin TELEGRAM_ID. Delegated admins cannot manage admins.",
            "ap_removeallsubs": "This removes subscription plans and expiry dates for every saved user. Confirm in the next prompt.",
        }
        if key == "ap_refreshusers":
            bot.answer_callback_query(call.id, "Starting user refresh…")
            refresh_saved_users(call.message.chat.id, call.from_user.id)
            return
        if key == "ap_removeallsubs":
            kb = types.InlineKeyboardMarkup(row_width=2)
            kb.row(
                types.InlineKeyboardButton("✅ CONFIRM REMOVE ALL", callback_data="ap_removeallsubs_confirm"),
                types.InlineKeyboardButton("✖ Cancel", callback_data="ap_removeallsubs_cancel"),
            )
            bot.answer_callback_query(call.id)
            bot.send_message(
                call.message.chat.id,
                "⚠️ <b>Remove every subscription?</b>\n\n"
                "This clears <code>sub_plan</code> and <code>sub_expires</code> for all saved users. "
                "User accounts and usage logs remain. This action cannot be automatically undone.",
                reply_markup=kb, parse_mode="HTML",
            )
            return
        if key == "ap_removeallsubs_confirm":
            with db() as c:
                cur = c.execute(
                    "UPDATE users SET sub_plan=NULL, sub_expires=NULL "
                    "WHERE sub_plan IS NOT NULL OR sub_expires IS NOT NULL"
                )
                changed = cur.rowcount
                c.commit()
            bot.answer_callback_query(call.id, "All subscriptions cleared.")
            bot.edit_message_text(
                "✅ <b>All subscriptions removed.</b>\n\n"
                "Updated user records: <b>%d</b>\nUser accounts were kept." % changed,
                call.message.chat.id, call.message.message_id, parse_mode="HTML",
            )
            notify_admin_group(
                "🧹 <b>All subscriptions removed</b>\nBy: <code>%s</code>\nRecords updated: <b>%s</b>" %
                (call.from_user.id, changed)
            )
            return
        if key == "ap_removeallsubs_cancel":
            bot.answer_callback_query(call.id, "Cancelled.")
            bot.edit_message_text("✖ <b>Bulk subscription removal cancelled.</b>",
                                  call.message.chat.id, call.message.message_id, parse_mode="HTML")
            return
        if key == "ap_users":
            bot.answer_callback_query(call.id, "Loading users…")
            fake = type("AdminPanelMessage", (), {})()
            fake.from_user, fake.chat = call.from_user, call.message.chat
            cmd_users(fake)
            return
        if key == "ap_maintenance":
            enabled = not maintenance_enabled()
            set_setting("maintenance", "1" if enabled else "0")
            bot.answer_callback_query(call.id, "Maintenance " + ("ON" if enabled else "OFF"))
            summary = "<b>🛠 ARRXCOD ADMIN PANEL</b>\\nMaintenance: <b>%s</b>\\nFree access: <b>%s</b>" % (
                "ON 🔴" if enabled else "OFF 🟢",
                "ON 🟢" if free_access_enabled() else "OFF 🔴")
            try:
                bot.edit_message_text(summary, call.message.chat.id, call.message.message_id,
                                      reply_markup=admin_panel_markup(), parse_mode="HTML")
            except Exception:
                pass
            notify_admin_group("🛠 Maintenance mode %s by <code>%s</code>" % ("enabled" if enabled else "disabled", call.from_user.id))
            return
        if key == "ap_free":
            enabled = not free_access_enabled()
            set_free_access(enabled)
            bot.answer_callback_query(call.id, "Free access " + ("ON" if enabled else "OFF"))
            summary = "<b>🛠 ARRXCOD ADMIN PANEL</b>\\nMaintenance: <b>%s</b>\\nFree access: <b>%s</b>" % (
                "ON 🔴" if maintenance_enabled() else "OFF 🟢",
                "ON 🟢" if enabled else "OFF 🔴")
            try:
                bot.edit_message_text(summary, call.message.chat.id, call.message.message_id,
                                      reply_markup=admin_panel_markup(), parse_mode="HTML")
            except Exception:
                pass
            return
        bot.answer_callback_query(call.id)
        bot.send_message(call.message.chat.id, instructions.get(key, "Unknown admin action"))


    @bot.message_handler(commands=["block"])
    def cmd_block_user(message):
        if not is_admin(message.from_user.id):
            bot.reply_to(message, "⛔ Admin only.")
            return
        parts = (message.text or "").split(maxsplit=2)
        if len(parts) < 2 or not parts[1].isdigit():
            bot.reply_to(message, "Usage: /block TELEGRAM_ID [reason]")
            return
        target = int(parts[1])
        if target in ADMIN_IDS:
            bot.reply_to(message, "⛔ The owner account cannot be blocked.")
            return
        set_user_blocked(target, message.from_user.id, parts[2] if len(parts) > 2 else "")
        notify_admin_group("🚫 User <code>%s</code> blocked by <code>%s</code>" % (target, message.from_user.id))
        bot.reply_to(message, "🚫 User <code>%s</code> is now blocked." % target, parse_mode="HTML")
        try:
            bot.send_message(target, "Your access has been blocked. Contact the owner for assistance.")
        except Exception:
            pass


    @bot.message_handler(commands=["unblock"])
    def cmd_unblock_user(message):
        if not is_admin(message.from_user.id):
            bot.reply_to(message, "⛔ Admin only.")
            return
        parts = (message.text or "").split()
        if len(parts) != 2 or not parts[1].isdigit():
            bot.reply_to(message, "Usage: /unblock TELEGRAM_ID")
            return
        target = int(parts[1])
        removed = set_user_unblocked(target)
        notify_admin_group("♻️ User <code>%s</code> unblocked by <code>%s</code>" % (target, message.from_user.id))
        bot.reply_to(message, ("✅ User unblocked." if removed else "ℹ️ User was not blocked.") + " ID: <code>%s</code>" % target, parse_mode="HTML")


    @bot.message_handler(commands=["removeuser"])
    def cmd_remove_user(message):
        if not is_admin(message.from_user.id):
            bot.reply_to(message, "⛔ Admin only.")
            return
        parts = (message.text or "").split()
        if len(parts) != 2 or not parts[1].isdigit():
            bot.reply_to(message, "Usage: /removeuser TELEGRAM_ID")
            return
        target = int(parts[1])
        if target in ADMIN_IDS:
            bot.reply_to(message, "⛔ The owner account cannot be removed.")
            return
        with db() as c:
            cur = c.execute("DELETE FROM users WHERE tg_id=?", (target,))
            c.execute("DELETE FROM clone_cooldown WHERE tg_id=?", (target,))
            c.execute("DELETE FROM bulk_email_access WHERE tg_id=?", (target,))
            c.commit()
        notify_admin_group("🗑 User record <code>%s</code> removed by <code>%s</code> (audit logs retained)" % (target, message.from_user.id))
        bot.reply_to(message, ("✅ User record removed." if cur.rowcount else "ℹ️ User record not found.") + " ID: <code>%s</code>" % target, parse_mode="HTML")


    @bot.message_handler(commands=["addadmin"])
    def cmd_add_admin(message):
        if not owner_only(message.from_user.id):
            bot.reply_to(message, "⛔ Only the permanent owner can add admins.")
            return
        parts = (message.text or "").split()
        if len(parts) != 2 or not parts[1].isdigit():
            bot.reply_to(message, "Usage: /addadmin TELEGRAM_ID")
            return
        target = int(parts[1])
        if target in ADMIN_IDS:
            bot.reply_to(message, "That user is already a permanent owner.")
            return
        with db() as c:
            c.execute("INSERT OR IGNORE INTO extra_admins (tg_id, added_by, added_at) VALUES (?,?,?)",
                      (target, message.from_user.id, time.time()))
            c.commit()
        notify_admin_group("🛡 Admin <code>%s</code> added by owner <code>%s</code>" % (target, message.from_user.id))
        bot.reply_to(message, "✅ Admin access granted to <code>%s</code>." % target, parse_mode="HTML")


    @bot.message_handler(commands=["removeadmin"])
    def cmd_remove_admin(message):
        if not owner_only(message.from_user.id):
            bot.reply_to(message, "⛔ Only the permanent owner can remove admins.")
            return
        parts = (message.text or "").split()
        if len(parts) != 2 or not parts[1].isdigit():
            bot.reply_to(message, "Usage: /removeadmin TELEGRAM_ID")
            return
        target = int(parts[1])
        if target in ADMIN_IDS:
            bot.reply_to(message, "⛔ Permanent owner IDs are configured with ADMIN_IDS and cannot be removed here.")
            return
        with db() as c:
            cur = c.execute("DELETE FROM extra_admins WHERE tg_id=?", (target,))
            c.commit()
        notify_admin_group("🛡 Admin <code>%s</code> removed by owner <code>%s</code>" % (target, message.from_user.id))
        bot.reply_to(message, ("✅ Admin access removed." if cur.rowcount else "ℹ️ That user was not an extra admin.") + " ID: <code>%s</code>" % target, parse_mode="HTML")


    @bot.message_handler(commands=["admins"])
    def cmd_list_admins(message):
        if not is_admin(message.from_user.id):
            bot.reply_to(message, "⛔ Admin only.")
            return
        with db() as c:
            extra = c.execute("SELECT tg_id FROM extra_admins ORDER BY added_at DESC").fetchall()
        lines = ["Owner: <code>%s</code>" % x for x in sorted(ADMIN_IDS)]
        lines += ["Admin: <code>%s</code>" % r["tg_id"] for r in extra]
        bot.reply_to(message, "<b>Admin accounts</b>\\n" + "\\n".join(lines), parse_mode="HTML")


    @bot.message_handler(commands=["freeaccess", "freeon", "freeoff"])
    def cmd_free_access(message):
        if not is_admin(message.from_user.id):
            bot.reply_to(message, "Admin only.")
            return

        command = (message.text or "").split()[0].split("@", 1)[0].lower()
        args = (message.text or "").split()[1:]
        if command == "/freeon":
            mode = "on"
        elif command == "/freeoff":
            mode = "off"
        elif args:
            mode = args[0].lower()
        else:
            mode = "status"

        if mode in ("on", "enable", "enabled", "1", "true"):
            set_free_access(True)
            bot.reply_to(
                message,
                "🆓 <b>Free access is ON.</b>\nAll users can use the bot without a subscription.\nFree clone limit: %d; cooldown: 5 minutes.\nUse /freeoff to disable." % FREE_CLONE_LIMIT,
                parse_mode="HTML",
            )
        elif mode in ("off", "disable", "disabled", "0", "false"):
            set_free_access(False)
            bot.reply_to(
                message,
                "🔒 <b>Free access is OFF.</b>\nUsers need an active subscription to use protected features.\nUse /freeon to enable again.",
                parse_mode="HTML",
            )
        elif mode == "status":
            enabled = free_access_enabled()
            bot.reply_to(
                message,
                "Free access: <b>%s</b>\nUse /freeaccess on or /freeaccess off." % ("ON 🟢" if enabled else "OFF 🔴"),
                parse_mode="HTML",
            )
        else:
            bot.reply_to(message, "Usage: /freeaccess on, /freeaccess off, or /freeaccess status")

    @bot.message_handler(commands=["setlogchat"])
    def cmd_setlogchat(message):
        # Run this command inside the private group that should receive audit logs.
        if not is_admin(message.from_user.id):
            bot.reply_to(message, "⛔ Admin only.")
            return
        chat_id = str(message.chat.id)
        with db() as c:
            c.execute("INSERT INTO settings (key, value) VALUES ('admin_log_chat_id', ?) ON CONFLICT(key) DO UPDATE SET value=excluded.value", (chat_id,))
            c.commit()
        try:
            bot.send_message(message.chat.id, "✅ This group is now the private audit-log destination. Chat ID: <code>%s</code>" % html.escape(chat_id), parse_mode="HTML")
            notify_admin_group("🧪 <b>Log test</b>\nPrivate group logging is configured.")
        except Exception as exc:
            print("setlogchat confirmation failed:", exc)

    @bot.message_handler(commands=["logchatstatus"])
    def cmd_logchatstatus(message):
        if not is_admin(message.from_user.id):
            bot.reply_to(message, "⛔ Admin only.")
            return
        saved = get_setting("admin_log_chat_id", "")
        active = ADMIN_LOG_CHAT_ID or saved
        bot.reply_to(message, "Private log group: <code>%s</code>\n%s" % (html.escape(str(active or "NOT CONFIGURED")), "Configured" if active else "Open your private group, add the bot, then run /setlogchat there."), parse_mode="HTML")

    @bot.message_handler(commands=["myid"])
    def cmd_myid(message):
        bot.reply_to(message, "Your Telegram ID: <code>%s</code>" % message.from_user.id, parse_mode="HTML")

    @bot.message_handler(commands=["credit", "balance"])
    def cmd_credit(message):
        amount = get_credit_balance(message.from_user.id)
        bot.reply_to(message, "💰 Your bot credit balance: <b>{:g}</b>".format(amount), parse_mode="HTML")

    @bot.message_handler(commands=["addcredit", "deductcredit", "setcredit", "addbalance", "deductbalance", "setbalance"])
    def cmd_manage_credit(message):
        if not is_admin(message.from_user.id):
            bot.reply_to(message, "⛔ Admin only.")
            return
        parts = (message.text or "").split()
        command = parts[0].split("@")[0].lstrip("/").lower()
        if len(parts) != 3 or not parts[1].isdigit():
            bot.reply_to(message, "Usage: /%s <telegram_id> <amount>" % command)
            return
        try:
            amount = float(parts[2])
            if amount < 0 or amount != amount or amount == float("inf"):
                raise ValueError
        except ValueError:
            bot.reply_to(message, "Amount must be a non-negative number.")
            return
        target = int(parts[1])
        with db() as c:
            c.execute("INSERT OR IGNORE INTO users (tg_id, joined_at, last_seen, balance) VALUES (?, ?, ?, 0)", (target, time.time(), time.time()))
            if command in ("addcredit", "addbalance"):
                c.execute("UPDATE users SET balance=balance+? WHERE tg_id=?", (amount, target))
            elif command in ("deductcredit", "deductbalance"):
                c.execute("UPDATE users SET balance=MAX(0, balance-?) WHERE tg_id=?", (amount, target))
            else:
                c.execute("UPDATE users SET balance=? WHERE tg_id=?", (amount, target))
            row = c.execute("SELECT balance FROM users WHERE tg_id=?", (target,)).fetchone()
            c.commit()
        bot.reply_to(message, "✅ Bot wallet updated for Telegram ID <code>%s</code>.\nNew balance: <b>{:g}</b>".format(float(row["balance"])) % target, parse_mode="HTML")
        try:
            bot.send_message(target, "💰 Your bot credit balance is now <b>{:g}</b>".format(float(row["balance"])), parse_mode="HTML")
        except Exception:
            pass

    @bot.message_handler(commands=["addadmin"])
    def cmd_addadmin(message):
        if message.from_user.id not in ADMIN_IDS:
            bot.reply_to(message, "⛔ Only primary ADMIN_IDS owners can add admins.")
            return
        parts = (message.text or "").split()
        if len(parts) != 2 or not parts[1].isdigit():
            bot.reply_to(message, "Usage: /addadmin <telegram_id>\nUse /myid to find your ID.")
            return
        tid = int(parts[1])
        with db() as c:
            c.execute("INSERT OR REPLACE INTO extra_admins (tg_id, added_by, added_at) VALUES (?,?,?)", (tid, message.from_user.id, time.time()))
            c.commit()
        bot.reply_to(message, "✅ Admin added: <code>%s</code>" % tid, parse_mode="HTML")
        notify_admin_group("👑 <b>Admin added</b>\nBy: <code>%s</code>\nNew admin: <code>%s</code>" % (message.from_user.id, tid))

    @bot.message_handler(commands=["deladmin"])
    def cmd_deladmin(message):
        if message.from_user.id not in ADMIN_IDS:
            bot.reply_to(message, "⛔ Only primary ADMIN_IDS owners can remove admins.")
            return
        parts = (message.text or "").split()
        if len(parts) != 2 or not parts[1].isdigit():
            bot.reply_to(message, "Usage: /deladmin <telegram_id>")
            return
        tid = int(parts[1])
        with db() as c:
            c.execute("DELETE FROM extra_admins WHERE tg_id=?", (tid,))
            c.commit()
        bot.reply_to(message, "✅ Delegated admin removed: <code>%s</code>" % tid, parse_mode="HTML")
        notify_admin_group("👑 <b>Admin removed</b>\nBy: <code>%s</code>\nRemoved admin: <code>%s</code>" % (message.from_user.id, tid))

    @bot.message_handler(commands=["admins"])
    def cmd_admins(message):
        if not is_admin(message.from_user.id):
            bot.reply_to(message, "Admin only.")
            return
        with db() as c:
            rows = c.execute("SELECT tg_id FROM extra_admins ORDER BY tg_id").fetchall()
        ids = sorted(ADMIN_IDS) + [int(r["tg_id"]) for r in rows]
        bot.reply_to(message, "<b>Admins</b>\n" + "\n".join("<code>%s</code>" % x for x in ids), parse_mode="HTML")

    @bot.message_handler(commands=["admin"])
    def cmd_admin(message):
        uid = getattr(getattr(message, "from_user", None), "id", None)
        if not is_admin(uid):
            configured = ", ".join(str(x) for x in sorted(ADMIN_IDS)) or "(none configured)"
            bot.reply_to(
                message,
                "⛔ Admin access denied.\nYour Telegram ID: <code>%s</code>\nConfigured ADMIN_IDS: <code>%s</code>\n\nSet ADMIN_IDS to your Telegram numeric ID in your hosting environment, then restart the bot." % (html.escape(str(uid)), html.escape(configured)),
                parse_mode="HTML",
            )
            return
        bot.reply_to(message, "<b>𝙰𝙳𝙼𝙸𝙽 𝙼𝙀𝙉𝚄</b>\n\n<b>Bulk Clone:</b> <b>%s</b>\nUse the button below or /bulkclone_on and /bulkclone_off.\n\n<b>Subscriptions</b>\n/givesub &lt;tg_id&gt; &lt;minutes|3day|7days|1month|lifetime&gt;\n/remsub &lt;tg_id&gt;\n/checktime &lt;tg_id&gt;\n\n<b>Access</b>\n/freeaccess on|off|status (or /freeon, /freeoff)\n\n<b>Maintenance</b>\n/maintenance_on\n/maintenance_off\n/maintenance\n\n<b>Users &amp; logs</b>\n/users\n/stats\n/setlogchat (run inside log group)\n/logchatstatus\n/broadcast text" % ("ON 🟢" if bulk_clone_enabled() else "OFF 🔴"), reply_markup=bulk_clone_admin_kb(), parse_mode="HTML")




if bot:

    @bot.pre_checkout_query_handler(func=lambda q: True)
    def pre_checkout(query):
        try:
            bot.answer_pre_checkout_query(query.id, ok=True)
        except Exception as e:
            print("pre_checkout", e)

    @bot.message_handler(content_types=["successful_payment"])
    def on_successful_payment(message):
        try:
            sp = message.successful_payment
            payload = (sp.invoice_payload or "")
            parts = payload.split(":")
            if len(parts) >= 3 and parts[0] == "stars":
                plan_key = parts[1]
                try:
                    buyer = int(parts[2])
                except Exception:
                    buyer = message.from_user.id
            else:
                plan_key = payload
                buyer = message.from_user.id
            if plan_key not in PLANS:
                bot.send_message(message.chat.id, "Payment received but plan unknown. Contact admin.")
                return
            set_subscription(buyer, plan_key)
            st = sub_status(buyer)
            bot.send_message(
                message.chat.id,
                "✅ <b>Payment OK</b>\nPlan: <b>%s</b>\nUntil: %s\nStars: %s"
                % (PLANS[plan_key]["label"], st.get("expires_str"), sp.total_amount),
            )
            if buyer != message.from_user.id:
                try:
                    bot.send_message(buyer, "✅ Subscription activated: <b>%s</b>" % PLANS[plan_key]["label"])
                except Exception:
                    pass
        except Exception as e:
            print("successful_payment", e)

    @bot.message_handler(commands=["buy", "subscribe"])
    def cmd_buy(message):
        text = (
            "Stars = instant unlock\n"
            "Manual payment = EasyPaisa only; admin approves after screenshot\n\n"
            "%s"
        ) % _money_instructions()
        bot.reply_to(message, text, reply_markup=plans_kb())

    @bot.callback_query_handler(func=lambda c: c.data and c.data.startswith("stars_"))
    def cb_stars(call):
        key = call.data.replace("stars_", "", 1)
        plan = PLANS.get(key)
        if not plan:
            bot.answer_callback_query(call.id, "Invalid")
            return
        uid = call.from_user.id
        stars = int(plan.get("stars") or 0)
        try:
            bot.send_invoice(
                chat_id=uid,
                title="𝘼𝙍𝙍 𝙓 𝘾𝙊𝘿 CPM1 TOOL — %s" % plan["label"],
                description="Subscription %s" % plan["label"],
                invoice_payload="stars:%s:%s" % (key, uid),
                provider_token="",
                currency="XTR",
                prices=[types.LabeledPrice(label=plan["label"], amount=stars)],
            )
            bot.answer_callback_query(call.id, "Invoice sent")
        except Exception as e:
            bot.answer_callback_query(call.id, str(e)[:80], show_alert=True)

    @bot.callback_query_handler(func=lambda c: c.data and c.data.startswith("money_"))
    def cb_money(call):
        key = call.data.replace("money_", "", 1)
        plan = PLANS.get(key)
        if not plan:
            bot.answer_callback_query(call.id, "Invalid")
            return
        uid = call.from_user.id
        un = call.from_user.username or ""
        text = (
            "Pay with money — <b>%s</b>\n"
            "Price: <b>%s</b>\n\n"
            "%s\n\n"
            "After payment, tap the receipt button and send your screenshot here.\n"
            "The owner/admin reviews it and approves access."
        ) % (plan["label"], plan.get("money_label"), _money_instructions())
        bot.answer_callback_query(call.id)
        bot.send_message(call.message.chat.id, text)
        for aid in ADMIN_IDS:
            try:
                bot.send_message(
                    aid,
                    "Money interest\nUser <code>%s</code> @%s\nPlan %s (%s)\n<code>/givesub %s %s</code>"
                    % (uid, un or "—", plan["label"], plan.get("money_label"), uid, key),
                )
            except Exception:
                pass



if bot:
    @bot.message_handler(func=lambda m: bool(getattr(m, "text", None)) and getattr(m.chat, "type", "") == "private")
    def cleaned_interface_router(message):
        """Route screenshot-style reply-keyboard labels to the existing backend handlers."""
        text = (message.text or "").strip()
        uid = message.from_user.id
        chat_id = message.chat.id
        if text.startswith("/"):
            return
        if not is_admin(uid) and is_blocked(uid):
            bot.send_message(chat_id, "🚫 Your access is blocked. Contact the owner.")
            return
        if not is_admin(uid) and maintenance_enabled():
            bot.send_message(chat_id, "🛠 The service is under maintenance. Please try again later.")
            return

        # Main navigation (the dashboard itself carries a persistent Telegram keyboard).
        if text == "🔐 Login":
            if not require_channel_message(chat_id, uid): return
            if not require_sub(uid):
                bot.send_message(chat_id, "🔒 An active subscription is required. Choose a plan below.", reply_markup=plans_kb()); return
            _tg_pending[uid] = ("login_email", {})
            bot.send_message(chat_id, "🔐 Send your CPM account email. Use /cancel to stop.")
            return
        if text == "🆕 Register":
            if not require_channel_message(chat_id, uid): return
            if not require_sub(uid):
                bot.send_message(chat_id, "🔒 An active subscription is required. Choose a plan below.", reply_markup=plans_kb()); return
            _tg_pending[uid] = ("register_email", {})
            bot.send_message(chat_id, "🆕 Send the email address for your new CPM account. Use /cancel to stop.")
            return
        if text == "⭐ Plans":
            bot.send_message(chat_id, "Choose a subscription plan:", reply_markup=plans_kb()); return
        if text == "🎟 Promo Code":
            _tg_pending[uid] = ("redeem_code", {})
            bot.send_message(chat_id, "🎟 Send your redeem code. Use /cancel to stop."); return
        if text == "📞 Contact Owner":
            bot.send_message(chat_id, "📞 Contact Owner: @Reatcpmseller46"); return
        if text == "🔄 Refresh":
            send_start_menu(chat_id, message.from_user); return
        if text == "🚪 Logout":
            _cpm_sessions.pop(uid, None)
            _tg_pending.pop(uid, None)
            bot.send_message(chat_id, "🚪 CPM session logged out.", reply_markup=main_inline_keyboard(uid)); return

        # Main section navigation.
        section_buttons = {
            "👤 Account": "account", "💰 Economy": "economy",
            "🚘 Vehicles": "vehicles", "🔓 Unlocks": "unlocks",
        }
        if text in section_buttons:
            if not require_channel_message(chat_id, uid): return
            if not require_sub(uid):
                bot.send_message(chat_id, "🔒 Subscription required.", reply_markup=plans_kb()); return
            section = section_buttons[text]
            bot.send_message(chat_id, text, reply_markup=telegram_feature_kb(section))
            return

        if text == "🎨 Customization":
            if not require_channel_message(chat_id, uid): return
            if not require_sub(uid):
                bot.send_message(chat_id, "🔒 Subscription required.", reply_markup=plans_kb()); return
            bot.send_message(chat_id, "Customization", reply_markup=telegram_feature_kb("custom")); return
        if text == "⬅️ Back":
            send_start_menu(chat_id, message.from_user); return

        # Map visible submenu labels to the real existing action IDs. Intentionally
        # omitted: Chrome All/Single, Preset All/Single, Race Wins and Race Loses.
        actions = {
            "ℹ️ Info": "acc_info", "✏️ Set Name": "acc_name", "🆔 Set ID": "acc_id",
            "📧 Change Email": "acc_change_credentials", "🔑 Change Password": "acc_change_credentials",
            "🚙 Copy Plates": "plate_copy", "📦 Bulk Clone": "bulk_clone",
            "💵 Money 50M": "eco_money", "🌑 Coins 500K": "eco_coin",
            "💵 Custom Money": "eco_money_c", "🌑 Custom Coins": "eco_coin_c",
            "👑 King Rank": "acc_rank",
            "🔧 W16": "unl_w16", "💨 Smoke": "unl_smoke", "⛽ Fuel": "unl_fuel",
            "🛡 No Damage": "unl_damage", "📯 Horns": "unl_horns", "🎭 Animations": "unl_anim",
            "🏘 All Houses": "unl_houses", "💎 Paid Wheels": "unl_wheels",
            "🏆 All Levels": "unl_levels", "👕 All Clothes": "unl_clothes", "🚨 Sirens": "veh_siren", "✅ Unlock All": "unl_all",
            "🚘 Unlock All Cars": "veh_all", "🛒 Buy Car (ID)": "veh_one",
            "🔧 Bumpers All": "bump_both_all", "🔧 Bumpers Single": "bump_both",
            "🚨 Police All": "veh_siren", "🚨 Police Single": "veh_siren_one",
            "🚘 Clone All": "car_all", "🚘 Clone Single": "car_one",
            "📋 Vinyls All": "vinyl_all", "📋 Vinyls Single": "vinyl_one",
            "🔢 Inject Plates": "plate_inject", "🚘 Unlock W124": "veh_w124",
            "🚘 Unlock Camry": "veh_camry",
            "🌈 Colourful Name": "acc_color_name", "🌈 Colourful ID": "acc_color_id",
            "🌈 Custom Rainbow Name": "acc_custom_rainbow_name",
            "🌈 Rainbow ID (current)": "acc_rainbow_id",
            "🌈 Custom Rainbow ID": "acc_custom_rainbow_id",
            "🎨 Vinyl Single Car": "vinyl_one", "🎨 Transfer Vinyl Matching Cars": "vinyl_all",
            "🚗 Clone Single Car": "car_one", "🚗 Clone All Cars": "car_all",
            "🔢 Copy Plates From Account": "plate_copy",
        }
        if text == "👥 Clone Account":
            if not require_channel_message(chat_id, uid): return
            if not require_sub(uid):
                bot.send_message(chat_id, "🔒 Subscription required.", reply_markup=plans_kb()); return
            _tg_pending[uid] = ("clone_source", {})
            bot.send_message(chat_id, "Clone account: send the source CPM email first. Use /cancel to stop.")
            return
        if text in actions:
            # Invoke the same callback implementation used by the inline interface,
            # but without issuing an answerCallbackQuery for a non-callback message.
            fake_call = type("TextMenuCall", (), {})()
            fake_call.id = None
            fake_call.data = "do_" + actions[text]
            fake_call.from_user = message.from_user
            fake_call.message = message
            cb_telegram_action(fake_call)
            return
        # Leave ordinary text for pending-input handlers or normal chat.
        return


def run_flask():
    flask_app.run(host="0.0.0.0", port=PORT, threaded=True, use_reloader=False)


if __name__ == "__main__":
    print("𝘼𝙍𝙍 𝙓 𝘾𝙊𝘿 CPM1 TOOL — Telegram-native menu")
    print("ADMIN_IDS =", ADMIN_IDS)
    print("ADMIN_LOG_CHAT_ID env configured =", bool(ADMIN_LOG_CHAT_ID))
    if bot:
        try:
            bot.remove_webhook()
            me = bot.get_me()
            print("Bot OK @%s" % me.username)
        except Exception as e:
            print("Bot token issue:", e)
    threading.Thread(target=run_flask, daemon=True).start()
    if bot:
        while True:
            try:
                bot.infinity_polling(timeout=60, long_polling_timeout=60, skip_pending=True, none_stop=True)
            except Exception as e:
                print("poll", e)
                time.sleep(3)
    else:
        run_flask()
