"""coby bot configuration."""

import os

APP_NAME = "coby"
APP_VERSION = "2.0"
MAX_CLONES_PER_RUN = 500
CLONE_WORKERS = 10
CLONE_COOLDOWN_SECONDS = 600

BOT_TOKEN = (os.getenv("BOT_TOKEN") or "9183078363:AAH3zhKvDP5pURaziHJouOjwWb4IN5BUWgc").strip()
ADMIN_ID = int(os.getenv("ADMIN_ID", "7251509770"))
ADMIN_USERNAME = (os.getenv("ADMIN_USERNAME", "arrxcod") or "").lstrip("@arrxcod")

CHANNEL_LINK = "https://t.me/arrxcodchannel"
CHANNEL_USERNAME = "@arrxcodchannel"

GROUP_LINK = "https://t.me/arrxcodtalk"
# No public @username was supplied; this invite link is private.
GROUP_USERNAME = "@arrxcodtalk"

# Direct, host-IP network policy: do not go through third-party proxy scrapers.
HOST_SERVER_IP = (os.getenv("HOST_SERVER_IP") or "127.0.0.1").strip()
REQUEST_TIMEOUT_SECONDS = float(os.getenv("REQUEST_TIMEOUT_SECONDS", "8"))
REQUEST_MAX_RETRIES = int(os.getenv("REQUEST_MAX_RETRIES", "4"))
REQUEST_BACKOFF_SECONDS = float(os.getenv("REQUEST_BACKOFF_SECONDS", "0.75"))
REQUEST_PACE_SECONDS = float(os.getenv("REQUEST_PACE_SECONDS", "0.35"))
USE_PROXY_ROTATION = False
DIRECT_REQUESTS_ONLY = True
TRUST_ENV_PROXIES = False

if not BOT_TOKEN:
    raise RuntimeError(
        "BOT_TOKEN is empty. Set the BOT_TOKEN environment variable or config.py before starting the bot."
    )
