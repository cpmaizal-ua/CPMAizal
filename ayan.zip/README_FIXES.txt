ARRXCOD CPM BOT - repaired package

Changes made:
- Fetch errors now include a short HTTP response body for diagnostics (no request headers/tokens).
- Unexpected/malformed successful responses are errors, not fake empty garages.
- Source-account credentials are read from CPM_SOURCE_EMAIL and CPM_SOURCE_PASSWORD.
- Removed the hard-coded Telegram bot token from config.py; BOT_TOKEN must be set in the host environment.
- Verified Python syntax for main.py, cpm1_core.py, and config.py.

Important limitations:
- An HTTP 500 from GetAllCars2 is a remote service failure. This patch improves diagnostics and prevents false success, but cannot guarantee the game service will accept a request or change its server-side behavior. Do not repeatedly hammer the endpoint.
- The package has not been live-tested against Telegram or the game service because that requires your credentials and a live service.

Before deploying:
1. Revoke/regenerate the Telegram bot token in BotFather because it was exposed in the uploaded config.
2. Change the source account password because it was included in the uploaded core file.
3. Add the NEW token and credentials as hosting environment variables. Never commit .env or real secrets.
4. Upload main.py, cpm1_core.py, config.py, requirements.txt. Install requirements and restart.


Stock-car unlock update
- The unlock-all / unlock-one-car path now clears body and window vinyl collections, turns off the CPM1 siren flag, and clears installed police-light entries before saving.
- The change applies only to unlock actions; normal clone and explicit vinyl-transfer functions are unchanged.
- This was syntax-checked, but the live game API was not available for end-to-end verification.
